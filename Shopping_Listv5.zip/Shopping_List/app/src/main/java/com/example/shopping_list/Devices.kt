package com.example.shopping_list

import android.content.Context
import android.os.Build
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import java.util.UUID

/** One phone, tablet or computer using the list (screen 3.5). */
data class Device(
    val id: String,
    val name: String,     // "Mary's tablet"
    val type: String,     // "Tablet", "Phone" or "Computer"
    val owner: String     // "Mary"
)

/**
 * The devices on a list, kept in Firebase:
 *
 *   lists / KQZPMT / devices        / a1b2c3 = { name, type, owner, lastSeen }
 *   lists / KQZPMT / removedDevices / a1b2c3 = true
 *
 * A device joins by entering its person's name: no password, no code.
 */
object Devices {

    private fun list(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists").child(listId)

    private fun ref(listId: String) = list(listId).child("devices")
    private fun removedRef(listId: String) = list(listId).child("removedDevices")

    private fun userName(context: Context): String =
        context.getSharedPreferences("shopping", Context.MODE_PRIVATE)
            .getString("userName", "") ?: ""

    /** A random id for this device, made once and kept until Log out. */
    fun myId(context: Context): String {
        val prefs = context.getSharedPreferences("shopping", Context.MODE_PRIVATE)
        prefs.getString("deviceId", null)?.let { return it }
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        prefs.edit().putString("deviceId", id).apply()
        return id
    }

    /** Tablets have a wider screen; phones are narrower. */
    private fun isTablet(context: Context) =
        context.resources.configuration.smallestScreenWidthDp >= 600

    /** The Android emulator on a laptop or desktop computer. */
    private fun isEmulator(): Boolean =
        Build.FINGERPRINT.startsWith("generic") ||
                Build.FINGERPRINT.contains("emulator") ||
                Build.MODEL.contains("sdk_gphone") ||
                Build.MODEL.contains("Emulator") ||
                Build.MODEL.contains("Android SDK built for") ||
                Build.HARDWARE == "goldfish" ||
                Build.HARDWARE == "ranchu" ||
                Build.PRODUCT.contains("sdk")

    /** "Computer", "Tablet" or "Phone". */
    private fun typeOf(context: Context): String = when {
        isEmulator() -> "Computer"
        isTablet(context) -> "Tablet"
        else -> "Phone"
    }

    /** Puts this device on the list's Devices screen, as "Mary's tablet". */
    fun register(context: Context, listId: String) {
        val owner = userName(context)
        val type = typeOf(context)
        val name = if (owner.isEmpty()) type else "$owner's ${type.lowercase()}"
        ref(listId).child(myId(context)).setValue(
            mapOf(
                "name" to name,
                "type" to type,
                "owner" to owner,
                "lastSeen" to ServerValue.TIMESTAMP
            )
        )
    }

    /** Takes this device off the Devices screen, on Log out. */
    fun unregister(context: Context, listId: String) {
        ref(listId).child(myId(context)).removeValue()
    }

    /** The devices on the list, now and after every change. */
    fun listen(listId: String, onChanged: (List<Device>) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                onChanged(snapshot.children.map { child ->
                    Device(
                        id = child.key ?: "",
                        name = child.child("name").value?.toString() ?: "",
                        type = child.child("type").value?.toString() ?: "",
                        owner = child.child("owner").value?.toString() ?: ""
                    )
                })
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        ref(listId).addValueEventListener(listener)
        return listener
    }

    fun stop(listId: String, listener: ValueEventListener) {
        ref(listId).removeEventListener(listener)
    }

    /** For a lost phone: it disappears here, and leaves the list. */
    fun remove(listId: String, device: Device) {
        ref(listId).child(device.id).removeValue()
        removedRef(listId).child(device.id).setValue(true)
    }

    /** Calls [onRemoved] if this device is removed on any other device. */
    fun watchRemoved(context: Context, listId: String, onRemoved: () -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.value == true) onRemoved()
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        removedRef(listId).child(myId(context)).addValueEventListener(listener)
        return listener
    }

    fun stopWatching(context: Context, listId: String, listener: ValueEventListener) {
        removedRef(listId).child(myId(context)).removeEventListener(listener)
    }

    /** "+ Add a device": three simple steps. No password, no code. */
    fun showHowToAdd(activity: AppCompatActivity) {
        val name = userName(activity).ifEmpty { "your name" }
        AlertDialog.Builder(activity)
            .setTitle("Add a device")
            .setMessage(
                "On the other phone or tablet:\n\n" +
                        "1.  Install the Shopping list app.\n" +
                        "2.  Open it.\n" +
                        "3.  Enter your name: $name\n\n" +
                        "It will open this shopping list straight away."
            )
            .setPositiveButton("OK", null)
            .show()
    }
}