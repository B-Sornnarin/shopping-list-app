package com.example.shopping_list

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.ValueEventListener

/**
 * Screen 3.3 Add a person.
 *
 * No code to type. Their name is saved to this list, the invitation is
 * shown, and Send opens a text message to their number. When they
 * install the app and enter their name, they land on this list.
 *
 * The same name or the same mobile number is never invited twice.
 */
class AddPersonScreen : AppCompatActivity() {

    private lateinit var listId: String
    private var people: List<Person> = emptyList()
    private var listener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_person)

        listId = Session.listId(this) ?: return finish()
        val nameInput = findViewById<EditText>(R.id.personNameInput)
        val mobileInput = findViewById<EditText>(R.id.personMobileInput)
        val sendButton = findViewById<View>(R.id.sendLinkButton)

        // Who is already on the list, for the checks below.
        listener = People.listen(listId) { latest -> people = latest }

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }

        sendButton.setOnClickListener {
            val name = Names.display(nameInput.text.toString())
            val mobile = mobileInput.text.toString().filter { it.isDigit() || it == '+' }

            // ---- Check what was typed ----
            if (name.isEmpty()) {
                return@setOnClickListener tell("Name needed", "Please enter the person's name.")
            }
            if (mobile.count { it.isDigit() } < 8) {
                return@setOnClickListener tell("Mobile number needed",
                    "Please enter a valid mobile number, for example 0412 345 678.")
            }

            // ---- Already on this list? ----
            people.firstOrNull { Names.same(it.name, name) }?.let { existing ->
                return@setOnClickListener tell("Already on the list",
                    "${existing.name} is already on this shopping list.")
            }
            people.firstOrNull { People.sameMobile(it.mobile, mobile) }?.let { existing ->
                return@setOnClickListener tell("Already invited",
                    "${existing.name} has already been invited using this mobile number.")
            }

            sendButton.isEnabled = false

            // ---- Is the name used for a different list? ----
            Accounts.find(
                name,
                onFound = { otherList ->
                    sendButton.isEnabled = true
                    if (otherList != null && otherList != listId) {
                        tell("Name already in use",
                            "The name $name is already used for another shopping list. " +
                                    "Please use a different name, such as their full name.")
                    } else {
                        Accounts.save(name, listId)          // their name opens this list
                        // invitedBy lets them see "Sorn has invited you" when they join.
                        People.join(listId, name, mobile = mobile, invitedBy = myName())
                        sendText(name, mobile)
                    }
                },
                onError = { reason ->
                    sendButton.isEnabled = true
                    tell("Something went wrong",
                        "The invitation could not be sent. Please check the internet " +
                                "connection and try again.\n\n($reason)")
                }
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.let { People.stop(listId, it) }
    }

    /** The name of the person using this phone, e.g. "Sorn". */
    private fun myName(): String =
        getSharedPreferences("shopping", MODE_PRIVATE).getString("userName", "") ?: ""

    /**
     * Shows the phone's share sheet with the invitation ready:
     * Messages, Email, WhatsApp, LINE, Facebook… whatever is installed.
     * Android never remembers a choice here, so every invite can use any app.
     */
    private fun sendText(name: String, mobile: String) {
        val link = android.net.Uri.Builder()
            .scheme("https")
            .authority(JoinLink.HOST)
            .path("join")
            .appendQueryParameter("l", listId)
            .appendQueryParameter("n", name)
            .build()
            .toString()
        android.util.Log.d("Invite", link)   // for testing: Logcat, tag:=Invite

        val message =
            "Hi $name, ${myName()} has invited you to share a shopping list. " +
                    "Install the Shopping list app, then tap this link to join:\n$link"

        // Also copied, so it can be pasted anywhere.
        val clipboard = getSystemService(android.content.ClipboardManager::class.java)
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Invite link", link))

        // Every app that can share text: WhatsApp, Gmail, LINE, Facebook…
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Shopping list invitation")
            putExtra(Intent.EXTRA_TEXT, message)
        }
        // Plus a text message straight to their number, shown first.
        val sms = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$mobile")).apply {
            putExtra("sms_body", message)
        }

        val chooser = Intent.createChooser(share, "Send the invitation to $name")
        if (sms.resolveActivity(packageManager) != null) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(sms))
        }

        try {
            startActivity(chooser)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this,
                "$name has been added. The invite link has been copied, so you can paste it into any app.",
                Toast.LENGTH_LONG).show()
        }
        setResult(RESULT_OK)
        finish()
    }

    /** A clear message that stays until OK is tapped. */
    private fun tell(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }
}