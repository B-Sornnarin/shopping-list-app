package com.example.shopping_list

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * The groups shown on the list (screen 3.2), kept in Firebase so the
 * whole household sees the same groups in the same order.
 *
 *   lists / KQZPMT / categories = ["Fruit & veg", "Fridge", ...]
 */
object Categories {

    /** The groups every list starts with. These cannot be removed. */
    val builtIn = listOf(
        "Fruit & veg", "Fridge", "Frozen", "Bathroom", "Cleaning", "Cupboard", "Other"
    )

    private fun ref(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists")
            .child(listId).child("categories")

    /**
     * Calls [onChanged] with the groups in order, now and after every
     * change on any device. Returns the listener so it can be stopped.
     */
    fun listen(listId: String, onChanged: (List<String>) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val saved = snapshot.children.mapNotNull { it.value?.toString() }
                // Any built-in group missing is added at the end.
                onChanged(saved + builtIn.filter { it !in saved })
            }

            override fun onCancelled(error: DatabaseError) {
                onChanged(builtIn)
            }
        }
        ref(listId).addValueEventListener(listener)
        return listener
    }

    fun stop(listId: String, listener: ValueEventListener) {
        ref(listId).removeEventListener(listener)
    }

    /** Reads the groups once, for a menu that needs them right now. */
    fun once(listId: String, onLoaded: (List<String>) -> Unit) {
        ref(listId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val saved = snapshot.children.mapNotNull { it.value?.toString() }
                onLoaded(saved + builtIn.filter { it !in saved })
            }

            override fun onCancelled(error: DatabaseError) = onLoaded(builtIn)
        })
    }

    /** Saves the groups in this order. */
    fun save(listId: String, categories: List<String>) {
        ref(listId).setValue(categories)
    }
}