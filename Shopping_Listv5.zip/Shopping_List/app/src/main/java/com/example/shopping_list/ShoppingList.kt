package com.example.shopping_list

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Screen 2.0 The list.
 *
 * The list lives in Firebase, so anything done here appears on every
 * other device straight away, and the other way round.
 */
class ShoppingList : AppCompatActivity() {

    /** Shorthand for ViewGroup.LayoutParams.WRAP_CONTENT. */
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var adapter: ItemAdapter
    private lateinit var toGetText: TextView

    /** What is on screen. Firebase replaces its contents. */
    private val items = mutableListOf<Item>()

    private val addLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != Activity.RESULT_OK) return@registerForActivityResult
        val names = addFromResult(result.data)

        // Suggestion (2.4): at most one card, straight after adding.
        Suggestions.next(this, names, items)?.let { showSuggestion(it) }
        Suggestions.record(this, names)
    }

    /** Yes on a suggestion: add it. No second card, so one at a time. */
    private val suggestionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            Suggestions.record(this, addFromResult(result.data))
        }
    }

    /** Opens the Add screen (from the bottom bar's + Add). */
    private fun openAdd() {
        addLauncher.launch(Intent(this, AddItem::class.java))
    }

    /**
     * The bottom bar (Home, + Add, People). Messages and the favourites
     * menu sit just above it, so they never cover it.
     */
    private val bottomBar: View
        get() {
            val wrapper = findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as ViewGroup
            return wrapper.getChildAt(wrapper.childCount - 1)
        }

    /** Puts the returned things on the list and says which they were. */
    private fun addFromResult(data: Intent?): List<String> {
        val names = data?.getStringArrayListExtra("names") ?: return emptyList()
        val categories = data.getStringArrayListExtra("categories") ?: arrayListOf()
        val pictures = data.getStringArrayListExtra("pictures") ?: arrayListOf()

        // Write to Firebase only. The listener puts them on screen.
        names.forEachIndexed { i, name ->
            ListRepository.add(
                name,
                categories.getOrElse(i) { "" },
                pictures.getOrElse(i) { "" },
                myName()   // who added it, for other people's notifications
            )
        }
        Session.listId(this)?.let { Regulars.record(it, names) }   // counts for "Regular", shared
        return names
    }

    private fun showSuggestion(card: Suggestions.Card) {
        val intent = Intent(this, SuggestionScreen::class.java)
        intent.putExtra("heading", card.heading)
        intent.putExtra("shownName", card.shown.name)
        intent.putExtra("shownPicture", Library.pictureFor(this, card.shown))
        intent.putExtra("question", card.question)
        intent.putExtra("yesText", card.yesText)
        intent.putExtra("addName", card.toAdd?.name ?: "")
        intent.putExtra("addCategory", card.toAdd?.category ?: "")
        intent.putExtra("addPicture", card.toAdd?.picture ?: "")
        suggestionLauncher.launch(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shopping_list)
        Library.load(this)   // so the household's own pictures show on the list

        // Which list this device is on. Without it there is nothing to show.
        val listId = Session.listId(this)
        if (listId == null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        ListRepository.use(listId)

        // Bottom bar: Home, + Add, People.
        // The old + Add button is hidden; the bar's + Add does the same thing.
        findViewById<View>(R.id.addButton).visibility = View.GONE
        BottomBar.attach(this, BottomBar.HOME) { openAdd() }

        // This device appears on Settings > Devices (3.5), and leaves if removed there.
        Devices.register(this, listId)
        Reminders.schedule(this)   // the daily "Still on your list" check (3.9)
        Favourites.start(listId)   // so tapping an item knows if it is a favourite
        Favourites.watch(refreshStars)   // the gold ★ appears straight away
        SharedPictures.start(this, listId)   // pictures changed on other devices
        SharedPictures.watch(refreshStars)   // redraw the list when one arrives
        Permission.start(this, listId)       // may this person remove favourites, etc.
        Regulars.start(listId)               // the household's regular things, shared
        Library.startSharing(this, listId)   // the household's own things, and their groups
        Library.watch(refreshStars)          // redraw when one arrives, or a group changes
        deviceListener = Devices.watchRemoved(this, listId) { leaveRemovedDevice() }
        findViewById<android.widget.ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, Settings::class.java))
        }

        // The phone's Back button closes the favourites menu first, if it is open.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (HoldMenu.close(this@ShoppingList)) return
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
                isEnabled = true
            }
        })

        toGetText = findViewById(R.id.toGetText)

        adapter = ItemAdapter(
            this,
            items,
            onTicked = { item -> ticked(item) },
            onDelete = { item -> deleteWithUndo(item) },
            onTapped = { item, row -> showFavouriteChoice(item, row) },
            onCountChanged = { item, count -> ListRepository.setCount(item, count) },
            onCountTapped = { item -> askHowMany(item) }
        )

        val list = findViewById<RecyclerView>(R.id.itemsList)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        // One listener keeps the screen in step with the database.
        ListRepository.listen { fromDatabase ->
            tellAboutNewItems(fromDatabase)
            items.clear()
            items.addAll(fromDatabase)
            adapter.refresh()
            showCount()
        }

        // If someone removes this person from the list (3.1), leave it.
        val myKey = Names.firebaseKey(
            getSharedPreferences("shopping", MODE_PRIVATE).getString("userName", "") ?: ""
        )
        if (myKey.isNotEmpty()) {
            removedListener = People.watchRemoved(listId, myKey) { leaveRemovedList() }
            removedKey = myKey
        }

        // The group order from Categories (3.2), kept in step the same way.
        categoryListener = Categories.listen(listId) { order ->
            adapter.order = order
            adapter.refresh()
        }

        showCount()

        // + Add was tapped on the People screen's bar: open Add now.
        if (intent.getBooleanExtra("openAdd", false)) openAdd()
    }

    /** The bar's + Add was tapped on another screen while this list was open. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("openAdd", false)) openAdd()
    }

    override fun onResume() {
        super.onResume()
        // Picture size or Group by may have changed while we were in Settings.
        adapter.grouped = getSharedPreferences("shopping", MODE_PRIVATE)
            .getString("groupBy", "category") != "none"
        adapter.refresh()
    }

    override fun onDestroy() {
        super.onDestroy()
        Favourites.unwatch(refreshStars)
        SharedPictures.unwatch(refreshStars)
        Library.unwatch(refreshStars)
        HoldMenu.close(this, animate = false)
        val deviceListId = Session.listId(this)
        val dl = deviceListener
        if (deviceListId != null && dl != null) Devices.stopWatching(this, deviceListId, dl)
        ListRepository.stopListening()
        val listId = Session.listId(this)
        val listener = categoryListener
        if (listId != null && listener != null) Categories.stop(listId, listener)
        val removed = removedListener
        if (listId != null && removed != null) People.stopWatching(listId, removedKey, removed)
    }

    /** Redraws the list when favourites change, so the gold ★ shows at once. */
    private val refreshStars: () -> Unit = {
        if (::adapter.isInitialized) adapter.refresh()
    }

    /**
     * Tapping an item's picture or name: the same menu as on Add.
     * The screen dims, the item lifts, and a small menu offers
     * ★ Add to favourites (or 🗑 Remove from favourites) and Cancel.
     */
    private fun showFavouriteChoice(item: Item, row: View) {
        val libraryItem = Library.items.firstOrNull { Names.same(it.name, item.name) }
        if (libraryItem == null) {
            showMessage("Only things with a picture can be favourites.")
            return
        }

        val favourite = Favourites.isFavourite(libraryItem.id)
        val main = if (favourite && !Permission.allowed(this)) {
            HoldMenu.Row("Permission needed to remove", "#8A93A3") {}
        } else if (favourite) {
            HoldMenu.Row("Remove from favourites", "#B3261E") {
                Favourites.set(libraryItem.id, false)
                showMessage("${item.name} removed from favourites")
            }
        } else {
            HoldMenu.Row("Add to favourites", "#1F3864") {
                Favourites.set(libraryItem.id, true)
                showMessage("★ ${item.name} added to favourites")
            }
        }
        HoldMenu.show(this, row, bottomBar, listOf(
            main,
            HoldMenu.Row("Cancel", "#1A1A1A") {}
        ))
    }

    /** A short message at the bottom, above the bar, in big words. */
    private fun showMessage(text: String) {
        val bar = com.google.android.material.snackbar.Snackbar.make(
            findViewById(R.id.itemsList), text, 4000
        )
        bar.setAnchorView(bottomBar)
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_text
        ).textSize = 18f
        bar.show()
    }

    /** "Start a new list" on All done: clear, with Undo. */
    private val allDoneLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        allDoneShowing = false   // All done has closed
        if (result.resultCode == Activity.RESULT_OK) clearWithUndo()
    }

    private var removedListener: com.google.firebase.database.ValueEventListener? = null
    private var removedKey = ""

    /** This person was removed: explain, then go back to Set up. */
    private fun leaveRemovedList() {
        if (isFinishing) return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Removed from the list")
            .setMessage("You have been removed from this shopping list. " +
                    "Ask the person who set it up if you would like to join again.")
            .setCancelable(false)
            .setPositiveButton("OK") { _, _ ->
                getSharedPreferences("shopping", MODE_PRIVATE).edit().clear().apply()
                startActivity(Intent(this, MainActivity::class.java))
                finishAffinity()
            }
            .show()
    }

    /** Listens for changes to the group order. */
    private var categoryListener: com.google.firebase.database.ValueEventListener? = null

    /**
     * The bin removes the item at once, then offers Undo for a while,
     * so a mis-tap is easy to put right. No "Are you sure?" box.
     */
    private fun deleteWithUndo(item: Item) {
        val saved = item.copy()
        ListRepository.remove(item)

        val bar = com.google.android.material.snackbar.Snackbar.make(
            findViewById(R.id.itemsList),
            "${item.name} deleted",
            8000   // 8 seconds: longer than usual, to give time to read
        )
        bar.setAction("Undo") { ListRepository.restore(saved) }
        bar.setAnchorView(bottomBar)   // sits above the bar, not over it

        // Bigger words than Android's default.
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_text
        ).textSize = 18f
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_action
        ).textSize = 18f

        bar.show()
    }

    private fun myName(): String =
        getSharedPreferences("shopping", MODE_PRIVATE).getString("userName", "") ?: ""

    /** Ids already seen, so only new ones are announced. Null until the list first loads. */
    private var knownIds: Set<String>? = null

    /**
     * "Frank added to the list: Milk and Bread", for what others just added.
     * List on screen: our own banner (3.8) and a quiet notification to read later.
     * App in the background: an Android notification that pops up.
     */
    private fun tellAboutNewItems(latest: List<Item>) {
        val known = knownIds
        knownIds = latest.map { it.id }.toSet()
        if (known == null) return   // opening the app: nothing is "new"

        val notifyOn = getSharedPreferences("shopping", MODE_PRIVATE).getBoolean("notify", false)
        val onScreen = lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)

        latest
            .filter { it.id !in known && it.addedBy.isNotEmpty() && !Names.same(it.addedBy, myName()) }
            .groupBy { it.addedBy }
            .forEach { (who, added) ->
                val names = added.map { it.name }
                if (onScreen && notifyOn) {
                    val what = when (names.size) {
                        1 -> names[0]
                        2 -> "${names[0]} and ${names[1]}"
                        else -> "${names[0]}, ${names[1]} and ${names.size - 2} more"
                    }
                    InAppBanner.show(this, "$who added to the list", what)
                    Notifier.newItems(this, who, names, quiet = true)   // kept in the pull-down list
                } else {
                    Notifier.newItems(this, who, names)
                }
            }
    }

    /** Listens for this device being removed on Settings > Devices. */
    private var deviceListener: com.google.firebase.database.ValueEventListener? = null

    /** This device was removed (e.g. reported lost): explain, then go to Set up. */
    private fun leaveRemovedDevice() {
        if (isFinishing) return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Device removed")
            .setMessage("This device was removed from the shopping list. " +
                    "To use it again, enter your name when the app opens.")
            .setCancelable(false)
            .setPositiveButton("OK") { _, _ ->
                getSharedPreferences("shopping", MODE_PRIVATE).edit().clear().apply()
                startActivity(Intent(this, MainActivity::class.java))
                finishAffinity()
            }
            .show()
    }

    private fun showCount() {
        val empty = items.isEmpty()

        findViewById<TextView>(R.id.emptyText).visibility =
            if (empty) View.VISIBLE else View.GONE

        toGetText.visibility = if (empty) View.GONE else View.VISIBLE
        toGetText.text = "${adapter.stillToGet()} to get"
    }

    /** True while All done is on screen, so it never opens twice. */
    private var allDoneShowing = false

    /** The waiting check, so a quicker second tick replaces it instead of adding another. */
    private val checkAllDone = Runnable {
        if (!isFinishing && !allDoneShowing && items.isNotEmpty() && items.all { it.done }) {
            allDoneShowing = true
            val intent = Intent(this, AllDoneScreen::class.java)
            intent.putExtra("count", items.size)
            allDoneLauncher.launch(intent)
        }
    }

    /** Saves the tick, and celebrates when it was the last one. */
    /**
     * "How many Apple?" with the number already in the box, so she can
     * type 12 rather than tapping + twelve times. Anything odd is
     * quietly brought back between 1 and 99 rather than refused.
     */
    private fun askHowMany(item: Item) {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val input = EditText(this).apply {
            setText(item.count.toString())
            setSelection(text.length)
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 28f
            gravity = Gravity.CENTER
            setSingleLine()
            // No underline: the number is the whole pop-up, and the
            // cursor already shows it can be typed over.
            background = null
            setPadding(0, dp(6), 0, dp(6))
        }
        // No title: the row she tapped is still behind the pop-up, so
        // the number on its own is enough, and the box stays small.
        val holder = FrameLayout(this).apply { setPadding(dp(22), dp(18), dp(22), dp(4)) }
        holder.addView(input, FrameLayout.LayoutParams(dp(104), wrap, Gravity.CENTER))

        MaterialAlertDialogBuilder(this, R.style.Shopping_SmallDialog)
            .setView(holder)
            .setPositiveButton("OK") { _, _ ->
                val typed = input.text.toString().trim().toIntOrNull() ?: return@setPositiveButton
                ListRepository.setCount(item, typed.coerceIn(1, 99))
            }
            .setNegativeButton("Cancel", null)
            .show()

    }

    private fun ticked(item: Item) {
        ListRepository.setDone(item, item.done)
        val list = findViewById<View>(R.id.itemsList)
        list.removeCallbacks(checkAllDone)          // forget any earlier wait
        if (!item.done) return

        // A short pause, so the last row is seen turning green first.
        list.postDelayed(checkAllDone, 700)
    }

    /** Clears the list, with 8 seconds to Undo. */
    private fun clearWithUndo() {
        val saved = items.map { it.copy() }
        ListRepository.clear()

        val bar = com.google.android.material.snackbar.Snackbar.make(
            findViewById(R.id.itemsList),
            "List cleared",
            8000
        )
        bar.setAction("Undo") { saved.forEach { ListRepository.restore(it) } }
        bar.setAnchorView(bottomBar)
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_text
        ).textSize = 18f
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_action
        ).textSize = 18f
        bar.show()
    }
}