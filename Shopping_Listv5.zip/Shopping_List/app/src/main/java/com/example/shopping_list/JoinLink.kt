package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Opens an invite link (1.4):
 *   https://shopping-list-48b.web.app/join?l=KQZPMT&n=Anna
 *
 * The invited person sees who invited them and chooses to join.
 * No typing, no code, no password.
 */
class JoinLink : AppCompatActivity() {

    companion object {
        /** The free Firebase Hosting address for this project. */
        const val HOST = "group-project-ca0a3.web.app"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            text = "Opening your invitation…"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(0xFF1F3864.toInt())
            setBackgroundColor(0xFFFFFFFF.toInt())
        })

        val uri = intent?.data
        val listId = uri?.getQueryParameter("l")?.trim()?.uppercase() ?: ""
        val name = Names.display(uri?.getQueryParameter("n") ?: "")
        if (listId.isEmpty() || name.isEmpty()) return invalid()

        val current = Session.listId(this)
        when {
            current == listId -> openList()              // already on this list
            current != null -> askToSwitch(listId, name)  // on another list
            else -> checkInvitation(listId, name)
        }
    }

    /** This device already has a list: ask before moving it. */
    private fun askToSwitch(listId: String, name: String) {
        AlertDialog.Builder(this)
            .setTitle("Join another list?")
            .setMessage("This device is already using a shopping list. " +
                    "Joining will switch it to the new list.")
            .setCancelable(false)
            .setPositiveButton("Switch") { _, _ -> checkInvitation(listId, name) }
            .setNegativeButton("Stay") { _, _ -> openList() }
            .show()
    }

    /** Is the invitation still there? (It is gone if the person was removed.) */
    private fun checkInvitation(listId: String, name: String) {
        People.find(listId, name) { found, inviter ->
            if (found) showInvitation(listId, name, inviter) else invalid()
        }
    }

    private fun showInvitation(listId: String, name: String, inviter: String) {
        val who = inviter.ifEmpty { "Someone" }
        AlertDialog.Builder(this)
            .setTitle("You're invited")
            .setMessage(
                "Hi $name, $who has invited you to share a shopping list.\n\n" +
                        "You can add things, tick them off, and see what others add straight away."
            )
            .setCancelable(false)
            .setPositiveButton("Join the list") { _, _ -> join(listId, name) }
            .setNegativeButton("No, thanks") { _, _ ->
                People.remove(listId, Person(key = Names.firebaseKey(name), name = name))
                finish()
            }
            .show()
    }

    private fun join(listId: String, name: String) {
        // Leaving another list: take this device off its Devices screen.
        Session.listId(this)?.let { Devices.unregister(this, it) }

        getSharedPreferences("shopping", MODE_PRIVATE).edit()
            .putString("userName", Names.display(name))
            .putString("userKey", Names.key(name))
            .putBoolean("setupDone", true)
            .apply()
        Session.setListId(this, listId)
        Accounts.save(name, listId)            // their name opens this list too
        People.markWelcomed(listId, name)
        openList()
    }

    private fun invalid() {
        AlertDialog.Builder(this)
            .setTitle("Invitation not valid")
            .setMessage("This invitation link is no longer valid. " +
                    "Ask the person who invited you to send a new one.")
            .setCancelable(false)
            .setPositiveButton("OK") { _, _ ->
                if (Session.listId(this) != null) openList() else finish()
            }
            .show()
    }

    private fun openList() {
        startActivity(
            Intent(this, ShoppingList::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        finish()
    }
}