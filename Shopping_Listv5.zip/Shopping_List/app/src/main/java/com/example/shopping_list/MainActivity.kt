package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Screen 1.1 Set up.
 *
 * A name used before opens that person's list straight away, whatever
 * mix of capitals they type. Someone who was invited sees who invited
 * them, and chooses to join or not.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set-up runs once. After that the app opens straight on the list.
        if (Session.listId(this) != null) {
            openList()
            return
        }

        setContentView(R.layout.activity_main)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        nextButton = findViewById(R.id.nextButton)

        nextButton.setOnClickListener {
            val name = nameInput.text.toString()

            if (Names.key(name).isEmpty()) {
                Toast.makeText(this, "Please type your name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Stop a second tap while Firebase is checking.
            nextButton.isEnabled = false

            Accounts.find(
                name,
                onFound = { listId ->
                    if (listId == null) {
                        // A new name: carry on with set-up, step 2.
                        nextButton.isEnabled = true
                        rememberName(name)
                        Toast.makeText(this, "Welcome, ${Names.display(name)}",
                            Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, SetupSize::class.java))
                    } else {
                        // Invited and here for the first time? Ask first.
                        People.invitation(listId, name) { inviter ->
                            nextButton.isEnabled = true
                            if (inviter != null) {
                                showInvitation(listId, name, inviter)
                            } else {
                                joinList(listId, name)
                                Toast.makeText(this, "Welcome back, ${Names.display(name)}",
                                    Toast.LENGTH_SHORT).show()
                                openList()
                            }
                        }
                    }
                },
                onError = { reason ->
                    nextButton.isEnabled = true
                    Toast.makeText(this, "Could not check: $reason",
                        Toast.LENGTH_LONG).show()
                }
            )
        }
    }

    /** The invited person sees who invited them, and decides. */
    private fun showInvitation(listId: String, name: String, inviter: String) {
        val who = Names.display(name)
        AlertDialog.Builder(this)
            .setTitle("You have been invited")
            .setMessage(
                "Hi $who, $inviter has invited you to share a shopping list.\n\n" +
                        "You can add things, tick them off, and see what others add straight away."
            )
            .setCancelable(false)
            .setPositiveButton("Join the list") { _, _ ->
                joinList(listId, name)
                People.markWelcomed(listId, name)
                openList()
            }
            .setNegativeButton("No, thanks") { _, _ ->
                // Taken off the list, and the name no longer opens it.
                People.remove(listId, Person(key = Names.firebaseKey(name), name = who))
                Toast.makeText(this,
                    "You have not joined. Tap Next to set up your own list.",
                    Toast.LENGTH_LONG).show()
            }
            .show()
    }

    /** This phone now uses [listId]; set-up is skipped. */
    private fun joinList(listId: String, name: String) {
        rememberName(name)
        Session.setListId(this, listId)
        People.join(listId, name)   // already there if invited
        getSharedPreferences("shopping", MODE_PRIVATE)
            .edit().putBoolean("setupDone", true).apply()
    }

    /** userKey is for matching ("sorn"), userName is for showing ("Sorn"). */
    private fun rememberName(name: String) {
        getSharedPreferences("shopping", MODE_PRIVATE)
            .edit()
            .putString("userName", Names.display(name))
            .putString("userKey", Names.key(name))
            .apply()
    }

    private fun openList() {
        startActivity(Intent(this, ShoppingList::class.java))
        finish()
    }
}