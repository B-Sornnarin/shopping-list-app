package com.example.shopping_list

import android.content.Context
import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener

/**
 * "Regular" on Add, shared by the whole household: how many times each
 * thing has been added to the list, by anyone, on any device.
 *
 *   lists / KQZPMT / addedCounts / milk = 7
 *
 * Someone who joins the list sees the household's regular things at once.
 */
object Regulars {

    /** Added this many times or more = a regular thing. */
    private const val OFTEN = 3
    private const val TAG = "Regulars"

    private var listId: String? = null
    private var listener: ValueEventListener? = null
    private val counts = mutableMapOf<String, Long>()
    private val watchers = mutableListOf<() -> Unit>()

    private fun ref(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists").child(listId).child("addedCounts")

    /** "Sweet potato" → "sweet potato" with no characters Firebase forbids. */
    private fun key(name: String) = Names.firebaseKey(name)

    fun watch(watcher: () -> Unit) { watchers.add(watcher) }
    fun unwatch(watcher: () -> Unit) { watchers.remove(watcher) }

    /** Starts keeping the household's counts up to date. Safe to call often. */
    fun start(listId: String) {
        if (this.listId == listId && listener != null) return
        stop()
        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                counts.clear()
                for (child in snapshot.children) {
                    val n = (child.value as? Number)?.toLong() ?: continue
                    counts[child.key ?: continue] = n
                }
                watchers.toList().forEach { it() }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d(TAG, "Cannot read counts: ${error.message}")
            }
        }
        ref(listId).addValueEventListener(l)
        this.listId = listId
        listener = l
    }

    private fun stop() {
        val id = listId
        val l = listener
        if (id != null && l != null) ref(id).removeEventListener(l)
        listId = null
        listener = null
        counts.clear()
    }

    /** Counts one more for each thing just added. Safe if two people add at once. */
    fun record(listId: String, names: List<String>) {
        for (name in names) {
            if (name.isBlank()) continue
            ref(listId).child(key(name)).runTransaction(object : Transaction.Handler {
                override fun doTransaction(data: MutableData): Transaction.Result {
                    val now = (data.value as? Number)?.toLong() ?: 0L
                    data.value = now + 1
                    return Transaction.success(data)
                }

                override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {}
            })
        }
    }

    /** How many times the household has added this thing. */
    fun timesAdded(name: String): Long = counts[key(name)] ?: 0L

    /**
     * The Regular tab: things the household adds often, most first,
     * plus this device's own regular things so nothing disappears.
     */
    fun often(context: Context, library: List<LibraryItem>): List<LibraryItem> {
        val shared = library.filter { timesAdded(it.name) >= OFTEN }
        val mine = Suggestions.often(context, library)
        return (shared + mine).distinctBy { it.id }
            .sortedByDescending { timesAdded(it.name) }
    }
}