plugins {
    alias(libs.plugins.android.application)
    id("com.google.gms.google-services")
}

android {
    androidResources {
        noCompress.add("tflite")
    }
    namespace = "com.example.shopping_list"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.shopping_list"
        minSdk = 23
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        mlModelBinding = true
    }
}

dependencies {
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-database")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("com.airbnb.android:lottie:6.6.2")
    // Photo (2.1b): recognises what is in a photo, on the phone itself.
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.mlkit:image-labeling-custom:17.0.3")
    implementation("androidx.core:core-splashscreen:1.0.1")
}