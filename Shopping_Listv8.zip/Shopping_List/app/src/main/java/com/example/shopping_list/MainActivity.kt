package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen


/**
 * Screen 1.1 Set up.
 *
 * A name used before opens that person's list straight away, whatever
 * mix of capitals they type. Someone who was invited sees who invited
 * them, and chooses to join or not.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()   // the start-up screen: icon on white (must be before super.onCreate)
        super.onCreate(savedInstanceState)
        SafeArea.install(this)   // every screen keeps clear of the phone's bars (see bottom of file)

        // Set-up runs once. After that the app opens straight on the list.
        if (Session.listId(this) != null) {
            openList()
            return
        }

        setContentView(R.layout.activity_main)
        StartIntro.play(this)
        HelpGuide.attach(findViewById(R.id.helpButton), this)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        nextButton = findViewById(R.id.nextButton)

        nextButton.setOnClickListener {
            val name = nameInput.text.toString()

            if (Names.key(name).isEmpty()) {
                Toast.makeText(this, "Please type your name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Stop a second tap while Firebase is checking.
            nextButton.isEnabled = false

            Accounts.find(
                name,
                onFound = { listId ->
                    if (listId == null) {
                        // A new name: carry on with set-up, step 2.
                        nextButton.isEnabled = true
                        rememberName(name)
                        Toast.makeText(
                            this, "Welcome, ${Names.display(name)}",
                            Toast.LENGTH_SHORT
                        ).show()
                        startActivity(Intent(this, SetupSize::class.java))
                    } else {
                        // Invited and here for the first time? Ask first.
                        People.invitation(listId, name) { inviter ->
                            nextButton.isEnabled = true
                            if (inviter != null) {
                                showInvitation(listId, name, inviter)
                            } else {
                                joinList(listId, name)
                                Toast.makeText(
                                    this, "Welcome back, ${Names.display(name)}",
                                    Toast.LENGTH_SHORT
                                ).show()
                                openList()
                            }
                        }
                    }
                },
                onError = { reason ->
                    nextButton.isEnabled = true
                    Toast.makeText(
                        this, "Could not check: $reason",
                        Toast.LENGTH_LONG
                    ).show()
                }
            )
        }
    }

    /** The invited person sees who invited them, and decides. */
    private fun showInvitation(listId: String, name: String, inviter: String) {
        val who = Names.display(name)
        AlertDialog.Builder(this)
            .setTitle("You have been invited")
            .setMessage(
                "Hi $who, $inviter has invited you to share a shopping list.\n\n" +
                        "You can add things, tick them off, and see what others add straight away."
            )
            .setCancelable(false)
            .setPositiveButton("Join the list") { _, _ ->
                joinList(listId, name)
                People.markWelcomed(listId, name)
                openList()
            }
            .setNegativeButton("No, thanks") { _, _ ->
                // Taken off the list, and the name no longer opens it.
                People.remove(listId, Person(key = Names.firebaseKey(name), name = who))
                Toast.makeText(
                    this,
                    "You have not joined. Tap Next to set up your own list.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .show()
    }

    /** This phone now uses [listId]; set-up is skipped. */
    private fun joinList(listId: String, name: String) {
        rememberName(name)
        Session.setListId(this, listId)
        People.join(listId, name)   // already there if invited
        getSharedPreferences("shopping", MODE_PRIVATE)
            .edit().putBoolean("setupDone", true).apply()
    }

    /** userKey is for matching ("sorn"), userName is for showing ("Sorn"). */
    private fun rememberName(name: String) {
        getSharedPreferences("shopping", MODE_PRIVATE)
            .edit()
            .putString("userName", Names.display(name))
            .putString("userKey", Names.key(name))
            .apply()
    }

    private fun openList() {
        startActivity(Intent(this, ShoppingList::class.java))
        finish()
    }
}

/**
 * Keeps every screen clear of the phone's own bars, on every phone:
 * the status bar, the navigation bar, the camera cut-out (landscape)
 * and the keyboard. Done once here instead of in each screen.
 * Started from MainActivity, JoinLink and ShoppingList.
 */
object SafeArea {

    private var installed = false

    fun install(first: android.app.Activity) {
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(first.window, false)
        if (installed) return
        installed = true

        first.application.registerActivityLifecycleCallbacks(object : android.app.Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: android.app.Activity, savedInstanceState: Bundle?) {
                androidx.core.view.WindowCompat.setDecorFitsSystemWindows(activity.window, false)
            }

            override fun onActivityStarted(activity: android.app.Activity) {
                apply(activity)
                SettingsButton.add(activity)   // ⚙ on every screen (sponsor feedback)
            }
            override fun onActivityResumed(activity: android.app.Activity) {}
            override fun onActivityPaused(activity: android.app.Activity) {}
            override fun onActivityStopped(activity: android.app.Activity) {}
            override fun onActivitySaveInstanceState(activity: android.app.Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: android.app.Activity) {}
        })
    }

    /** Space for the status bar, navigation bar, camera cut-out and keyboard. */
    private fun apply(activity: android.app.Activity) {
        val content = activity.findViewById<android.view.View>(android.R.id.content) ?: return
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(content) { v, insets ->
            val bars = insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars() or
                        androidx.core.view.WindowInsetsCompat.Type.displayCutout()
            )
            val keyboard = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, keyboard.bottom))
            androidx.core.view.WindowInsetsCompat.CONSUMED
        }
        androidx.core.view.ViewCompat.requestApplyInsets(content)
    }
}

/**
 * Settings from every screen (sponsor feedback): the same ⚙ as on the
 * shopping list, in the top right corner of each screen.
 *
 * Added here once for the whole app, so no screen's layout changes.
 * Not on the screens that are part of setting up or of a single question
 * (set-up, invitations, All done, a suggestion, "Milk?"), and not on the
 * list (it has its own) or on Settings itself.
 */
object SettingsButton {

    private const val TAG = "settingsShortcut"

    private val notHere = setOf(
        "MainActivity", "SetupWhoElse", "JoinLink", "JoinList",
        "ShoppingList", "Settings", "AllDoneScreen", "SuggestionScreen", "CheckItem"
    )

    fun add(activity: android.app.Activity) {
        val name = activity.javaClass.simpleName
        if (name in notHere) return
        // Picture size is also step 2 of setting up: only from Settings.
        if (name == "SetupSize" && !activity.intent.getBooleanExtra("fromSettings", false)) return

        val content = activity.findViewById<android.widget.FrameLayout>(android.R.id.content) ?: return
        if (content.findViewWithTag<android.view.View>(TAG) != null) return   // already there

        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val gear = android.widget.ImageButton(activity).apply {
            tag = TAG
            setImageResource(R.drawable.ic_settings)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(android.graphics.Color.WHITE)
            }
            elevation = dp(2).toFloat()
            contentDescription = "Settings"
            setOnClickListener {
                // Back to the Settings already open, or a new one.
                val intent = android.content.Intent(activity, Settings::class.java)
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
                activity.startActivity(intent)
            }
        }
        content.addView(gear, android.widget.FrameLayout.LayoutParams(dp(48), dp(48),
            android.view.Gravity.TOP or android.view.Gravity.END).apply {
            topMargin = dp(18)
            marginEnd = dp(14)
        })
    }
}

/**
 * A short start-up animation: the Easy Shop icon grows in with a small
 * bounce, then fades into the app. Under one second, smooth even on slow
 * phones. A tap skips it. Skipped when "Remove animations" is on.
 */
object StartIntro {

    private var shown = false

    fun play(activity: android.app.Activity) {
        if (shown) return
        shown = true

        val scale = android.provider.Settings.Global.getFloat(
            activity.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f
        )
        if (scale == 0f) return

        val root = activity.window.decorView as android.view.ViewGroup
        val cover = android.widget.FrameLayout(activity).apply {
            setBackgroundColor(android.graphics.Color.WHITE)
            isClickable = true
        }
        val icon = android.widget.ImageView(activity).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleX = 0.6f
            scaleY = 0.6f
            alpha = 0f
        }
        val size = (140 * activity.resources.displayMetrics.density).toInt()
        cover.addView(icon, android.widget.FrameLayout.LayoutParams(size, size, android.view.Gravity.CENTER))
        root.addView(cover, android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.MATCH_PARENT
        ))

        var done = false
        val hide = {
            if (!done) {
                done = true
                cover.animate().alpha(0f).setDuration(250)
                    .withEndAction { root.removeView(cover) }.start()
            }
        }
        cover.setOnClickListener { hide() }

        // Grow in with a small bounce, wait a moment, then fade into the app.
        icon.animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(450)
            .setInterpolator(android.view.animation.OvershootInterpolator(1.6f))
            .withLayer()
            .withEndAction { cover.postDelayed({ hide() }, 250) }
            .start()
    }
}

/**
 * The "?" button: "How can I help?"
 *
 * Written for someone with memory problems who may be using the app alone:
 *  - the help is a list of things people want to do, in their own words;
 *  - each one opens ONE step at a time, with a small drawing of the screen
 *    (like a wireframe) where the button to tap glows orange;
 *  - "Read aloud" reads the step out loud;
 *  - "Show on screen" closes the help and points at the real button;
 *  - the first time the list opens, the app offers to show how it works.
 *
 * To change the help, change the words in `tasks` below.
 * Screens that can be drawn: "list", "add", "settings", "people", "devices", "message".
 */
object HelpGuide {

    /**
     * One step: what to do, a drawing of [screen] with [spot] glowing
     * (or a big [icon] when there is no screen to show), and the real
     * button to point at for "Show on screen".
     */
    class Step(
        val text: String,
        val screen: String? = null,
        val spot: String? = null,
        val icon: String = "",
        val showMe: Int? = null,
        val animation: Int? = null      // an animation from res/raw, played over and over
    )

    /** Something a person may want to do, said the way they would say it. */
    class Task(val icon: String, val title: String, val steps: List<Step>)

    // The icons on the "How can I help?" list, the same ones the app uses.
    // "+", "★", "✓", "✕" and "−+" are drawn like the app draws them;
    // anything else is shown as it is.
    private const val PLUS = "+"

    private val tasks = listOf(
        Task(PLUS, "Adding an item to the list", listOf(
            Step("Please tap + Add at the bottom of the shopping list.", "list", "add", showMe = R.id.addButton),
            Step("Tap the picture of the item you need. A tick will appear on it. You may select more than one item.", "add", "tiles"),
            Step("Tap Add selected. The items will be added to your shopping list.", "add", "addSelected"),
            Step("If you cannot find the picture, tap Type an item to type its name. Alternatively, tap the microphone to say it, or tap the camera to take a photograph of it.", "add", "type")
        )),
        Task("@frequency", "Adding items you buy regularly", listOf(
            Step("Please tap + Add at the bottom of the shopping list.", "list", "add", showMe = R.id.addButton),
            Step("Tap Frequency board. This shows the items you have added two or more times in the last 30 days.", "add", "frequency"),
            Step("Select the pictures of the items you require, then tap Add selected.", "add", "addSelected")
        )),
        Task("★", "Adding an item to your favourites", listOf(
            Step("There are two ways to do this. Option 1, from the shopping list: tap the picture or the name of the item.", "list", "item"),
            Step("A small menu will appear. Tap Add to favourites. A gold star will then appear next to the item.", "list", "favMenu"),
            Step("Option 2, from the Frequency board: tap + Add at the bottom of the screen, then tap Frequency board.", "add", "frequency"),
            Step("Press and hold the picture of the item until a small menu appears.", "add", "tiles"),
            Step("Tap Add to favourites. A gold star will appear on the picture.", "add", "menu")
        )),
        Task("★", "Adding all your favourites", listOf(
            Step("Please tap + Add at the bottom of the shopping list.", "list", "add", showMe = R.id.addButton),
            Step("Tap ★ Favourites.", "add", "favourites"),
            Step("Tap Add all. All of your favourite items will be added to the shopping list at once.", "add", "addAll")
        )),
        Task("✕", "Removing an item from your favourites", listOf(
            Step("There are two ways to do this. Option 1, from the shopping list: tap the picture or the name of the item.", "list", "item"),
            Step("Tap Remove from favourites. The star will disappear, and the item will remain on your shopping list.", "list", "unfavMenu"),
            Step("Option 2: tap + Add, then tap ★ Favourites. Press and hold the picture of the item until a small menu appears.", "add", "favHold"),
            Step("Tap Remove from favourites. The item will remain on the Frequency board, so you may add it to your favourites again at a later time.", "add", "favRemove")
        )),
        Task("−+", "Changing the quantity of an item", listOf(
            Step("Please find the item on your shopping list.", "list", "row"),
            Step("Tap + to increase the quantity by one. Tap − to reduce it by one.", "list", "count"),
            Step("Alternatively, tap the number and type the quantity you require.", "list", "count")
        )),
        Task("✓", "Marking an item as purchased", listOf(
            Step("Please place the item in your trolley.", icon = "🛒"),
            Step("Tap the box to the left of the item's name. The item will be marked as Done and moved to the bottom of the list.", "list", "box"),
            Step("If you have marked an item by mistake, tap the box again.", "list", "box")
        )),
        Task("@aisle", "Shopping one aisle at a time", listOf(
            Step("Above the shopping list, there is a button for each category, such as Fruit & Veg or Fridge.", "list", "chips", showMe = R.id.categoryBar),
            Step("Tap the category for the aisle you are in. Those items will move to the top of your list.", "list", "chips", showMe = R.id.categoryBar)
        )),
        Task("@bin", "Removing an item from the list", listOf(
            Step("Please tap the bin next to the name of the item.", "list", "bin"),
            Step("The bin will open, and the item will be removed from your shopping list.", animation = R.raw.bin_delete)
        )),
        Task("@people", "Sharing the list with family", listOf(
            Step("Please tap People at the bottom of the screen.", "list", "people"),
            Step("Tap + Add a person.", "people", "addPerson"),
            Step("Enter the person's name and mobile number.", "addPerson", "form"),
            Step("Tap Send link. Your messages application will open with the link ready. Tap Send.", "addPerson", "sendLink"),
            Step("Once the person opens the link, they will see the same list. Any item added by either of you will appear on both phones immediately.", icon = "📱")
        )),
        Task("@settings", "Using the list on another device", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Devices.", "settings", "devices"),
            Step("Tap + Add a device. Your phone will ask how you would like to send the link. Please choose Messages or email.", "devices", "addDevice"),
            Step("Send the link to your other phone, tablet or computer, and open it on that device. An iPhone or a computer will open the list in its web browser.", "message", "link")
        )),
        Task("@bell", "Setting a shopping reminder", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Turn on Remind me.", "settings", "remind"),
            Step("Tap − or + to choose the number of days, then choose the time. Your phone will remind you at that time.", "settings", "days")
        )),
        Task("@settings", "Turning suggestions on or off", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap the switch next to Show suggestions. When it is On, the app may suggest a related item after you add something. When it is Off, no suggestions will be shown.", "settings", "suggest")
        )),
        Task("@bell", "Receiving notifications of new items", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Turn on New item notifications. Your phone will notify you when another person adds an item to the list.", "settings", "notify"),
            Step("If your phone asks for permission to show notifications, please tap Allow.", icon = "🔔")
        )),
        Task("@settings", "Choosing how the list is grouped", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Category to group the list by type, such as Fruit & Veg. Tap None to show a single list.", "settings", "groupBy")
        )),
        Task("@settings", "Changing the picture size", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Picture size.", "settings", "pictureSize"),
            Step("Select Small, Medium or Large. The picture of Milk below will show the selected size immediately.", "size", "sizes"),
            Step("Tap Done to save your choice.", "size", "done")
        )),
        Task("@settings", "Changing a picture", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Pictures.", "settings", "pictures"),
            Step("Tap the picture you would like to change.", "pictures", "tile"),
            Step("Tap Take a photo to use your camera, or Choose a picture to select one from your phone.", "change", "choose")
        )),
        Task("@settings", "Changing the order of the categories", listOf(
            Step("The order of the categories is the order they appear on your shopping list. You may arrange them in the order in which you walk around the shop.", "list", "chips"),
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Categories.", "settings", "categories"),
            Step("There are two ways to do this. Option 1: press and hold a category, then drag it up or down to its new place.", "categories", "dragMove"),
            Step("Option 2: tap a category, for example Fridge.", "categories", "tapFridge"),
            Step("Tap Move up to move it higher, or Move down to move it lower. Repeat until it is in the right place.", "categories", "catMenu"),
            Step("The new order is saved at once, and every phone sharing the list will show the categories in this order.", "list", "chips")
        )),
        Task("@settings", "Adding a new category", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Categories.", "settings", "categories"),
            Step("Tap + Add a category, at the bottom of the screen.", "categories", "addCat"),
            Step("Type the name of the new category, for example Bakery, then tap Add.", "categories", "addCatAsk")
        )),
        Task("@settings", "Renaming a category", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Categories.", "settings", "categories"),
            Step("Tap the category you would like to rename.", "categories", "drag"),
            Step("Tap Change the name.", "categories", "catRename"),
            Step("Type the new name, then tap Save.", "categories", "renameAsk")
        )),
        Task("@settings", "Moving all items to another category", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Categories.", "settings", "categories"),
            Step("Tap the category whose items you would like to move.", "categories", "drag"),
            Step("Tap Move everything here to…", "categories", "catMoveAll"),
            Step("Select the category to move them to. Every item in the first category will move there.", "categories", "moveAllAsk")
        )),
        Task("@settings", "Deleting a category", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Categories.", "settings", "categories"),
            Step("Tap the category you would like to delete.", "categories", "drag"),
            Step("Tap Delete.", "categories", "catDelete"),
            Step("You will be asked to confirm. Tap Delete. Any items in it will move to another category, so nothing is lost.", "categories", "deleteAsk")
        )),
        Task("@aisle", "Moving an item to another category", listOf(
            Step("There are two ways to do this. Option 1: tap + Add at the bottom of the shopping list.", "list", "add", showMe = R.id.addButton),
            Step("Press and hold the picture of the item until a small menu appears.", "add", "tiles"),
            Step("Tap Move to another category. If you do not see this option, please ask the person who created the list.", "add", "moveMenu"),
            Step("Select the new category. The item will appear in that category on every phone sharing the list.", "add", "chooseGroup"),
            Step("Option 2, from Settings: tap the settings button, then tap Pictures.", "settings", "pictures"),
            Step("Press and hold the picture of the item until a small menu appears.", "pictures", "picHold"),
            Step("Tap Move to another category, then select the new category.", "pictures", "picMove")
        )),
        Task("@settings", "Renaming an item you added", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Pictures.", "settings", "pictures"),
            Step("Press and hold the picture of the item until a small menu appears.", "pictures", "ownHold"),
            Step("Tap Change the name. This option appears only for items your household added, not for the built-in items.", "pictures", "picRename"),
            Step("Type the new name, then tap Save. If the item is already on your list, its name will change there too.", "pictures", "renameItemAsk")
        )),
        Task("@settings", "Deleting an item you added", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Pictures.", "settings", "pictures"),
            Step("Press and hold the picture of the item until a small menu appears.", "pictures", "ownHold"),
            Step("Tap Delete item. The built-in items cannot be deleted.", "pictures", "picDelete"),
            Step("The item is deleted on every phone. If you made a mistake, tap Undo within 8 seconds.", "pictures", "undo")
        )),
        Task("@people", "Allowing a person to change settings", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap People.", "settings", "people"),
            Step("Turn on Can change settings for that person. They will then be able to change Pictures, Categories, People and Devices.", "people", "permission")
        )),
        Task("@back", "Logging out of this phone", listOf(
            Step("Please tap the settings button at the top right of the screen.", "list", "settings", showMe = R.id.settingsButton),
            Step("Tap Log out, at the bottom right of the screen.", "settings", "logout"),
            Step("You will be asked to confirm. Tap Log out to leave the list, or Stay to remain. Your list will not be deleted.", "settings", "logoutAsk")
        )),
        Task("@back", "Finding your way back", listOf(
            Step("Tap the back arrow at the top left of the screen. This will return you to the previous screen.", "add", "back"),
            Step("Your list is saved automatically, so no information will be lost.", icon = "💾"),
            Step("If a setting is locked, only the person who created the list, or a person they have given permission to, can change it. Please ask that person for assistance.", icon = "🔒"),
            Step("You may tap the blue ? at the top of your list at any time to view this help again.", "list", "help")
        ))
    )

    // Colours, to match the app.
    private val NAVY = 0xFF1F3864.toInt()
    private val INK = 0xFF1A1A1A.toInt()
    private val GREY = 0xFF5F5E5A.toInt()
    private val PAGE = 0xFFFFFFFF.toInt()
    private val CARD = 0xFFEEF3FA.toInt()
    private val EDGE = 0xFFC9D6E8.toInt()
    private val ORANGE = 0xFFEE9B2C.toInt()

    private var onMenu = true   // is the help showing the list (true) or a step (false)?
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false
    private var waitingToSay: String? = null

    /** Makes a view into a round "?" button that opens the help. */
    fun attach(button: android.view.View?, activity: android.app.Activity) {
        if (button == null) return
        button.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(NAVY)
        }
        button.contentDescription = "Help: instructions for using the app"
        button.setOnClickListener { show(activity) }
    }

    /** The first time only: offers to show how the app works. */
    fun welcome(activity: android.app.Activity) {
        val prefs = activity.getSharedPreferences("shopping", android.content.Context.MODE_PRIVATE)
        if (prefs.getBoolean("helpSeen", false)) return
        prefs.edit().putBoolean("helpSeen", true).apply()
        // Wait for the start-up animation to finish first.
        activity.window.decorView.postDelayed({
            if (activity.isFinishing) return@postDelayed
            android.app.AlertDialog.Builder(activity)
                .setTitle("Welcome to Easy Shop")
                .setMessage("Would you like to see how the app works?\n\n" +
                        "You may tap the blue ? at the top of the screen at any time.")
                .setPositiveButton("Yes, please") { _, _ -> show(activity) }
                .setNegativeButton("Not now", null)
                .show()
        }, 1300)
    }

    /** Opens the help on the list of things to do. */
    fun show(activity: android.app.Activity) {
        val dialog = android.app.Dialog(activity, android.R.style.Theme_Material_Light_NoActionBar)
        dialog.window?.setLayout(-1, -1)
        // The phone's Back button: from a step, back to the list; from the list, close.
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && !onMenu) {
                if (event.action == android.view.KeyEvent.ACTION_UP) showMenu(activity, dialog)
                true
            } else false
        }
        dialog.setOnDismissListener { tts?.stop() }
        showMenu(activity, dialog)
        dialog.show()
    }

    // ---------------- the list of things to do ----------------

    private fun showMenu(activity: android.app.Activity, dialog: android.app.Dialog) {
        onMenu = true
        tts?.stop()
        val page = page(activity)
        page.addView(topRow(activity, dialog, text(activity, "Help", 30f, NAVY, bold = true)))
        page.addView(text(activity, "Please select what you would like to do.", 20f, GREY, top = 4))

        val list = column(activity)
        // Short headings, so the list is easier to find your way around.
        val headings = mapOf(
            "Adding an item to the list" to "Your shopping list",
            "Using the list on another device" to "Settings",
            "Finding your way back" to "Further assistance"
        )
        for (task in tasks) {
            headings[task.title]?.let {
                list.addView(text(activity, it.uppercase(), 16f, GREY, bold = true, top = 18))
            }
            list.addView(menuButton(activity, task) {
                showStep(activity, dialog, task, 0)
            })
        }
        val scroll = android.widget.ScrollView(activity).apply { addView(list) }
        page.addView(scroll, android.widget.LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(activity, 16)
        })
        page.addView(button(activity, "Close", filled = true) { dialog.dismiss() })
        setPage(dialog, page)
    }

    // ---------------- one step at a time ----------------

    private fun showStep(activity: android.app.Activity, dialog: android.app.Dialog,
                         task: Task, index: Int) {
        onMenu = false
        tts?.stop()
        val step = task.steps[index]
        val last = index == task.steps.size - 1
        val page = page(activity)

        page.addView(topRow(activity, dialog,
            button(activity, "◀  All topics", filled = false, small = true) {
                showMenu(activity, dialog)
            }.apply {
                // Plain words, no box around them.
                background = null
                setPadding(0, paddingTop, paddingRight, paddingBottom)
            }))
        page.addView(text(activity, task.title, 26f, NAVY, bold = true, top = 12))
        page.addView(text(activity, "Step ${index + 1} of ${task.steps.size}", 20f, GREY, top = 4))

        // The step itself: a big picture and a short sentence.
        val card = column(activity).apply {
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            background = rounded(activity, CARD, EDGE)
            setPadding(dp(activity, 20), dp(activity, 20), dp(activity, 20), dp(activity, 24))
        }
        if (step.animation != null) {
            // The same bin animation the app plays (Lottie), over and over.
            card.addView(com.airbnb.lottie.LottieAnimationView(activity).apply {
                setAnimation(step.animation)
                repeatCount = android.animation.ValueAnimator.INFINITE
                playAnimation()
                contentDescription = "Animation of the bin opening"
            }, android.widget.LinearLayout.LayoutParams(dp(activity, 200), dp(activity, 200)).apply {
                gravity = android.view.Gravity.CENTER_HORIZONTAL
            })
        } else if (step.screen != null) {
            card.addView(Wire(activity, step.screen, step.spot),
                android.widget.LinearLayout.LayoutParams(-1, dp(activity, 380)))
        } else {
            card.addView(text(activity, step.icon, 72f, INK, center = true))
        }
        card.addView(stepWords(activity, step.text))
        val scroll = android.widget.ScrollView(activity).apply { addView(card) }
        page.addView(scroll, android.widget.LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(activity, 16)
        })

        page.addView(button(activity, "🔊   Read aloud", filled = false) {
            say(activity, "${task.title}. Step ${index + 1}. ${step.text}")
        })

        // Point at the real button, if it is on this screen.
        val target = step.showMe?.let { activity.findViewById<android.view.View>(it) }
        if (target != null && target.isShown) {
            page.addView(button(activity, "👆   Show on screen", filled = false) {
                dialog.dismiss()
                pointAt(target)
            })
        }

        // Back and Next, side by side.
        val row = android.widget.LinearLayout(activity).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
        }
        if (index > 0) {
            row.addView(button(activity, "◀  Back", filled = false) {
                showStep(activity, dialog, task, index - 1)
            }, android.widget.LinearLayout.LayoutParams(0, -2, 1f).apply {
                marginEnd = dp(activity, 10)
            })
        }
        row.addView(button(activity, if (last) "Done  ✓" else "Next  ▶", filled = true) {
            if (last) showMenu(activity, dialog)
            else showStep(activity, dialog, task, index + 1)
        }, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(row, android.widget.LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(activity, 6)
        })

        setPage(dialog, page)
    }

    /**
     * The top of every help page: [left] (the title, or "All topics"),
     * and the settings button on the right, as on every other screen.
     */
    private fun topRow(activity: android.app.Activity, dialog: android.app.Dialog,
                       left: android.view.View): android.view.View {
        val row = android.widget.LinearLayout(activity).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        row.addView(left, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        val pad = dp(activity, 10)
        row.addView(android.widget.ImageButton(activity).apply {
            setImageResource(R.drawable.ic_settings)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, pad)
            background = null
            contentDescription = "Settings"
            setOnClickListener {
                dialog.dismiss()
                val intent = android.content.Intent(activity, Settings::class.java)
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP)
                activity.startActivity(intent)
            }
        }, android.widget.LinearLayout.LayoutParams(dp(activity, 48), dp(activity, 48)).apply {
            marginStart = dp(activity, 8)
        })
        return row
    }

    /** Shows [page] in the help window, kept clear of the phone's bars. */
    private fun setPage(dialog: android.app.Dialog, page: android.view.View) {
        dialog.setContentView(page)
        page.post { androidx.core.view.ViewCompat.requestApplyInsets(page) }
    }

    // ---------------- how a step's words look ----------------

    /** Button names in the help. They are shown in bold navy so they are easy to spot. */
    private val buttonNames = listOf(
        "+ Add a person", "+ Add a device", "+ Add a category", "+ Add",
        "Add selected", "Add all", "Type an item", "Frequency board", "★ Favourites",
        "Add to favourites", "Remove from favourites", "Done", "People", "Send link",
        "Devices", "Remind me", "Show suggestions", "New item notifications", "Allow",
        "Category", "None", "Picture size", "Small", "Medium", "Large", "Pictures",
        "Take a photo", "Choose a picture", "Categories", "Move up", "Move down",
        "Can change settings", "Log out", "Stay", "Messages", "Option 1", "Option 2"
    ).sortedByDescending { it.length }   // longest first, so "+ Add a person" wins over "+ Add"

    /**
     * A step's words: the first sentence large and dark (what to do),
     * the rest a little smaller underneath (what happens, or another way).
     */
    private fun stepWords(activity: android.app.Activity, words: String): android.view.View {
        val parts = words.split(Regex("(?<=[.?!])\\s+"), limit = 2)
        val block = column(activity)
        block.addView(text(activity, "", 24f, INK, center = true, top = 16).apply {
            this.text = withButtonNames(parts[0])
            setLineSpacing(0f, 1.25f)
        })
        if (parts.size > 1) {
            block.addView(text(activity, "", 20f, 0xFF3A3A3A.toInt(), center = true, top = 10).apply {
                this.text = withButtonNames(parts[1])
                setLineSpacing(0f, 1.25f)
            })
        }
        return block
    }

    /** Makes every button name in [words] bold and navy. */
    private fun withButtonNames(words: String): CharSequence {
        val out = android.text.SpannableStringBuilder(words)
        val taken = BooleanArray(words.length)
        for (name in buttonNames) {
            var at = words.indexOf(name)
            while (at >= 0) {
                val end = at + name.length
                val startsWord = at == 0 || !words[at - 1].isLetterOrDigit()
                val endsWord = end == words.length || !words[end].isLetterOrDigit()
                if (startsWord && endsWord && (at until end).none { taken[it] }) {
                    for (i in at until end) taken[i] = true
                    out.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), at, end,
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    out.setSpan(android.text.style.ForegroundColorSpan(NAVY), at, end,
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                at = words.indexOf(name, at + 1)
            }
        }
        return out
    }

    // ---------------- reading aloud ----------------

    private fun say(activity: android.app.Activity, words: String) {
        // Read the words, not the pictures.
        val clean = words.replace(Regex("[^\\p{L}\\p{N}\\p{P}\\s+−]"), "")
            .replace("+", " plus ").replace("−", " minus ")
        val t = tts
        if (t != null && ttsReady) {
            t.speak(clean, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "help")
            return
        }
        waitingToSay = clean
        if (t != null) return   // still starting up; it will read when ready
        val app = activity.applicationContext
        tts = android.speech.tts.TextToSpeech(app) { status ->
            ttsReady = status == android.speech.tts.TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = java.util.Locale.getDefault()
                tts?.setSpeechRate(0.85f)   // a little slower than normal
                waitingToSay?.let { tts?.speak(it, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "help") }
            } else {
                tts = null
                android.widget.Toast.makeText(app, "Reading aloud is not available on this device.",
                    android.widget.Toast.LENGTH_LONG).show()
            }
            waitingToSay = null
        }
    }

    // ---------------- "Show me": the real button pulses ----------------

    private fun pointAt(target: android.view.View) {
        val before = target.foreground
        target.foreground = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 16f * target.resources.displayMetrics.density
            setStroke((4 * target.resources.displayMetrics.density).toInt(), ORANGE)
        }
        fun pulse(times: Int) {
            if (times == 0) {
                target.foreground = before
                return
            }
            target.animate().scaleX(1.12f).scaleY(1.12f).setDuration(300).withEndAction {
                target.animate().scaleX(1f).scaleY(1f).setDuration(300).withEndAction {
                    pulse(times - 1)
                }.start()
            }.start()
        }
        target.postDelayed({ pulse(4) }, 250)
    }

    // ---------------- building blocks ----------------

    private fun dp(activity: android.app.Activity, v: Int) =
        (v * activity.resources.displayMetrics.density).toInt()

    private fun rounded(activity: android.app.Activity, fill: Int, edge: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(activity, 16).toFloat()
            setColor(fill)
            setStroke(dp(activity, 2), edge)
        }

    private fun column(activity: android.app.Activity) = android.widget.LinearLayout(activity).apply {
        orientation = android.widget.LinearLayout.VERTICAL
    }

    /** The whole help page, kept clear of the phone's own bars. */
    private fun page(activity: android.app.Activity) = column(activity).apply {
        setBackgroundColor(PAGE)
        val pad = dp(activity, 20)
        setPadding(pad, pad, pad, pad)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
            val bars = insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars() or
                        androidx.core.view.WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(pad + bars.left, pad + bars.top, pad + bars.right, pad + bars.bottom)
            insets
        }
    }

    private fun text(activity: android.app.Activity, words: String, size: Float, color: Int,
                     bold: Boolean = false, center: Boolean = false, top: Int = 0) =
        android.widget.TextView(activity).apply {
            this.text = words
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            if (center) gravity = android.view.Gravity.CENTER_HORIZONTAL
            setLineSpacing(0f, 1.15f)
            layoutParams = android.widget.LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(activity, top)
            }
        }

    /** One line on the "How can I help?" list: the app's own icon, then the words. */
    private fun menuButton(activity: android.app.Activity, task: Task, onTap: () -> Unit) =
        android.widget.LinearLayout(activity).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(activity, 68)
            setPadding(dp(activity, 14), dp(activity, 10), dp(activity, 14), dp(activity, 10))
            background = rounded(activity, PAGE, EDGE)
            isClickable = true
            isFocusable = true
            contentDescription = task.title
            setOnClickListener { onTap() }
            layoutParams = android.widget.LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(activity, 10)
            }
            addView(menuIcon(activity, task.icon),
                android.widget.LinearLayout.LayoutParams(dp(activity, 40), dp(activity, 40)))
            addView(android.widget.TextView(activity).apply {
                this.text = task.title
                textSize = 21f
                setTextColor(NAVY)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }, android.widget.LinearLayout.LayoutParams(0, -2, 1f).apply {
                marginStart = dp(activity, 14)
            })
        }

    /** The icon for one line of the help list, drawn the same way as in the app. */
    private fun menuIcon(activity: android.app.Activity, icon: String): android.view.View {
        fun picture(res: Int, tint: Int?) = android.widget.ImageView(activity).apply {
            setImageResource(res)
            if (tint != null) setColorFilter(tint)
        }
        fun badge(word: String, fill: Int, color: Int, round: Boolean, size: Float = 22f) =
            android.widget.TextView(activity).apply {
                this.text = word
                textSize = size
                gravity = android.view.Gravity.CENTER
                includeFontPadding = false
                setTextColor(color)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                background = android.graphics.drawable.GradientDrawable().apply {
                    if (round) shape = android.graphics.drawable.GradientDrawable.OVAL
                    else cornerRadius = dp(activity, 8).toFloat()
                    setColor(fill)
                }
            }
        return when (icon) {
            PLUS -> badge("+", NAVY, PAGE, round = true, size = 26f)              // the bar's + Add
            "★" -> badge("★", PAGE, 0xFFE0A800.toInt(), round = true, size = 30f) // the gold star
            "✕" -> badge("✕", 0xFFB3261E.toInt(), PAGE, round = true)             // remove_circle
            "✓" -> badge("✓", 0xFF2E7D32.toInt(), PAGE, round = false)            // a ticked box
            "−+" -> badge("–+", CARD, NAVY, round = false, size = 20f)            // – number +
            "@frequency" -> badge("2×", CARD, NAVY, round = false, size = 18f)
            "@aisle" -> badge("▤", CARD, NAVY, round = false)
            "@bin" -> picture(R.drawable.ic_bin, null)
            "@people" -> picture(R.drawable.ic_bar_people, null)
            "@settings" -> picture(R.drawable.ic_settings, null)
            "@bell" -> picture(R.drawable.ic_notify, NAVY)
            "@back" -> picture(R.drawable.ic_back, null)
            else -> text(activity, icon, 26f, INK, center = true)
        }
    }

    /** A big, easy-to-hit button: at least 64dp tall, large text. */
    private fun button(activity: android.app.Activity, label: String, filled: Boolean,
                       small: Boolean = false, onTap: () -> Unit) =
        android.widget.TextView(activity).apply {
            this.text = label
            textSize = if (small) 18f else 21f
            setTextColor(if (filled) PAGE else NAVY)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = if (filled) android.view.Gravity.CENTER
            else android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.START
            minHeight = dp(activity, if (small) 48 else 64)
            setPadding(dp(activity, 18), dp(activity, 10), dp(activity, 18), dp(activity, 10))
            background = if (filled) rounded(activity, NAVY, NAVY) else rounded(activity, PAGE, EDGE)
            isClickable = true
            isFocusable = true
            setOnClickListener { onTap() }
            layoutParams = android.widget.LinearLayout.LayoutParams(
                if (small) -2 else -1, -2
            ).apply { topMargin = dp(activity, 10) }
        }

    // ---------------- the screen drawings (wireframes) ----------------

    /**
     * A small drawing of one screen of the app, like a wireframe.
     * The part to tap ([spot]) glows orange and a finger points at it.
     * Sizes are in % of the drawn phone, so it fits any screen.
     */
    private class Wire(context: android.content.Context, val screen: String, val spot: String?) :
        android.view.View(context) {

        private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val d = resources.displayMetrics.density
        private var glow = 0f
        private var target: android.graphics.RectF? = null
        private var px = 0f
        private var py = 0f
        private var pw = 0f
        private var ph = 0f

        private val NAVY = 0xFF1F3864.toInt()
        private val LINE = 0xFFB8C4D6.toInt()
        private val SOFT = 0xFFF4F6FA.toInt()
        private val GREY = 0xFF6B7280.toInt()
        private val GREEN = 0xFF2E7D32.toInt()
        private val PALE_GREEN = 0xFFE8F5E9.toInt()
        private val ORANGE = 0xFFEE9B2C.toInt()
        private val WHITE = 0xFFFFFFFF.toInt()
        private val RED = 0xFFB3261E.toInt()
        private val GOLD = 0xFFE0A800.toInt()
        private val INK_DARK = 0xFF1A1A1A.toInt()
        private val OUTLINE = 0xFF595959.toInt()       // button_outline.xml
        private val CARD_EDGE = 0xFFC8C8C8.toInt()     // setting_card.xml, more_tile.xml
        private val PALE_BLUE = 0xFFEAF4FB.toInt()     // button_selected.xml
        private val LIGHT_BLUE = 0xFF87CDEB.toInt()    // button_primary.xml
        private val TILE = 0xFFF0F3F8.toInt()          // picture_tile.xml
        private val DONE_FILL = 0xFFC9E7BE.toInt()     // row_done.xml
        private val DONE_EDGE = 0xFF4C9A3F.toInt()
        private val HERE = 0xFFE3EAF6.toInt()          // bottom bar: "you are here"
        private val BAR_LINE = 0xFFD5DAE3.toInt()

        private val pulse = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            addUpdateListener { glow = it.animatedValue as Float; invalidate() }
        }

        init {
            contentDescription = "Drawing of the screen. The area to tap is highlighted in orange."
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            if (spot != null) pulse.start()
        }

        override fun onDetachedFromWindow() {
            pulse.cancel()
            super.onDetachedFromWindow()
        }

        // ---- drawing helpers: x and y are % of the phone ----
        private fun x(v: Float) = px + pw * v / 100f
        private fun y(v: Float) = py + ph * v / 100f

        private fun box(c: android.graphics.Canvas, l: Float, t: Float, r: Float, b: Float,
                        fill: Int?, stroke: Int? = LINE, round: Float = 3f, key: String? = null) {
            val rect = android.graphics.RectF(x(l), y(t), x(r), y(b))
            val rad = pw * round / 100f
            if (fill != null) {
                p.style = android.graphics.Paint.Style.FILL; p.color = fill
                c.drawRoundRect(rect, rad, rad, p)
            }
            if (stroke != null) {
                p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = stroke
                c.drawRoundRect(rect, rad, rad, p)
            }
            if (key != null && key == spot) target = rect
        }

        private fun mark(key: String, l: Float, t: Float, r: Float, b: Float) {
            if (key == spot) target = android.graphics.RectF(x(l), y(t), x(r), y(b))
        }

        private fun word(c: android.graphics.Canvas, s: String, at: Float, base: Float, size: Float,
                         color: Int = NAVY, bold: Boolean = false,
                         align: android.graphics.Paint.Align = android.graphics.Paint.Align.LEFT,
                         maxWidth: Float = 0f) {
            p.style = android.graphics.Paint.Style.FILL
            p.color = color
            p.textSize = pw * size / 100f
            p.isFakeBoldText = bold
            p.textAlign = align
            // Too long for its button? Make it a little smaller, so every letter shows.
            if (maxWidth > 0f) {
                val room = pw * maxWidth / 100f
                val need = p.measureText(s)
                if (need > room) p.textSize = p.textSize * room / need
            }
            c.drawText(s, x(at), y(base), p)
            p.isFakeBoldText = false
            p.textAlign = android.graphics.Paint.Align.LEFT
        }

        /**
         * One of the app's own icons (res/drawable), fitted square in the box.
         * [tint] = one colour for it, as the bottom bar does; null = its own colours.
         */
        private fun icon(c: android.graphics.Canvas, res: Int, l: Float, t: Float, r: Float, b: Float,
                         tint: Int? = null, key: String? = null) {
            val picture = context.getDrawable(res)?.mutate() ?: return
            val size = minOf(x(r) - x(l), y(b) - y(t))
            val cx = (x(l) + x(r)) / 2f
            val cy = (y(t) + y(b)) / 2f
            picture.setBounds((cx - size / 2).toInt(), (cy - size / 2).toInt(),
                (cx + size / 2).toInt(), (cy + size / 2).toInt())
            if (tint != null) picture.setTint(tint)
            picture.draw(c)
            if (key != null && key == spot) target = android.graphics.RectF(x(l), y(t), x(r), y(b))
        }

        /** An On/Off switch like the app's: green with "On", or grey with "Off". */
        private fun switch(c: android.graphics.Canvas, on: Boolean, l: Float, t: Float, r: Float, b: Float,
                           key: String? = null) {
            box(c, l, t, r, b, if (on) GREEN else 0xFF616161.toInt(), null, 50f, key = key)
            dot(c, if (on) r - 4f else l + 4f, (t + b) / 2f, 3f, WHITE)
            word(c, if (on) "On" else "Off", if (on) l + 5.5f else r - 6f, b - 1.2f, 3f, WHITE, true,
                android.graphics.Paint.Align.CENTER)
        }

        /** A round shape that stays round whatever the size of the drawing. */
        private fun dot(c: android.graphics.Canvas, cxPct: Float, cyPct: Float, radiusPct: Float, fill: Int) {
            p.style = android.graphics.Paint.Style.FILL
            p.color = fill
            c.drawCircle(x(cxPct), y(cyPct), pw * radiusPct / 100f, p)
        }

        /** The back arrow (ic_back) and title at the top of most screens. */
        private fun header(c: android.graphics.Canvas, title: String) {
            icon(c, R.drawable.ic_back, 3f, 2.5f, 15f, 10f, key = "back")
            word(c, title, 18f, 8.5f, 8f, NAVY, true, maxWidth = 66f)
            // The settings button, top right, as on every screen except Settings itself.
            if (title != "Settings") icon(c, R.drawable.ic_settings, 87.5f, 4.2f, 95f, 8.2f, key = "settings")
        }

        override fun onDraw(c: android.graphics.Canvas) {
            super.onDraw(c)
            // The phone: tall, centred, with room around it for the glow.
            ph = height - 24 * d
            pw = ph * 0.56f
            if (pw > width - 24 * d) { pw = width - 24 * d; ph = pw / 0.56f }
            px = (width - pw) / 2f
            py = (height - ph) / 2f
            target = null

            box(c, 0f, 0f, 100f, 100f, WHITE, 0xFF1A1A1A.toInt(), 7f)
            when (screen) {
                "list" -> list(c)
                "add" -> add(c)
                "settings" -> settings(c)
                "people" -> people(c)
                "devices" -> devices(c)
                "message" -> message(c)
                "size" -> size(c)
                "pictures" -> pictures(c)
                "change" -> change(c)
                "categories" -> categories(c)
                "addPerson" -> addPerson(c)
            }

            // The glowing ring and the pointing finger.
            target?.let { r ->
                val grow = (3 + glow * 4) * d
                p.style = android.graphics.Paint.Style.STROKE
                p.strokeWidth = 3.5f * d
                p.color = ORANGE
                p.alpha = (160 + glow * 95).toInt()
                c.drawRoundRect(r.left - grow, r.top - grow, r.right + grow, r.bottom + grow,
                    10 * d, 10 * d, p)
                p.alpha = 255
                p.style = android.graphics.Paint.Style.FILL
                p.textSize = 30 * d
                p.textAlign = android.graphics.Paint.Align.CENTER
                val fx = minOf(r.right, px + pw - 4 * d)
                val fy = minOf(r.bottom + 30 * d + glow * 6 * d, height - 2 * d)
                c.drawText("👆", fx, fy, p)
                p.textAlign = android.graphics.Paint.Align.LEFT
            }
        }

        /** The shopping list. */
        private fun list(c: android.graphics.Canvas) {
            word(c, "Shopping list", 5f, 8.5f, 8f, NAVY, true)
            // ? and settings: small and level with the title, as on the real screen.
            dot(c, 81f, 6.2f, 3f, NAVY)
            word(c, "?", 81f, 7.4f, 3.8f, WHITE, true, android.graphics.Paint.Align.CENTER)
            mark("help", 77.5f, 4.3f, 84.5f, 8.1f)
            icon(c, R.drawable.ic_settings, 87.5f, 4.2f, 95f, 8.2f, key = "settings")

            // The aisle buttons
            box(c, 4f, 13f, 36f, 19f, SOFT, NAVY, 50f)
            word(c, "Fruit & veg · 2", 20f, 17.3f, 4.6f, NAVY, true, android.graphics.Paint.Align.CENTER, maxWidth = 29f)
            box(c, 39f, 13f, 62f, 19f, SOFT, LINE, 50f)
            word(c, "Fridge · 1", 50.5f, 17.3f, 4.6f, NAVY, true, android.graphics.Paint.Align.CENTER, maxWidth = 20f)
            box(c, 65f, 13f, 92f, 19f, SOFT, LINE, 50f)
            word(c, "Bakery · 1", 78.5f, 17.3f, 4.6f, NAVY, true, android.graphics.Paint.Align.CENTER, maxWidth = 24f)
            mark("chips", 4f, 13f, 92f, 19f)

            // One row, as in row_item.xml: tick box, picture, name and bin, then – number +.
            fun row(top: Float, emoji: String, name: String, count: String, done: Boolean, first: Boolean) {
                box(c, 3f, top, 97f, top + 16f, if (done) DONE_FILL else WHITE,
                    if (done) DONE_EDGE else LINE, 4f, key = if (first) "row" else null)
                box(c, 6f, top + 5.5f, 14f, top + 10f, if (done) GREEN else WHITE,
                    if (done) GREEN else 0xFF49454F.toInt(), 1.5f, key = if (first) "box" else null)
                if (done) word(c, "✓", 10f, top + 9.2f, 5f, WHITE, true, android.graphics.Paint.Align.CENTER)
                box(c, 17f, top + 3.5f, 31f, top + 11.5f, TILE, null, 4f)      // picture_tile
                word(c, emoji, 24f, top + 9.3f, 7.5f, NAVY, false, android.graphics.Paint.Align.CENTER)
                word(c, name, 34f, top + 6.5f, 5.5f, if (done) GREEN else NAVY, true)
                if (first) mark("item", 16f, top + 2.5f, 62f, top + 12.5f)
                if (first && (spot == "favMenu" || spot == "unfavMenu")) {
                    word(c, "★", 55f, top + 6.5f, 5.5f, GOLD, true)
                }
                icon(c, R.drawable.ic_bin, 82f, top + 1.5f, 93f, top + 8.5f,
                    key = if (first) "bin" else null)
                if (done) {
                    word(c, "Done", 34f, top + 12.5f, 4.5f, GREEN)
                } else {
                    box(c, 34f, top + 8.8f, 42f, top + 14f, WHITE, LINE, 2f)
                    word(c, "–", 38f, top + 12.8f, 5f, NAVY, true, android.graphics.Paint.Align.CENTER)
                    word(c, count, 47.5f, top + 12.8f, 5f, NAVY, true, android.graphics.Paint.Align.CENTER)
                    box(c, 53f, top + 8.8f, 61f, top + 14f, WHITE, LINE, 2f)
                    word(c, "+", 57f, top + 12.8f, 5f, NAVY, true, android.graphics.Paint.Align.CENTER)
                    if (first) mark("count", 34f, top + 8.8f, 61f, top + 14f)
                }
            }
            row(23f, "🍎", "Apple", "5", done = false, first = true)
            row(42f, "🥛", "Milk", "2", done = false, first = false)
            row(61f, "🍌", "Banana", "1", done = true, first = false)

            // The bottom bar (BottomBar.kt): Home, + Add, People.
            box(c, 0f, 86f, 100f, 86.3f, BAR_LINE, null, 0f)
            box(c, 5f, 87.2f, 31f, 99f, HERE, null, 6f)                      // "you are here"
            icon(c, R.drawable.ic_bar_home, 12f, 87.8f, 24f, 93.8f, tint = NAVY)
            word(c, "Home", 18f, 97.6f, 4.2f, NAVY, true, android.graphics.Paint.Align.CENTER)
            dot(c, 50f, 91f, 6.5f, NAVY)
            word(c, "+", 50f, 93.1f, 8f, WHITE, true, android.graphics.Paint.Align.CENTER)
            word(c, "Add", 50f, 97.6f, 4.2f, GREY, false, android.graphics.Paint.Align.CENTER)
            mark("add", 38f, 87f, 62f, 99.2f)
            icon(c, R.drawable.ic_bar_people, 76f, 87.8f, 88f, 93.8f, tint = GREY)
            word(c, "People", 82f, 97.6f, 4.2f, GREY, false, android.graphics.Paint.Align.CENTER)
            mark("people", 70f, 87f, 94f, 99.2f)

            // The small menu that opens when you tap a thing's picture or name.
            if (spot == "favMenu" || spot == "unfavMenu") {
                val removing = spot == "unfavMenu"
                box(c, 0f, 0f, 100f, 100f, 0x66000000, null, 7f)
                box(c, 3f, 23f, 97f, 39f, WHITE, NAVY, 4f)
                box(c, 17f, 26.5f, 31f, 34.5f, TILE, null, 4f)
                word(c, "🍎", 24f, 32.3f, 7.5f, NAVY, false, android.graphics.Paint.Align.CENTER)
                word(c, "Apple", 34f, 31.5f, 5.5f, NAVY, true)
                box(c, 12f, 44f, 88f, 62f, WHITE, NAVY, 4f)
                word(c, if (removing) "Remove from favourites" else "★  Add to favourites",
                    50f, 51f, 5f, if (removing) RED else NAVY, true, android.graphics.Paint.Align.CENTER)
                box(c, 16f, 54f, 84f, 54.3f, LINE, null, 0f)
                word(c, "Cancel", 50f, 59.5f, 4.6f, GREY, false, android.graphics.Paint.Align.CENTER)
                mark(if (removing) "unfavMenu" else "favMenu", 14f, 45.5f, 86f, 53f)
            }
        }

        /** The Add screen. */
        private fun add(c: android.graphics.Canvas) {
            header(c, "Add")
            box(c, 4f, 13f, 96f, 21f, WHITE, LINE, 50f, key = "type")
            word(c, "Type an item", 9f, 18.4f, 5f, GREY)
            icon(c, android.R.drawable.ic_btn_speak_now, 68f, 13.8f, 79f, 20.2f)   // microphone
            icon(c, R.drawable.ic_camera, 81f, 14.3f, 92f, 19.7f)                   // camera
            word(c, "Or tap a picture", 4f, 28f, 5f, NAVY, true)

            val favourites = spot in listOf("favourites", "addAll", "favHold", "favRemove")
            box(c, 4f, 31f, 48f, 37.5f, if (favourites) WHITE else NAVY, NAVY, 50f, key = "frequency")
            word(c, "Frequency board", 26f, 35.5f, 4.4f, if (favourites) NAVY else WHITE, true,
                android.graphics.Paint.Align.CENTER, maxWidth = 40f)
            box(c, 52f, 31f, 96f, 37.5f, if (favourites) NAVY else WHITE, NAVY, 50f, key = "favourites")
            word(c, "★ Favourites", 74f, 35.5f, 4.4f, if (favourites) WHITE else NAVY, true,
                android.graphics.Paint.Align.CENTER, maxWidth = 40f)

            val things = listOf("🥛" to "Milk", "🍎" to "Apple", "🥚" to "Eggs",
                "🍞" to "Bread", "🧼" to "Soap", "🥦" to "Broccoli")
            for ((i, t) in things.withIndex()) {
                val l = 4f + (i % 3) * 32f
                val top = 41f + (i / 3) * 22f
                val chosen = i == 1 && !favourites && spot !in listOf("menu", "moveMenu", "chooseGroup")
                box(c, l, top, l + 28f, top + 16f, WHITE, if (chosen) NAVY else LINE, 4f,
                    key = if (i == 1) (if (favourites) "favHold" else "tiles") else null)
                word(c, t.first, l + 14f, top + 11.5f, 9f, NAVY, false, android.graphics.Paint.Align.CENTER)
                word(c, t.second, l + 14f, top + 20f, 4.2f, NAVY, false, android.graphics.Paint.Align.CENTER)
                if (chosen) {
                    dot(c, l + 23f, top + 12.5f, 3.6f, GREEN)                       // tick_circle
                    word(c, "✓", l + 23f, top + 13.9f, 4.4f, WHITE, true, android.graphics.Paint.Align.CENTER)
                }
                if (favourites || (spot == "menu" && i == 1)) {
                    word(c, "★", l + 4.5f, top + 5.5f, 5.5f, GOLD, true, android.graphics.Paint.Align.CENTER)
                }
            }

            if (spot == "moveMenu") {
                box(c, 0f, 0f, 100f, 100f, 0x66000000, null, 7f)
                box(c, 10f, 50f, 90f, 72f, WHITE, NAVY, 4f)
                word(c, "★ Add to favourites", 50f, 56f, 4.8f, NAVY, true, android.graphics.Paint.Align.CENTER)
                word(c, "Move to another category", 50f, 63f, 4.8f, NAVY, true, android.graphics.Paint.Align.CENTER)
                word(c, "Cancel", 50f, 69.5f, 4.5f, INK_DARK, false, android.graphics.Paint.Align.CENTER)
                mark("moveMenu", 12f, 58.8f, 88f, 64.8f)
            }
            if (spot == "chooseGroup") {
                box(c, 0f, 0f, 100f, 100f, 0x66000000, null, 7f)
                box(c, 6f, 24f, 94f, 80f, WHITE, null, 5f)
                word(c, "Which category for Apple?", 11f, 31.5f, 4.8f, INK_DARK, true)
                val groups = listOf("Fruit & Veg", "Fridge", "Bakery", "Frozen", "Other")
                for ((i, g) in groups.withIndex()) {
                    val y0 = 35f + i * 7.4f
                    val on = i == 0
                    dot(c, 15f, y0 + 2.6f, 2.6f, if (on) NAVY else GREY)
                    dot(c, 15f, y0 + 2.6f, 1.7f, WHITE)
                    if (on) dot(c, 15f, y0 + 2.6f, 1.1f, NAVY)
                    word(c, g, 22f, y0 + 4f, 4.4f, INK_DARK)
                }
                mark("chooseGroup", 9f, 41.8f, 91f, 72f)
                word(c, "CANCEL", 88f, 77.5f, 4.2f, NAVY, true, android.graphics.Paint.Align.RIGHT)
            }
            if (spot == "menu" || spot == "favRemove") {
                val removing = spot == "favRemove"
                box(c, 10f, 50f, 90f, 64f, WHITE, NAVY, 4f)
                word(c, if (removing) "Remove from favourites" else "★ Add to favourites", 50f, 56f, 5f,
                    if (removing) RED else NAVY, true, android.graphics.Paint.Align.CENTER)
                word(c, "Cancel", 50f, 62f, 4.5f, GREY, false, android.graphics.Paint.Align.CENTER)
                mark(if (removing) "favRemove" else "menu", 12f, 51.5f, 88f, 57.5f)
            }

            val label = if (favourites) "Add all" else "Add selected"
            box(c, 4f, 88f, 96f, 96f, NAVY, null, 50f, key = if (favourites) "addAll" else "addSelected")
            word(c, label, 50f, 93.4f, 5.5f, WHITE, true, android.graphics.Paint.Align.CENTER)
        }

        /** Settings, laid out like the real Settings screen. */
        private fun settings(c: android.graphics.Canvas) {
            header(c, "Settings")
            val left = android.graphics.Paint.Align.LEFT
            val middle = android.graphics.Paint.Align.CENTER

            word(c, "REMINDERS AND SUGGESTIONS", 4f, 14f, 3.4f, NAVY, true, left)
            box(c, 4f, 15.5f, 96f, 36.5f, WHITE, LINE, 3f)
            word(c, "Remind me", 8f, 20.8f, 4.4f, INK_DARK, false, left)
            switch(c, true, 72f, 17f, 92f, 23f, key = "remind")
            word(c, "After", 8f, 28f, 4f, GREY, false, left)
            box(c, 22f, 24.8f, 31f, 30f, WHITE, INK_DARK, 2f)
            word(c, "–", 26.5f, 28.4f, 4.4f, INK_DARK, true, middle)
            box(c, 34f, 24.8f, 79f, 30f, WHITE, INK_DARK, 2f)
            word(c, "7 days", 56.5f, 28.4f, 4.6f, INK_DARK, true, middle)
            box(c, 82f, 24.8f, 91f, 30f, WHITE, INK_DARK, 2f)
            word(c, "+", 86.5f, 28.4f, 4.4f, INK_DARK, true, middle)
            word(c, "At", 8f, 34f, 4f, GREY, false, left)
            box(c, 22f, 31.2f, 46f, 35.6f, WHITE, INK_DARK, 2.5f)
            word(c, "10:00 am", 34f, 34.3f, 3.8f, NAVY, true, middle)
            mark("days", 6f, 24.3f, 92f, 36f)

            box(c, 4f, 38f, 96f, 44.5f, WHITE, LINE, 3f)
            word(c, "Show suggestions", 8f, 42.4f, 4.4f, INK_DARK, false, left)
            switch(c, true, 72f, 39.3f, 92f, 43.2f, key = "suggest")
            box(c, 4f, 46f, 96f, 52.5f, WHITE, LINE, 3f)
            word(c, "New item notifications", 8f, 50.4f, 4.4f, INK_DARK, false, left)
            switch(c, false, 72f, 47.3f, 92f, 51.2f, key = "notify")

            word(c, "LIST DISPLAY", 4f, 56.8f, 3.4f, NAVY, true, left)
            word(c, "Group items by", 4f, 60.6f, 3.8f, INK_DARK, false, left)
            box(c, 4f, 62.5f, 49f, 69f, 0xFFE8F0FA.toInt(), NAVY, 3f)
            word(c, "Category", 26.5f, 66.8f, 4.2f, NAVY, true, middle)
            box(c, 51f, 62.5f, 96f, 69f, WHITE, INK_DARK, 3f)
            word(c, "None", 73.5f, 66.8f, 4.2f, INK_DARK, false, middle)
            mark("groupBy", 4f, 62.5f, 96f, 69f)

            word(c, "MORE SETTINGS", 4f, 73.6f, 3.4f, NAVY, true, left)
            val cells = listOf("Picture size", "Pictures", "Categories", "People", "Devices", "Log out")
            for ((i, name) in cells.withIndex()) {
                val l = if (i % 2 == 0) 4f else 51f
                val t = 75.5f + (i / 2) * 7.8f
                val key = when (name) {
                    "Picture size" -> "pictureSize"
                    "Log out" -> "logout"
                    else -> name.lowercase()      // pictures, categories, people, devices
                }
                box(c, l, t, l + 45f, t + 6.5f, WHITE, LINE, 3f, key = key)
                word(c, name, l + 3.5f, t + 4.4f, 4f,
                    if (name == "Log out") RED else INK_DARK, name == "Log out", left)
                word(c, "›", l + 41f, t + 4.6f, 5.5f, INK_DARK, true, middle)
            }

            // "Log out?" asks first.
            if (spot == "logoutAsk") {
                box(c, 0f, 0f, 100f, 100f, 0x66000000, null, 7f)
                box(c, 8f, 36f, 92f, 62f, WHITE, null, 5f)
                word(c, "Log out?", 14f, 43f, 5.5f, INK_DARK, true, left)
                word(c, "This phone will leave the", 14f, 48.5f, 4f, GREY, false, left)
                word(c, "shopping list. The list is not deleted.", 14f, 52.5f, 4f, GREY, false, left)
                word(c, "STAY", 58f, 59f, 4.4f, NAVY, true, middle)
                word(c, "LOG OUT", 79f, 59f, 4.4f, NAVY, true, middle)
                mark("logoutAsk", 50f, 55.2f, 90f, 60.8f)
            }
        }

        /** People, as in activity_people.xml and row_person.xml. */
        private fun people(c: android.graphics.Canvas) {
            header(c, "People")
            val people = listOf("Anna", "Sorn")
            for ((i, name) in people.withIndex()) {
                val top = 13f + i * 23f
                box(c, 4f, top, 96f, top + 21f, WHITE, CARD_EDGE, 3f)                // setting_card
                icon(c, if (i == 0) R.drawable.avatar_filled else R.drawable.avatar_outline,
                    6f, top + 1.5f, 19f, top + 9f)
                word(c, name.take(1), 12.5f, top + 6.8f, 5f, if (i == 0) WHITE else NAVY, true,
                    android.graphics.Paint.Align.CENTER)
                word(c, name, 22f, top + 5f, 5f, INK_DARK, true)
                word(c, if (i == 0) "Uses the list · Can change settings" else "Uses the list",
                    22f, top + 8.6f, 3.6f, GREY)
                word(c, "Can change settings", 7f, top + 14f, 3.8f, GREY)
                val on = i == 0            // Sorn's switch is Off: that is the one to tap
                switch(c, on, 74f, top + 11.5f, 93f, top + 15.5f, key = if (i == 1) "permission" else null)
                if (i == 1) word(c, "Remove", 7f, top + 19.4f, 3.8f, RED, false)
            }
            box(c, 4f, 61f, 96f, 68f, WHITE, OUTLINE, 3f, key = "addPerson")      // button_outline
            word(c, "+  Add a person", 50f, 65.8f, 4.8f, INK_DARK, false, android.graphics.Paint.Align.CENTER)
        }

        /** Add a person: their name and mobile, then Send link. */
        private fun addPerson(c: android.graphics.Canvas) {
            header(c, "Add a person")
            word(c, "Name", 4f, 17f, 4.2f, INK_DARK, true)
            box(c, 4f, 18.5f, 96f, 25.5f, WHITE, OUTLINE, 3f)
            word(c, "Anna", 8f, 23.2f, 4.6f, INK_DARK)
            word(c, "Mobile", 4f, 31f, 4.2f, INK_DARK, true)
            box(c, 4f, 32.5f, 96f, 39.5f, WHITE, OUTLINE, 3f)
            word(c, "0400 000 000", 8f, 37.2f, 4.6f, INK_DARK)
            mark("form", 3f, 14f, 97f, 40f)
            box(c, 4f, 44f, 96f, 51f, LIGHT_BLUE, NAVY, 3f, key = "sendLink")     // button_primary
            word(c, "Send link", 50f, 48.8f, 5f, NAVY, true, android.graphics.Paint.Align.CENTER)
        }

        /** Picture size, as in activity_setup_size.xml (opened from Settings). */
        private fun size(c: android.graphics.Canvas) {
            header(c, "Picture size")
            word(c, "How big should the pictures be?", 4f, 17f, 4.2f, INK_DARK)
            // Three buttons side by side; the chosen one is pale blue with a navy edge.
            for ((i, name) in listOf("Small", "Medium", "Large").withIndex()) {
                val l = 4f + i * 31.3f
                val chosen = i == 1
                box(c, l, 21f, l + 29.4f, 29f, if (chosen) PALE_BLUE else WHITE,
                    if (chosen) NAVY else OUTLINE, 3f)
                word(c, name, l + 14.7f, 26f, 4.2f, if (chosen) NAVY else INK_DARK, chosen,
                    android.graphics.Paint.Align.CENTER)
            }
            mark("sizes", 4f, 21f, 96f, 29f)
            // Preview: a tick box, the Milk picture and the word Milk, as on the list.
            word(c, "Preview", 4f, 35.5f, 3.8f, GREY)
            box(c, 14f, 42f, 21f, 46.5f, WHITE, 0xFF49454F.toInt(), 1.5f)
            box(c, 26f, 39f, 46f, 50f, TILE, null, 4f)
            word(c, "🥛", 36f, 47.6f, 10f, NAVY, false, android.graphics.Paint.Align.CENTER)
            word(c, "Milk", 51f, 46.6f, 5.5f, INK_DARK, true)
            // Done, a navy button at the bottom.
            box(c, 4f, 88f, 96f, 96f, NAVY, null, 50f, key = "done")
            word(c, "Done", 50f, 93.4f, 5.2f, WHITE, true, android.graphics.Paint.Align.CENTER)
        }

        /** Pictures, as in activity_pictures_screen.xml, with its press-and-hold menu. */
        private fun pictures(c: android.graphics.Canvas) {
            header(c, "Pictures")
            word(c, "Tap a picture to change it. Press", 4f, 16f, 4f, INK_DARK)
            word(c, "and hold to delete.", 4f, 19.6f, 4f, INK_DARK)

            // For rename and delete, the first one is the household's own thing,
            // which has no picture yet, so its first letter is shown.
            val own = spot in listOf("ownHold", "picRename", "picDelete", "renameItemAsk", "undo")
            val things = listOf(
                (if (own) "T" else "🍎") to (if (own) "Tahini" else "Apple"),
                "🥛" to "Milk", "🥚" to "Eggs", "🍞" to "Bread", "🧼" to "Soap", "🥦" to "Broccoli"
            )
            for ((i, t) in things.withIndex()) {
                if (spot == "undo" && i == 0) continue          // just deleted
                val l = 4f + (i % 3) * 32f
                val top = 23f + (i / 3) * 22f
                box(c, l, top, l + 28f, top + 16f, TILE, null, 4f,
                    key = if (i == 0) (if (own) "ownHold" else "picHold") else null)
                if (i == 0 && own) {
                    word(c, t.first, l + 14f, top + 11.2f, 9f, NAVY, true, android.graphics.Paint.Align.CENTER)
                } else {
                    word(c, t.first, l + 14f, top + 11.5f, 9f, NAVY, false, android.graphics.Paint.Align.CENTER)
                }
                word(c, t.second, l + 14f, top + 20f, 4.2f, INK_DARK, false, android.graphics.Paint.Align.CENTER)
                if (i == 0) mark("tile", l, top, l + 28f, top + 16f)
            }

            // Press and hold: the menu, as on the real screen.
            if (spot in listOf("picMove", "picRename", "picDelete")) {
                box(c, 0f, 0f, 100f, 100f, 0x66000000, null, 7f)
                val rows = if (own) listOf("Change the name", "Move to another category", "Delete item", "Cancel")
                else listOf("Move to another category", "Built in, can't be deleted", "Cancel")
                val top = 48f
                box(c, 8f, top, 92f, top + 4f + rows.size * 7f, WHITE, NAVY, 4f)
                for ((i, r) in rows.withIndex()) {
                    val y0 = top + 2f + i * 7f
                    val colour = when (r) {
                        "Delete item" -> RED
                        "Built in, can't be deleted" -> 0xFF8A93A3.toInt()
                        "Cancel" -> INK_DARK
                        else -> NAVY
                    }
                    word(c, r, 50f, y0 + 5f, 4.6f, colour, r != "Cancel", android.graphics.Paint.Align.CENTER)
                    val key = when (r) {
                        "Change the name" -> "picRename"
                        "Move to another category" -> "picMove"
                        "Delete item" -> "picDelete"
                        else -> null
                    }
                    if (key != null) mark(key, 10f, y0, 90f, y0 + 7f)
                }
            }

            // Change the name: type it, then Save.
            if (spot == "renameItemAsk") {
                box(c, 0f, 0f, 100f, 100f, 0x66000000, null, 7f)
                box(c, 6f, 32f, 94f, 62f, WHITE, null, 5f)
                word(c, "Change the name", 12f, 39.5f, 5.4f, INK_DARK, true)
                box(c, 12f, 43f, 88f, 50f, WHITE, NAVY, 2f)
                word(c, "Tahini", 15f, 47.8f, 4.4f, INK_DARK)
                word(c, "CANCEL", 66f, 58.5f, 4.2f, NAVY, true, android.graphics.Paint.Align.RIGHT)
                word(c, "SAVE", 88f, 58.5f, 4.2f, NAVY, true, android.graphics.Paint.Align.RIGHT)
                mark("renameItemAsk", 10f, 42f, 91f, 60f)
            }

            // Deleted, with 8 seconds to Undo, at the bottom of the screen.
            if (spot == "undo") {
                box(c, 4f, 86f, 96f, 96f, 0xFF323232.toInt(), null, 3f)
                word(c, "Tahini deleted", 9f, 92.2f, 4.4f, WHITE)
                word(c, "UNDO", 90f, 92.2f, 4.4f, 0xFF87CDEB.toInt(), true, android.graphics.Paint.Align.RIGHT)
                mark("undo", 74f, 87.5f, 94f, 94.5f)
            }
        }

        /** Change picture, as in activity_change_picture.xml. */
        private fun change(c: android.graphics.Canvas) {
            header(c, "Change picture")
            box(c, 22f, 15f, 78f, 46f, TILE, null, 5f)                 // the picture, 180dp
            word(c, "🍎", 50f, 37f, 26f, NAVY, false, android.graphics.Paint.Align.CENTER)
            word(c, "Apple", 50f, 53f, 7f, INK_DARK, false, android.graphics.Paint.Align.CENTER)
            // Two big navy buttons at the bottom.
            box(c, 4f, 76f, 96f, 85f, NAVY, null, 50f)
            word(c, "Take a photo", 50f, 81.8f, 5.2f, WHITE, true, android.graphics.Paint.Align.CENTER)
            box(c, 4f, 87f, 96f, 96f, NAVY, null, 50f)
            word(c, "Choose a picture", 50f, 92.8f, 5.2f, WHITE, true, android.graphics.Paint.Align.CENTER)
            mark("choose", 4f, 76f, 96f, 96f)
        }

        /** Categories, as in activity_categories.xml and row_category.xml. */
        private fun categories(c: android.graphics.Canvas) {
            header(c, "Categories")
            word(c, "Hold a group and drag it to change the order", 4f, 16f, 3.4f, 0xFF5B6475.toInt())
            for ((i, name) in listOf("Fruit & Veg", "Fridge", "Bakery", "Frozen", "Other").withIndex()) {
                val t = 19f + i * 9f
                val lifted = spot == "dragMove" && i == 2
                box(c, if (lifted) 6f else 4f, t, if (lifted) 98f else 96f, t + 7.5f,
                    if (lifted) PALE_BLUE else WHITE, if (lifted) NAVY else CARD_EDGE, 3f,
                    key = when {
                        i == 0 -> "drag"
                        i == 1 -> "tapFridge"
                        lifted -> "dragMove"
                        else -> null
                    })  // more_tile
                word(c, name, 8f, t + 5f, 4.8f, INK_DARK)
                word(c, "≡", 89f, t + 5.4f, 6f, 0xFF8A93A3.toInt(), false, android.graphics.Paint.Align.CENTER)
            }
            // Dragging: an arrow shows Bakery going up above Fridge.
            if (spot == "dragMove") {
                word(c, "▲", 72f, 32f, 6f, NAVY, true, android.graphics.Paint.Align.CENTER)
                word(c, "▲", 72f, 26.5f, 6f, 0x991F3864.toInt(), true, android.graphics.Paint.Align.CENTER)
            }
            // + Add a category sits at the bottom of the screen.
            box(c, 4f, 88f, 96f, 96f, WHITE, OUTLINE, 3f, key = "addCat")
            word(c, "+  Add a category", 50f, 93.3f, 4.8f, INK_DARK, false, android.graphics.Paint.Align.CENTER)

            // A box over the screen, like the app's own pop-ups.
            fun dialog(top: Float, bottom: Float) {
                box(c, 0f, 0f, 100f, 100f, 0x66000000, null, 7f)
                box(c, 6f, top, 94f, bottom, WHITE, null, 5f)
            }
            val right = android.graphics.Paint.Align.RIGHT

            // Tapping a group: its name, the choices, and Cancel.
            if (spot == "catMenu") {
                // Fridge is in the middle, so it can go both ways.
                dialog(27f, 77f)
                word(c, "Fridge", 12f, 34f, 5.4f, INK_DARK, true)
                val choices = listOf("Move up", "Move down", "Change the name", "Move everything here to…", "Delete")
                for ((i, choice) in choices.withIndex()) {
                    word(c, choice, 12f, 41.5f + i * 6.5f, 4.4f, INK_DARK)
                }
                word(c, "CANCEL", 88f, 74.5f, 4.2f, NAVY, true, right)
                mark("catMenu", 9f, 37.5f, 91f, 49.5f)        // Move up and Move down
            }
            val menuSpots = listOf("catRename", "catMoveAll", "catDelete")
            if (spot in menuSpots) {
                // Fruit & Veg is first, so there is no Move up.
                dialog(27f, 71f)
                word(c, "Fruit & Veg", 12f, 34f, 5.4f, INK_DARK, true)
                val choices = listOf("Move down", "Change the name", "Move everything here to…", "Delete")
                for ((i, choice) in choices.withIndex()) {
                    word(c, choice, 12f, 41.5f + i * 6.5f, 4.4f, INK_DARK)
                }
                word(c, "CANCEL", 88f, 68f, 4.2f, NAVY, true, right)
                mark("catRename", 9f, 37.5f + 6.5f, 91f, 43f + 6.5f)
                mark("catMoveAll", 9f, 37.5f + 13f, 91f, 43f + 13f)
                mark("catDelete", 9f, 37.5f + 19.5f, 91f, 43f + 19.5f)
            }

            // + Add a category: type the name, then Add.
            if (spot == "addCatAsk") {
                dialog(32f, 62f)
                word(c, "Add a category", 12f, 39.5f, 5.4f, INK_DARK, true)
                box(c, 12f, 43f, 88f, 50f, WHITE, NAVY, 2f)
                word(c, "For example: Bakery", 15f, 47.8f, 4.2f, GREY)
                word(c, "CANCEL", 66f, 58.5f, 4.2f, NAVY, true, right)
                word(c, "ADD", 88f, 58.5f, 4.2f, NAVY, true, right)
                mark("addCatAsk", 10f, 42f, 91f, 60f)
            }

            // Change the name: type the new name, then Save.
            if (spot == "renameAsk") {
                dialog(32f, 62f)
                word(c, "Change the name", 12f, 39.5f, 5.4f, INK_DARK, true)
                box(c, 12f, 43f, 88f, 50f, WHITE, NAVY, 2f)
                word(c, "Fruit & Veg", 15f, 47.8f, 4.4f, INK_DARK)
                word(c, "CANCEL", 66f, 58.5f, 4.2f, NAVY, true, right)
                word(c, "SAVE", 88f, 58.5f, 4.2f, NAVY, true, right)
                mark("renameAsk", 10f, 42f, 91f, 60f)
            }

            // Move everything here to…: choose where they go.
            if (spot == "moveAllAsk") {
                dialog(26f, 72f)
                word(c, "Move everything in", 12f, 33f, 5f, INK_DARK, true)
                word(c, "Fruit & Veg to…", 12f, 37.5f, 5f, INK_DARK, true)
                for ((i, g) in listOf("Fridge", "Bakery", "Frozen", "Other").withIndex()) {
                    word(c, g, 12f, 45f + i * 6.5f, 4.4f, INK_DARK)
                }
                word(c, "CANCEL", 88f, 69f, 4.2f, NAVY, true, right)
                mark("moveAllAsk", 9f, 41f, 91f, 66f)
            }

            // Delete: asks first, and says where the items will go.
            if (spot == "deleteAsk") {
                dialog(32f, 64f)
                word(c, "Bakery", 12f, 39.5f, 5.4f, INK_DARK, true)
                word(c, "Delete Bakery? The 6 things in it", 12f, 45.5f, 4f, GREY)
                word(c, "will move to Fruit & Veg.", 12f, 49.5f, 4f, GREY)
                word(c, "CANCEL", 66f, 60.5f, 4.2f, NAVY, true, right)
                word(c, "DELETE", 88f, 60.5f, 4.2f, NAVY, true, right)
                mark("deleteAsk", 72f, 56f, 91f, 62.5f)
            }
        }

        /** Devices, as in activity_devices.xml and row_device.xml. */
        private fun devices(c: android.graphics.Canvas) {
            header(c, "Devices")
            for ((i, name) in listOf("Anna's phone", "Tablet").withIndex()) {
                val top = 13f + i * 12f
                box(c, 4f, top, 96f, top + 10.5f, WHITE, CARD_EDGE, 3f)
                word(c, name, 7f, top + 4.8f, 4.8f, INK_DARK, true)
                word(c, if (i == 0) "This device" else "Uses the list", 7f, top + 8.6f, 3.6f, GREY)
                word(c, "Remove", 92f, top + 6.4f, 3.8f, RED, false, android.graphics.Paint.Align.RIGHT)
            }
            box(c, 4f, 39f, 96f, 46f, WHITE, OUTLINE, 3f, key = "addDevice")      // button_outline
            word(c, "+  Add a device", 50f, 43.8f, 4.8f, INK_DARK, false, android.graphics.Paint.Align.CENTER)
        }

        /** Sending the link in a message. */
        private fun message(c: android.graphics.Canvas) {
            word(c, "Messages", 50f, 8.5f, 6.5f, NAVY, true, android.graphics.Paint.Align.CENTER)
            box(c, 0f, 12f, 100f, 12.4f, LINE, null, 0f)
            box(c, 22f, 30f, 96f, 52f, NAVY, null, 5f)
            word(c, "Easy Shop: open this link", 27f, 36f, 4.4f, WHITE, true)
            word(c, "to use our shopping list.", 27f, 39.6f, 4.4f, WHITE, true)
            box(c, 26f, 41f, 92f, 48.5f, WHITE, null, 3f, key = "link")
            word(c, "…web.app/join", 59f, 46.3f, 4.6f, NAVY, true, android.graphics.Paint.Align.CENTER)
            box(c, 4f, 88f, 80f, 95f, WHITE, LINE, 50f)
            word(c, "Message", 9f, 92.8f, 4.5f, GREY)
            box(c, 84f, 88f, 96f, 95f, NAVY, null, 50f)
            word(c, "➤", 90f, 93f, 4.5f, WHITE, true, android.graphics.Paint.Align.CENTER)
        }
    }
}