package com.example.shopping_list

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged

/**
 * Screen 2.1d Type.
 * After two or three letters the app shows what she may mean, with
 * pictures, so she rarely has to type a whole word.
 *
 * Several at once: tapping a suggestion ticks it instead of leaving
 * the screen. Type "bread", tick Bread and Bread rolls, type "milk",
 * tick Milk, then tap "Add selected (3)". Ticked things stay ticked
 * while she types another word, and are listed above the button.
 */
class TypeItem : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var list: LinearLayout
    private lateinit var didYouMean: TextView
    private lateinit var nothingFound: TextView
    private lateinit var chosenText: TextView
    private lateinit var addButton: Button

    /** How many suggestions to show for one word. The list scrolls. */
    private val most = 20

    /** One ticked thing: its picture and name, and whether it is new to the library. */
    private class Chosen(val item: LibraryItem, val isNew: Boolean)

    /** Everything ticked so far, in the order it was ticked, kept while she types other words. */
    private val chosen = linkedMapOf<String, Chosen>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_type_item)
        Library.load(this)   // include the household's own things

        input = findViewById(R.id.typeInput)
        list = findViewById(R.id.suggestionList)
        didYouMean = findViewById(R.id.didYouMeanText)
        nothingFound = findViewById(R.id.nothingFoundText)
        chosenText = findViewById(R.id.chosenText)
        addButton = findViewById(R.id.addSelectedButton)

        findViewById<View>(R.id.backButton).setOnClickListener { leave() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = leave()
        })

        // New suggestions with every letter.
        input.doAfterTextChanged { showSuggestions(it?.toString() ?: "") }

        // The keyboard's Done key: add what is ticked, or else tick the first suggestion.
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (chosen.isNotEmpty()) {
                    addChosen()
                } else {
                    Library.suggestions(input.text.toString(), most).firstOrNull()?.let {
                        toggle(it, isNew = false)
                        showSuggestions(input.text.toString())
                    }
                }
                true
            } else false
        }

        addButton.setOnClickListener { addChosen() }

        showChosen()
        input.requestFocus()
    }

    private fun showSuggestions(typed: String) {
        list.removeAllViews()
        val found = Library.suggestions(typed, most)

        // Not in the pictures? Offer to add exactly what she typed.
        // Only from two letters on, so one stray tap adds nothing.
        val offerNew = Names.key(typed).length >= 2 && !Library.isKnown(typed)

        didYouMean.visibility = if (found.isEmpty()) View.GONE else View.VISIBLE
        didYouMean.text = "Tap each one you need. You can tick more than one."
        nothingFound.text = "Not in the pictures yet"
        nothingFound.visibility = if (found.isEmpty() && offerNew) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(this)

        // Things already in the library, with their pictures.
        for (item in found) {
            val row = inflater.inflate(R.layout.row_suggestion, list, false)
            Pictures.show(row.findViewById<ImageView>(R.id.suggestionPicture),
                Library.pictureFor(this, item))
            row.findViewById<TextView>(R.id.suggestionName).text = boldStart(item.name, typed)
            row.setOnClickListener {
                toggle(item, isNew = false)
                styleRow(row, item)
            }
            styleRow(row, item)
            list.addView(row)
        }

        // Then "+ Add “Tahini”" at the bottom.
        if (offerNew) {
            val newItem = Library.custom(typed)
            val row = inflater.inflate(R.layout.row_suggestion, list, false)
            Pictures.show(row.findViewById<ImageView>(R.id.suggestionPicture), newItem.picture)
            row.findViewById<TextView>(R.id.suggestionName).text =
                "+  Add “${newItem.name}”"
            row.setOnClickListener {
                toggle(newItem, isNew = true)
                styleRow(row, newItem)
            }
            styleRow(row, newItem)
            list.addView(row)
        }
    }

    private fun key(item: LibraryItem) = Names.key(item.name)

    /** Ticks a thing, or unticks it if it was ticked. */
    private fun toggle(item: LibraryItem, isNew: Boolean) {
        val k = key(item)
        if (chosen.containsKey(k)) chosen.remove(k) else chosen[k] = Chosen(item, isNew)
        showChosen()
    }

    /** A ticked row: pale blue with a navy edge, and a green ✓ on the right. */
    private fun styleRow(row: View, item: LibraryItem) {
        val on = chosen.containsKey(key(item))
        row.setBackgroundResource(if (on) R.drawable.button_selected else R.drawable.more_tile)

        val d = resources.displayMetrics.density
        val tick = row.findViewWithTag<TextView>("tick") ?: TextView(this).apply {
            tag = "tick"
            text = "✓"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setBackgroundResource(R.drawable.tick_circle)
            (row as LinearLayout).addView(this, LinearLayout.LayoutParams((36 * d).toInt(), (36 * d).toInt())
                .apply { marginEnd = (6 * d).toInt() })
        }
        tick.visibility = if (on) View.VISIBLE else View.INVISIBLE
        row.contentDescription = if (on) "${item.name}, ticked" else item.name
    }

    /** "Chosen: Bread, Bread rolls" and "Add selected (2)", or nothing when none are ticked. */
    private fun showChosen() {
        val names = chosen.values.map { it.item.name }
        chosenText.visibility = if (names.isEmpty()) View.GONE else View.VISIBLE
        chosenText.text = "Chosen: " + names.joinToString(", ")
        addButton.visibility = if (names.isEmpty()) View.GONE else View.VISIBLE
        addButton.text = "Add selected (${names.size})"
    }

    /** Puts every ticked thing on the list in one go. */
    private fun addChosen() {
        if (chosen.isEmpty()) return
        val things = chosen.values.toList()

        // A new thing joins the picture grid, so next time it can simply be tapped.
        for (c in things) if (c.isNew) Library.addCustom(this, c.item.name)

        val result = Intent()
        result.putStringArrayListExtra("names", ArrayList(things.map { it.item.name }))
        result.putStringArrayListExtra("categories", ArrayList(things.map { it.item.category }))
        result.putStringArrayListExtra("pictures", ArrayList(things.map { it.item.picture }))
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    /** Back: if things are ticked, ask first, so they are not lost by mistake. */
    private fun leave() {
        if (chosen.isEmpty()) {
            finish()
            return
        }
        val n = chosen.size
        AlertDialog.Builder(this)
            .setTitle(if (n == 1) "Add the item you chose?" else "Add the $n items you chose?")
            .setMessage(chosen.values.joinToString(", ") { it.item.name })
            .setPositiveButton("Add") { _, _ -> addChosen() }
            .setNegativeButton("Leave without adding") { _, _ -> finish() }
            .setNeutralButton("Cancel", null)
            .show()
    }

    /** "Bro" + "Broccoli" → **Bro**ccoli, as in the wireframe. */
    private fun boldStart(name: String, typed: String): CharSequence {
        val t = Names.key(typed)
        if (!name.lowercase().startsWith(t)) return name
        return SpannableString(name).apply {
            setSpan(StyleSpan(Typeface.BOLD), 0, t.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }
}