package com.example.shopping_list

import android.content.Context

/**
 * Suggestions (screen 2.4) and "bought often".
 *
 * The app never adds anything by itself. After something is added, it
 * may remind or ask about something that goes with it, one card at a
 * time. Things bought often are not asked about: they are shown first
 * on the Add screen instead.
 */
object Suggestions {

    /** One card. [toAdd] is null for a reminder only. */
    data class Card(
        val heading: String,      // "You added"
        val shown: LibraryItem,   // the picture and name on the card
        val question: String,     // "Do you need butter as well?"
        val yesText: String,      // "Yes, add butter"
        val toAdd: LibraryItem?   // what Yes puts on the list, or null
    )

    /** [remindOnly]: the app cannot know exactly what to buy, so it only reminds. */
    private data class GoesWith(
        val name: String,
        val question: String,
        val yes: String,
        val remindOnly: Boolean = false
    )

    /** Things that usually go together. */
    private val goesWith = mapOf(
        "Birthday card" to GoesWith("Gift", "Do you need a gift as well?", "Yes, add a gift"),
        "Flowers" to GoesWith("Birthday card", "Do you need a card as well?", "Yes, add a card"),
        "Bread" to GoesWith("Butter", "Do you need butter as well?", "Yes, add butter"),
        "Pasta" to GoesWith("Cheese", "Do you need cheese as well?", "Yes, add cheese"),
        "Cereal" to GoesWith("Milk", "Do you need milk as well?", "Yes, add milk"),
        "Tea" to GoesWith("Milk", "Do you need milk as well?", "Yes, add milk"),
        "Coffee" to GoesWith("Milk", "Do you need milk as well?", "Yes, add milk"),
        "Sausages" to GoesWith("Bread", "Do you need bread as well?", "Yes, add bread"),
        "Lettuce" to GoesWith("Tomato", "Do you need tomatoes as well?", "Yes, add tomatoes")
    )

    /** Added this many times or more counts as "bought often". */
    const val OFTEN = 3

    /** After "No, thank you", stay quiet about that thing for a week. */
    private const val QUIET_MILLIS = 7L * 24 * 60 * 60 * 1000

    private fun store(context: Context) =
        context.getSharedPreferences("suggestions", Context.MODE_PRIVATE)

    fun timesAdded(context: Context, name: String) =
        store(context).getInt("count_" + Names.key(name), 0)

    /** Remembers what was added, to learn what she buys often. */
    fun record(context: Context, names: List<String>) {
        val edit = store(context).edit()
        for (name in names) {
            edit.putInt("count_" + Names.key(name), timesAdded(context, name) + 1)
        }
        edit.apply()
    }

    /** The things bought often, most-bought first. Used by the Add screen. */
    fun often(context: Context, items: List<LibraryItem>): List<LibraryItem> =
        items.filter { timesAdded(context, it.name) >= OFTEN }
            .sortedByDescending { timesAdded(context, it.name) }

    /** "No, thank you": not suggested again for a week. */
    fun decline(context: Context, name: String) {
        store(context).edit()
            .putLong("no_" + Names.key(name), System.currentTimeMillis())
            .apply()
    }

    private fun recentlyDeclined(context: Context, name: String): Boolean {
        val time = store(context).getLong("no_" + Names.key(name), 0L)
        return System.currentTimeMillis() - time < QUIET_MILLIS
    }

    /**
     * The one card to show after [added] went on the list, or null.
     * [onList] is what is already on the list.
     */
    fun next(context: Context, added: List<String>, onList: List<Item>): Card? {
        val on = context.getSharedPreferences("shopping", Context.MODE_PRIVATE)
            .getBoolean("suggest", true)
        if (!on) return null

        // Not just added, not already waiting on the list, not just declined.
        fun wanted(name: String) =
            added.none { Names.same(it, name) } &&
                    onList.none { !it.done && Names.same(it.name, name) } &&
                    !recentlyDeclined(context, name)

        fun find(name: String) = Library.items.firstOrNull { Names.same(it.name, name) }

        // Something that goes with what was just added.
        for (name in added) {
            val pair = goesWith.entries.firstOrNull { Names.same(it.key, name) }?.value ?: continue
            val from = find(name) ?: continue

            // A reminder only: nothing to add.
            if (pair.remindOnly) return Card("You added", from, pair.question, pair.yes, null)

            val to = find(pair.name) ?: continue
            if (wanted(to.name)) return Card("You added", from, pair.question, pair.yes, to)
        }
        return null
    }
}