package com.example.shopping_list

import android.content.Context
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * May this person change things that affect everyone on the list
 * (Pictures, Categories, People, Devices, removing favourites)?
 *
 * Yes for the person who set up the list, and for anyone given
 * "Can change settings" on People. Kept up to date live:
 *
 *   lists / KQZPMT / people / jj = { owner, canChange, … }
 */
object Permission {

    private var listId: String? = null
    private var ref: DatabaseReference? = null
    private var listener: ValueEventListener? = null

    private fun prefs(context: Context) =
        context.getSharedPreferences("shopping", Context.MODE_PRIVATE)

    /** The latest known answer (also remembered for when there is no internet). */
    fun allowed(context: Context): Boolean =
        prefs(context).getBoolean("mayChangeShared", true)

    /** Starts keeping the answer up to date. Safe to call often. */
    fun start(context: Context, listId: String) {
        if (this.listId == listId && listener != null) return
        stop()
        val app = context.applicationContext
        val myKey = Names.firebaseKey(prefs(app).getString("userName", "") ?: "")
        if (myKey.isEmpty()) return

        val r = FirebaseDatabase.getInstance().getReference("lists")
            .child(listId).child("people").child(myKey)
        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) return
                val owner = snapshot.child("owner").value == true
                val canChange = snapshot.child("canChange").value == true
                prefs(app).edit().putBoolean("mayChangeShared", owner || canChange).apply()
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        r.addValueEventListener(l)
        this.listId = listId
        ref = r
        listener = l
    }

    private fun stop() {
        val r = ref
        val l = listener
        if (r != null && l != null) r.removeEventListener(l)
        listId = null
        ref = null
        listener = null
    }
}