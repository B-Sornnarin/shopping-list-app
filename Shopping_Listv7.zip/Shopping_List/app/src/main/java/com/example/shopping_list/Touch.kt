package com.example.shopping_list

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View

/**
 * A gentle "press in" when something is touched: it shrinks very slightly
 * under the finger and springs back, so the tap is clearly felt.
 * Taps and long presses still work as normal.
 */
object Touch {

    /** Pressing [view] makes [target] press in (often the whole card or tile). */
    @SuppressLint("ClickableViewAccessibility")
    fun press(view: View, target: View = view) {
        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    target.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    target.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false   // let the normal tap / long press happen too
        }
    }
}