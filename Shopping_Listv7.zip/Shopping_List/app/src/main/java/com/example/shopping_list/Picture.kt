package com.example.shopping_list

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.widget.ImageView
import java.io.File

/**
 * Shows an item's picture: a photo the household chose, or a drawable
 * (res/drawable/pumpkin.png). If neither exists, the library's emoji
 * is drawn, or the first letter for the household's own things.
 */
object Pictures {

    fun show(view: ImageView, picture: String) {
        // Clear first: a reused row must not keep the last item's picture.
        view.setImageDrawable(null)
        if (picture.isEmpty()) return

        if (picture.startsWith("/")) {
            val file = File(picture)
            if (file.exists()) {
                view.setImageBitmap(BitmapFactory.decodeFile(picture))
                return
            }
        } else {
            val context = view.context
            val id = context.resources.getIdentifier(picture, "drawable", context.packageName)
            if (id != 0) {
                view.setImageResource(id)
                return
            }
        }

        // No photo and no drawable: draw the emoji, or the first letter.
        val name = picture.substringAfterLast('/').substringBefore('.').lowercase()
            .removePrefix("lib_").removePrefix("custom_")
        val text = Library.emojiFor(name) ?: name.take(1).uppercase()
        view.setImageBitmap(textBitmap(text))
    }

    /** Draws [text] centred on a square bitmap. ImageView scales it. */
    /** The household's Picture size setting: 48, 64 or 96. */
    private fun chosenSize(context: android.content.Context): Int =
        context.getSharedPreferences("shopping", android.content.Context.MODE_PRIVATE)
            .getInt("pictureSize", 64)

    /** How big a picture tile is on Add, Pictures and Photo, in dp. */
    fun tileSizeDp(context: android.content.Context): Int = when {
        chosenSize(context) <= 48 -> 88
        chosenSize(context) <= 64 -> 108
        else -> 144
    }

    /** The name under a tile grows with the picture. */
    fun tileTextSp(context: android.content.Context): Float = when {
        chosenSize(context) <= 48 -> 15f
        chosenSize(context) <= 64 -> 17f
        else -> 20f
    }

    /** How many tiles fit across the screen at this size (at least 2). */
    fun columns(context: android.content.Context): Int {
        val screenDp = context.resources.configuration.screenWidthDp - 32   // page padding
        val perTileDp = tileSizeDp(context) + 12                             // tile + its padding
        return maxOf(2, screenDp / perTileDp)
    }
    private fun textBitmap(text: String): Bitmap {
        val size = 256
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size * 0.7f
            textAlign = Paint.Align.CENTER
            color = 0xFF1F3864.toInt()
        }
        val y = size / 2f - (paint.descent() + paint.ascent()) / 2f
        Canvas(bitmap).drawText(text, size / 2f, y, paint)
        return bitmap
    }
}