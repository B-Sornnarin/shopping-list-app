package com.example.shopping_list

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar

/**
 * Screen 2.1 Add.
 *
 * Pictures come first, because a person may recognise an item without
 * recalling its name. It opens on ★ Favourites when there are any, so
 * the few usual things are shown instead of the whole library.
 *
 * Chosen pictures are never lost by accident: leaving or switching tab
 * while something is chosen asks "Add them to the shopping list?" first.
 *
 * Press and hold a picture:
 *   Frequency tab     → ★ Add to favourites
 *   ★ Favourites tab → 🗑 Remove from favourites
 */
class AddItem : AppCompatActivity() {

    private lateinit var adapter: LibraryAdapter
    private lateinit var addButton: Button
    private lateinit var addAllButton: Button
    private lateinit var allTab: TextView
    private lateinit var favouritesTab: TextView
    private lateinit var emptyText: TextView

    private val library = Library.items

    private var showingFavourites = false

    /** After the first choice, the tab only changes when she taps it. */
    private var tabChosen = false

    private val onFavouritesChanged: () -> Unit = { favouritesChanged() }

    /** Returns from Check, Photo or Type; passes the result straight on. */
    private val checkLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            setResult(Activity.RESULT_OK, result.data)
            finish()
        }
    }

    /** Returns from Android's speech recogniser. */
    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val heard = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull() ?: return@registerForActivityResult

        matchAndCheck(heard)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)
        Library.load(this)   // include the household's own things

        val listId: String? = Session.listId(this)
        if (listId != null) {
            Favourites.start(listId)
            Regulars.start(listId)               // the household's regular things, shared
        }

        addButton = findViewById(R.id.addSelectedButton)
        addAllButton = findViewById(R.id.addAllButton)
        allTab = findViewById(R.id.allButton)
        favouritesTab = findViewById(R.id.favouritesButton)
        emptyText = findViewById(R.id.favouritesEmptyText)

        adapter = LibraryAdapter(
            library,
            onSelectionChanged = { showCount() },
            // Press and hold a picture (both tabs): the small favourites menu.
            onRemoveFavourite = { item, tile -> showHoldMenu(item, tile) },
            // "Frequency" tab: only what she buys often, most first.
            allFilter = { list -> Regulars.often(this, list) }
        )

        val grid = findViewById<RecyclerView>(R.id.libraryGrid)
        // As many across as fit at the chosen Picture size.
        grid.layoutManager = GridLayoutManager(this, Pictures.columns(this))
        grid.adapter = adapter

        // ‹ back arrow and the phone's Back button: close the menu if open,
        // otherwise ask first if anything is chosen.
        findViewById<View>(R.id.backButton).setOnClickListener { askBeforeLosing { finish() } }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (HoldMenu.close(this@AddItem)) return
                askBeforeLosing { finish() }
            }
        })

        addButton.setOnClickListener { sendBack(adapter.selectedItems()) }

        // Add all favourites: everything on the Favourites tab, in one tap (Req 8).
        addAllButton.setOnClickListener { sendBack(adapter.shownItems()) }

        // Filtering changes what is shown; it never adds anything.
        // Switching tab with pictures chosen asks first, so nothing is lost.
        allTab.setOnClickListener {
            if (!showingFavourites) return@setOnClickListener   // already here
            askBeforeLosing {
                tabChosen = true
                showTab(favourites = false)
            }
        }
        favouritesTab.setOnClickListener {
            if (showingFavourites) return@setOnClickListener    // already here
            askBeforeLosing {
                tabChosen = true
                showTab(favourites = true)
            }
        }

        // These three now live inside the search bar, so they are a
        // TextView and two ImageButtons rather than Buttons.
        findViewById<View>(R.id.sayButton).setOnClickListener { listen() }
        findViewById<View>(R.id.photoButton).setOnClickListener {
            checkLauncher.launch(Intent(this, PhotoItem::class.java))
        }
        findViewById<View>(R.id.typeButton).setOnClickListener {
            checkLauncher.launch(Intent(this, TypeItem::class.java))
        }

        Favourites.watch(onFavouritesChanged)
        Library.watch(onFavouritesChanged)   // a new thing from another device: show it
        Regulars.watch(onFavouritesChanged)  // the household's counts changed: update Frequency
        favouritesChanged()
        showCount()
    }

    override fun onDestroy() {
        super.onDestroy()
        Favourites.unwatch(onFavouritesChanged)
        Library.unwatch(onFavouritesChanged)
        Regulars.unwatch(onFavouritesChanged)
        HoldMenu.close(this, animate = false)
    }

    /**
     * Nothing chosen: do [then] straight away.
     * Something chosen: "You chose 2 things. Add them to the shopping list?"
     *   Add to list → adds them and returns to the list.
     *   Don't add   → clears the choices, then does [then].
     *   Tap outside → stays here, choices kept.
     */
    private fun askBeforeLosing(then: () -> Unit) {
        val chosen = adapter.selectedItems()
        if (chosen.isEmpty()) {
            then()
            return
        }
        val things = if (chosen.size == 1) "1 thing" else "${chosen.size} things"
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("You chose $things")
            .setMessage("Add ${if (chosen.size == 1) "it" else "them"} to the shopping list?")
            .setPositiveButton("Add to list") { _, _ -> sendBack(chosen) }
            .setNegativeButton("Don't add") { _, _ ->
                adapter.clearSelection()
                showCount()
                then()
            }
            .show()

        // Bigger words than Android's default.
        dialog.findViewById<TextView>(android.R.id.message)?.textSize = 20f
        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)?.textSize = 19f
        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)?.textSize = 19f
    }

    /** Opens on Favourites the first time, if there are any. */
    private fun favouritesChanged() {
        if (!tabChosen && Favourites.loaded) {
            tabChosen = true
            showTab(favourites = Favourites.hasAny())
        } else {
            showTab(showingFavourites)
        }
    }

    private fun showTab(favourites: Boolean) {
        showingFavourites = favourites
        if (favourites) adapter.showFavourites() else adapter.showAll()

        styleTab(allTab, chosen = !favourites)
        styleTab(favouritesTab, chosen = favourites)

        val empty = adapter.shownItems().isEmpty()
        emptyText.text = if (favourites) "No favourites yet"
        else "Things added 2 or more times in the last 30 days show here.\nUse Type, Say or Photo above."
        emptyText.visibility = if (empty) View.VISIBLE else View.GONE

        // Only on Favourites: "add all" of every picture would be a mistake.
        addAllButton.visibility = if (favourites && !empty) View.VISIBLE else View.GONE
    }

    /** The chosen tab is dark navy with white words, as in the wireframe. */
    private fun styleTab(tab: TextView, chosen: Boolean) {
        tab.setBackgroundResource(if (chosen) R.drawable.tab_selected else R.drawable.button_outline)
        tab.setTextColor(Color.parseColor(if (chosen) "#FFFFFF" else "#1F3864"))
        tab.setTypeface(null, if (chosen) Typeface.BOLD else Typeface.NORMAL)
        tab.isSelected = chosen   // TalkBack says "selected"
    }

    /**
     * Press and hold a picture: the screen dims, the picture lifts,
     * and a small menu appears next to it.
     *   Frequency tab      → ★ Add to favourites  (or "Already a favourite")
     *   ★ Favourites tab → 🗑 Remove from favourites
     */
    private fun showHoldMenu(item: LibraryItem, tile: View) {
        val favourite = Favourites.isFavourite(item.id)

        val main = when {
            // ★ Favourites tab, not allowed: locked
            showingFavourites && !Permission.allowed(this) ->
                HoldMenu.Row("Permission needed to remove", "#8A93A3") {}

            // ★ Favourites tab: Remove
            showingFavourites ->
                HoldMenu.Row("Remove from favourites", "#B3261E") { removeFavourite(item) }

            // Frequency tab, already a favourite: just say so (nothing to do here)
            favourite ->
                HoldMenu.Row("Already a favourite", "#8A93A3") {}

            // Frequency tab: Add
            else ->
                HoldMenu.Row("Add to favourites", "#1F3864") {
                    addFavourite(item)
                }
        }

        // The household's own things can be renamed; built-in names are
        // what Say, Type and Photo match on, so those stay as they are.
        val rows = mutableListOf(main)
        if (Library.isCustom(item) && Permission.allowed(this)) {
            rows.add(HoldMenu.Row("Change the name", "#1F3864") {
                RenameItem.ask(this, item)
            })
        }
        if (Permission.allowed(this)) {
            rows.add(HoldMenu.Row("Move to another category", "#1F3864") {
                ChooseGroup.ask(this, item)
            })
        }
        rows.add(HoldMenu.Row("Cancel", "#1A1A1A") {})

        HoldMenu.show(this, tile, addButton, rows)
    }

    /** Into favourites: the gold ★ appears at once, with a short message. */
    private fun addFavourite(item: LibraryItem) {
        Favourites.set(item.id, true)
        showTab(showingFavourites)   // the ★ shows straight away
        message("★ ${item.name} added to favourites")
    }

    /**
     * Out of favourites only. It stays in Frequency and on the shopping list.
     * It disappears at once; Undo puts it back.
     */
    private fun removeFavourite(item: LibraryItem) {
        adapter.deselect(item.id)
        Favourites.set(item.id, false)
        showTab(showingFavourites)   // gone from the grid straight away
        showCount()
        message("${item.name} removed from favourites") {
            Favourites.set(item.id, true)
            showTab(showingFavourites)   // back straight away
        }
    }

    /** A message at the bottom, above the buttons, in big words. With Undo if [undo] is given. */
    private fun message(text: String, undo: (() -> Unit)? = null) {
        val bar = Snackbar.make(
            findViewById(R.id.libraryGrid),
            text,
            if (undo != null) 8000 else 4000   // 8 seconds when there is something to decide
        )
        if (undo != null) bar.setAction("Undo") { undo() }
        bar.setAnchorView(R.id.addSelectedButton)
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_text
        ).textSize = 18f
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_action
        ).textSize = 18f
        bar.show()
    }

    /** The button says how many are chosen, so the tap is confirmed. */
    private fun showCount() {
        val n = adapter.selectedItems().size
        addButton.text = if (n == 0) "Add selected" else "Add selected ($n)"
        addButton.isEnabled = n > 0
    }

    /** Hands the chosen names, categories and pictures back to the list. */
    private fun sendBack(chosen: List<LibraryItem>) {
        if (chosen.isEmpty()) return

        val result = Intent()
        result.putStringArrayListExtra("names", ArrayList(chosen.map { it.name }))
        result.putStringArrayListExtra("categories", ArrayList(chosen.map { it.category }))
        result.putStringArrayListExtra("pictures", ArrayList(chosen.map { it.picture }))
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    /** Asks for the microphone, then opens Android's own listener. */
    private fun listen() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.RECORD_AUDIO), 1
            )
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening…")
        }
        speechLauncher.launch(intent)
    }

    /** Something in the library, or a new thing; Check confirms either. */
    private fun matchAndCheck(heard: String) {
        if (Names.key(heard).isEmpty()) {
            Toast.makeText(this, "Not recognised. Please try again.", Toast.LENGTH_SHORT).show()
            return
        }

        val match = Library.match(heard)
        val item = match ?: Library.custom(heard)

        val intent = Intent(this, CheckItem::class.java)
        intent.putExtra("name", item.name)
        intent.putExtra("category", item.category)
        intent.putExtra("picture", item.picture)
        intent.putExtra("isNew", match == null)
        checkLauncher.launch(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
    }
}