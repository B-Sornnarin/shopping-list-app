package com.example.shopping_list

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/** One person on a list (screen 3.1). */
data class Person(
    val key: String,          // "anna": the name in lowercase
    val name: String,         // "Anna": as shown
    val mobile: String = "",
    val owner: Boolean = false,
    val canChange: Boolean = false
) {
    /** The owner can always change settings. */
    val mayChangeSettings get() = owner || canChange
}

/**
 * The people on a list, kept in Firebase:
 *
 *   lists / KQZPMT / people  / anna = { name, mobile, owner, canChange, invitedBy, welcomed }
 *   lists / KQZPMT / removed / anna = true
 */
object People {

    private fun list(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists").child(listId)

    private fun ref(listId: String) = list(listId).child("people")
    private fun removedRef(listId: String) = list(listId).child("removed")

    /** The people on the list, owner first, now and after every change. */
    fun listen(listId: String, onChanged: (List<Person>) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val people = snapshot.children.map { child ->
                    Person(
                        key = child.key ?: "",
                        name = child.child("name").value?.toString() ?: "",
                        mobile = child.child("mobile").value?.toString() ?: "",
                        owner = child.child("owner").value == true,
                        canChange = child.child("canChange").value == true
                    )
                }
                onChanged(people.sortedByDescending { it.owner })
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        ref(listId).addValueEventListener(listener)
        return listener
    }

    fun stop(listId: String, listener: ValueEventListener) {
        ref(listId).removeEventListener(listener)
    }

    /**
     * Puts [name] on the list if not already there. The first person on
     * a list is its owner; everyone else joins as a normal member.
     * [invitedBy] is who sent the invitation, for the welcome message.
     */
    fun join(listId: String, name: String, owner: Boolean = false, mobile: String = "",
             invitedBy: String = "") {
        val key = Names.firebaseKey(name)
        val person = ref(listId).child(key)

        // Invited again after being removed: welcome back.
        removedRef(listId).child(key).removeValue()

        // A single-value listener, not get(): get() can fail with
        // "Client is offline" when it is the first thing asked.
        person.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) return
                person.setValue(
                    mapOf(
                        "name" to Names.display(name),
                        "mobile" to mobile,
                        "owner" to owner,
                        "canChange" to owner,
                        "invitedBy" to invitedBy
                    )
                )
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    /** The switch on People: give or take back permission. */
    fun setCanChange(listId: String, key: String, allowed: Boolean) {
        ref(listId).child(key).child("canChange").setValue(allowed)
    }

    /**
     * Takes someone off the list. The owner can never be removed.
     * Their name stops opening this list, and their phone is told.
     */
    fun remove(listId: String, person: Person) {
        if (person.owner) return
        ref(listId).child(person.key).removeValue()
        removedRef(listId).child(person.key).setValue(true)
        Accounts.forget(person.name, listId)
    }

    /** Calls [onRemoved] if this person is taken off the list, on any device. */
    fun watchRemoved(listId: String, key: String, onRemoved: () -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.value == true) onRemoved()
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        removedRef(listId).child(key).addValueEventListener(listener)
        return listener
    }

    fun stopWatching(listId: String, key: String, listener: ValueEventListener) {
        removedRef(listId).child(key).removeEventListener(listener)
    }

    /**
     * One way of writing each Australian mobile number, so
     * "0412 345 678", "+61 412 345 678" and "61412345678" all match.
     */
    fun sameMobile(a: String, b: String): Boolean {
        fun plain(m: String): String {
            val digits = m.filter { it.isDigit() }
            return if (digits.startsWith("61") && digits.length == 11) "0" + digits.drop(2) else digits
        }
        return plain(a).isNotEmpty() && plain(a) == plain(b)
    }

    /**
     * Who invited [name], if they have not seen the welcome yet.
     * [onResult] gets the inviter's name, or null.
     */
    fun invitation(listId: String, name: String, onResult: (String?) -> Unit) {
        ref(listId).child(Names.firebaseKey(name))
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val inviter = snapshot.child("invitedBy").value?.toString() ?: ""
                    val seen = snapshot.child("welcomed").value == true
                    onResult(if (inviter.isNotEmpty() && !seen) inviter else null)
                }

                override fun onCancelled(error: DatabaseError) {
                    onResult(null)
                }
            })
    }

    /** The welcome is shown once only. */
    fun markWelcomed(listId: String, name: String) {
        ref(listId).child(Names.firebaseKey(name)).child("welcomed").setValue(true)
    }

    /**
     * For an invite link: is [name] still invited to [listId], and by whom?
     * [onResult] gets (found, inviter's name).
     */
    fun find(listId: String, name: String, onResult: (Boolean, String) -> Unit) {
        ref(listId).child(Names.firebaseKey(name))
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    onResult(snapshot.exists(), snapshot.child("invitedBy").value?.toString() ?: "")
                }

                override fun onCancelled(error: DatabaseError) {
                    onResult(false, "")
                }
            })
    }
}