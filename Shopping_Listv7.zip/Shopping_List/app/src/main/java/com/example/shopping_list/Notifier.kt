package com.example.shopping_list

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * "New item notifications" (Settings).
 *
 * Shows "Frank added to the list: Milk and Bread" when someone else
 * adds something. It stays in the notification list until tapped,
 * so it can be read later. Tapping it opens the list.
 */
object Notifier {

    // A new channel name, because Android never changes an old channel's importance.
    private const val CHANNEL = "new_items_popup"
    private const val TAG = "Notify"
    private var nextId = 1

    /** Android 13 and newer must be allowed to show notifications. */
    fun canShow(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED

    private fun makeChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.deleteNotificationChannel("new_items")   // the old, quiet one
            val channel = NotificationChannel(
                CHANNEL, "New items on the list", NotificationManager.IMPORTANCE_HIGH
            )
            channel.description = "When someone else adds something to the shopping list"
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * One notification for everything [who] just added.
     * [quiet] = true: no pop-up or sound, just kept in the notification list
     * (used when the list is open and the white card has already shown it).
     */
    @SuppressLint("MissingPermission")
    fun newItems(context: Context, who: String, names: List<String>, quiet: Boolean = false) {
        Log.d(TAG, "$who added $names")

        val on = context.getSharedPreferences("shopping", Context.MODE_PRIVATE)
            .getBoolean("notify", false)
        if (!on) { Log.d(TAG, "Not shown: New item notifications is Off in Settings"); return }
        if (!canShow(context)) { Log.d(TAG, "Not shown: Android has not allowed notifications"); return }
        if (names.isEmpty()) return
        makeChannel(context)

        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            Log.d(TAG, "Not shown: notifications are turned off for this app in Android Settings")
            return
        }

        // "Milk", "Milk and Bread", "Milk, Bread and 3 more"
        val what = when (names.size) {
            1 -> names[0]
            2 -> "${names[0]} and ${names[1]}"
            else -> "${names[0]}, ${names[1]} and ${names.size - 2} more"
        }

        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, ShoppingList::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("$who added to the list")
            .setContentText(what)
            .setStyle(NotificationCompat.BigTextStyle().bigText(what))
            .setPriority(NotificationCompat.PRIORITY_HIGH)       // pops up on older Android too
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setSilent(quiet)                                    // quiet: no pop-up, no sound
            .setShowWhen(true)                                   // shows the time it arrived
            .setContentIntent(open)
            .setAutoCancel(true)                                 // goes away once tapped
            .build()

        try {
            NotificationManagerCompat.from(context).notify(nextId++, notification)
            Log.d(TAG, "Shown${if (quiet) " quietly" else ""}: $who added to the list: $what")
        } catch (e: SecurityException) {
            Log.d(TAG, "Not shown: blocked by Android ($e)")
        }
    }
}