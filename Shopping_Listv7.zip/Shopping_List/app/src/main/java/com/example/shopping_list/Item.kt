package com.example.shopping_list

/**
 * One thing on the shopping list.
 *
 * Adding the same thing twice raises [count] rather than making a
 * second row: two identical rows would read as a mistake.
 * [addedBy] is who put it on the list, for "Notify me of new items".
 */
data class Item(
    val id: String,
    val name: String,
    val category: String,
    val picture: String = "",
    val count: Int = 1,
    var done: Boolean = false,
    val addedBy: String = ""
)