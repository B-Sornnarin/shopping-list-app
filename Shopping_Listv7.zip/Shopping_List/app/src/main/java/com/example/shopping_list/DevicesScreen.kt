package com.example.shopping_list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.ValueEventListener

/**
 * Screen 3.5 Devices.
 *
 * One list on every device (Req 3). Each device adds itself when the
 * list opens. A lost device can be removed here: your own devices
 * always, anyone's if you may change settings.
 */
class DevicesScreen : AppCompatActivity() {

    private lateinit var listId: String
    private lateinit var rows: LinearLayout
    private var devices: List<Device> = emptyList()
    private var iMayChange = false
    private var deviceListener: ValueEventListener? = null
    private var peopleListener: ValueEventListener? = null

    private val myName: String
        get() = getSharedPreferences("shopping", MODE_PRIVATE).getString("userName", "") ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_devices)

        listId = Session.listId(this) ?: return finish()
        rows = findViewById(R.id.deviceRows)

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }
        findViewById<View>(R.id.addDeviceButton).setOnClickListener { Devices.showHowToAdd(this) }

        Devices.register(this, listId)   // make sure this one is listed

        peopleListener = People.listen(listId) { people ->
            iMayChange = people.firstOrNull { Names.same(it.name, myName) }?.mayChangeSettings == true
            show()
        }
        deviceListener = Devices.listen(listId) { latest ->
            devices = latest
            show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        deviceListener?.let { Devices.stop(listId, it) }
        peopleListener?.let { People.stop(listId, it) }
    }

    private fun show() {
        val me = Devices.myId(this)
        rows.removeAllViews()
        val inflater = LayoutInflater.from(this)

        // This one first, then the others by name.
        for (device in devices.sortedWith(compareBy<Device>({ it.id != me }, { it.name }))) {
            val row = inflater.inflate(R.layout.row_device, rows, false)
            row.findViewById<TextView>(R.id.deviceName).text = device.name
            row.findViewById<TextView>(R.id.deviceType).text =
                if (device.id == me) "${device.type} · This one" else device.type

            // Remove: not this one (Log out is for that). Your own
            // devices always; anyone's with permission.
            val remove = row.findViewById<TextView>(R.id.removeDeviceButton)
            val canRemove = device.id != me &&
                    (iMayChange || Names.same(device.owner, myName))
            remove.visibility = if (canRemove) View.VISIBLE else View.GONE
            remove.contentDescription = "Remove ${device.name}"
            remove.setOnClickListener { confirmRemove(device) }

            rows.addView(row)
        }
    }

    /** Asks first, so a mis-tap removes nothing. */
    private fun confirmRemove(device: Device) {
        AlertDialog.Builder(this)
            .setTitle("Remove ${device.name}?")
            .setMessage(
                "This device will no longer show the shopping list. " +
                        "You can add it again at any time."
            )
            .setPositiveButton("Remove") { _, _ ->
                Devices.remove(listId, device)
                Toast.makeText(this, "${device.name} has been removed.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}