package com.example.shopping_list

import android.graphics.Color
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * The picture grid, used by Add, Pictures and Photo.
 *
 * On Add, tapping a picture selects it (green border and ✓); nothing
 * reaches the list until Add selected is pressed, which protects
 * against a mis-tap. Elsewhere, tapping opens the item instead.
 *
 * On Add (both tabs), pressing and holding a picture opens the small
 * menu: Add to / Remove from favourites, or Cancel.
 */
class LibraryAdapter(
    private val library: MutableList<LibraryItem>,
    private val onSelectionChanged: () -> Unit,
    private val selectable: Boolean = true,
    private val onTapped: ((LibraryItem) -> Unit)? = null,
    /** Press and hold: the item, and the tile to show the menu next to. Only on Add. */
    private val onRemoveFavourite: ((LibraryItem, View) -> Unit)? = null,
    /** What the non-favourites tab shows. Add uses "bought often"; others show everything. */
    private val allFilter: (List<LibraryItem>) -> List<LibraryItem> = { it }
) : RecyclerView.Adapter<LibraryAdapter.Holder>() {

    private var favouritesOnly = false

    /** What is currently shown. Filtering never changes the library. */
    private var shown: List<LibraryItem> = library

    /** Ids of the tiles chosen on this visit to Add. */
    private val selectedIds = mutableSetOf<String>()

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val frame: View = view.findViewById(R.id.tilePictureFrame)
        val picture: ImageView = view.findViewById(R.id.tilePicture)
        val name: TextView = view.findViewById(R.id.tileName)
        val star: TextView = view.findViewById(R.id.tileStar)
        val remove: TextView = view.findViewById(R.id.tileRemove)
        val tick: TextView = view.findViewById(R.id.tileTick)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.tile_library, parent, false)
        Touch.press(view)   // the picture presses in when touched
        return Holder(view)
    }

    override fun getItemCount() = shown.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = shown[position]
        holder.name.text = item.name

        // The Picture size from Settings, here as on the list.
        val context = holder.itemView.context
        val px = (Pictures.tileSizeDp(context) * context.resources.displayMetrics.density).toInt()
        holder.frame.layoutParams.width = px
        holder.frame.layoutParams.height = px
        holder.frame.requestLayout()
        holder.name.textSize = Pictures.tileTextSp(context)
        Pictures.show(holder.picture, Library.pictureFor(holder.itemView.context, item))

        val favourite = Favourites.isFavourite(item.id)
        val chosen = selectable && item.id in selectedIds
        val canHold = onRemoveFavourite != null   // on Add, both tabs

        // The gold ★ shows on every favourite. The old ✕ is no longer used.
        holder.star.visibility = if (favourite) View.VISIBLE else View.GONE
        holder.remove.visibility = View.GONE

        holder.tick.visibility = if (chosen) View.VISIBLE else View.GONE
        holder.frame.setBackgroundResource(
            if (chosen) R.drawable.tile_selected else R.drawable.tile_plain
        )
        holder.name.setTextColor(Color.parseColor(if (chosen) "#1E5B14" else "#1A1A1A"))
        holder.name.setTypeface(null, if (chosen) Typeface.BOLD else Typeface.NORMAL)

        // TalkBack: "Milk, favourite, selected. Press and hold for more."
        holder.itemView.contentDescription = buildString {
            append(item.name)
            if (favourite) append(", favourite")
            if (chosen) append(", selected")
            if (canHold) append(". Press and hold for more.")
        }

        holder.itemView.setOnClickListener {
            if (selectable) {
                if (!selectedIds.remove(item.id)) selectedIds.add(item.id)
                notifyItemChanged(holder.bindingAdapterPosition)
                onSelectionChanged()
            } else {
                onTapped?.invoke(item)
            }
        }

        // Press and hold (on Add): the small favourites menu.
        if (canHold) {
            holder.itemView.setOnLongClickListener {
                onRemoveFavourite?.invoke(item, holder.itemView)
                true
            }
        } else {
            holder.itemView.setOnLongClickListener(null)
            holder.itemView.isLongClickable = false
        }
    }

    fun selectedItems() = library.filter { it.id in selectedIds }

    /** Unchoose a tile, e.g. when it is taken out of favourites. */
    fun deselect(itemId: String) {
        selectedIds.remove(itemId)
    }

    /** Unchoose everything, e.g. "Don't add" when leaving. */
    fun clearSelection() {
        selectedIds.clear()
        notifyDataSetChanged()
    }

    /** Everything currently on screen: all pictures, or only favourites. */
    fun shownItems(): List<LibraryItem> = shown

    fun showAll() {
        favouritesOnly = false
        refresh()
    }

    fun showFavourites() {
        favouritesOnly = true
        refresh()
    }

    /** Call when favourites change, so stars and the filter stay right. */
    fun refresh() {
        shown = if (favouritesOnly) library.filter { Favourites.isFavourite(it.id) } else allFilter(library)
        notifyDataSetChanged()
    }
}