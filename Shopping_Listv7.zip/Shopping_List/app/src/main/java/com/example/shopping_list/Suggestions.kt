package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Screen 2.4 Suggestion.
 *
 * A question: Yes adds the thing, No, thank you closes the card.
 * A reminder: one button, which only closes the card.
 */
class SuggestionScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_suggestion)

        val addName = intent.getStringExtra("addName") ?: ""
        val addCategory = intent.getStringExtra("addCategory") ?: ""
        val addPicture = intent.getStringExtra("addPicture") ?: ""
        val remindOnly = addName.isEmpty()

        findViewById<TextView>(R.id.suggestionHeading).text = intent.getStringExtra("heading")
        findViewById<TextView>(R.id.suggestionItemName).text = intent.getStringExtra("shownName")
        findViewById<TextView>(R.id.suggestionQuestion).text = intent.getStringExtra("question")
        Pictures.show(findViewById<ImageView>(R.id.suggestionItemPicture),
            intent.getStringExtra("shownPicture") ?: "")

        val yes = findViewById<TextView>(R.id.suggestYesButton)
        val no = findViewById<View>(R.id.suggestNoButton)
        yes.text = intent.getStringExtra("yesText")

        if (remindOnly) {
            // Just a reminder: one button, nothing is added.
            no.visibility = View.GONE
            yes.setOnClickListener { finish() }
            return
        }

        yes.setOnClickListener {
            val result = Intent()
            result.putStringArrayListExtra("names", arrayListOf(addName))
            result.putStringArrayListExtra("categories", arrayListOf(addCategory))
            result.putStringArrayListExtra("pictures", arrayListOf(addPicture))
            setResult(RESULT_OK, result)
            finish()
        }

        no.setOnClickListener {
            Suggestions.decline(this, addName)
            finish()
        }
    }
}