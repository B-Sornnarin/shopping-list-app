package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Screen 2.2 Check.
 *
 * Shown only when the app had to guess: after Say, Photo or Type.
 * Tapping a picture never comes here, because a tap cannot be
 * misheard. Each button does one whole thing, then the screen closes:
 *  - Yes, add it
 *  - ★ Yes, add it and make it a favourite (only if not one already)
 *  - No: nothing is added, back to try again
 */
class CheckItem : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_item)
        Session.listId(this)?.let { Favourites.start(it) }

        val name = intent.getStringExtra("name") ?: ""
        val category = intent.getStringExtra("category") ?: ""
        val picture = intent.getStringExtra("picture") ?: ""

        // True when this is something not yet in the picture library.
        val isNew = intent.getBooleanExtra("isNew", false)

        findViewById<TextView>(R.id.checkName).text = "$name?"
        Pictures.show(findViewById<ImageView>(R.id.checkPicture), picture)

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }

        findViewById<Button>(R.id.yesButton).setOnClickListener {
            addAndClose(name, category, picture, isNew, favourite = false)
        }

        // The ★ button only when it is not a favourite already.
        val yesFavourite = findViewById<Button>(R.id.yesFavouriteButton)
        if (!isNew && Favourites.isFavourite(libraryId(name))) {
            yesFavourite.visibility = View.GONE
        }
        yesFavourite.setOnClickListener {
            addAndClose(name, category, picture, isNew, favourite = true)
        }

        findViewById<Button>(R.id.noButton).setOnClickListener {
            // Nothing is added. Back, to try again.
            finish()
        }
    }

    /** The library id for [name]: "lib_milk", or "custom_tahini" for a new thing. */
    private fun libraryId(name: String): String =
        Library.items.firstOrNull { Names.same(it.name, name) }?.id ?: Library.custom(name).id

    private fun addAndClose(name: String, category: String, picture: String,
                            isNew: Boolean, favourite: Boolean) {
        // A new thing joins the picture grid, so next time it can
        // simply be tapped. Its picture can be set in Settings.
        if (isNew) Library.addCustom(this, name)

        if (favourite) {
            Favourites.set(libraryId(name), true)
            Toast.makeText(this, "$name is added and is now a favourite",
                Toast.LENGTH_SHORT).show()
        }

        val result = Intent()
        result.putStringArrayListExtra("names", arrayListOf(name))
        result.putStringArrayListExtra("categories", arrayListOf(category))
        result.putStringArrayListExtra("pictures", arrayListOf(picture))
        setResult(RESULT_OK, result)
        finish()
    }
}