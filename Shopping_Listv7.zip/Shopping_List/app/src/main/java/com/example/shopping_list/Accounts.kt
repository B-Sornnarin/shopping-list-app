package com.example.shopping_list

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * Connects a person's name to their shopping list in Firebase:
 *   accounts / sorn / listId = "KQZPMT"
 * Saved in lowercase, so "Sorn" and "SORN" find the same list.
 */
object Accounts {

    private val ref
        get() = FirebaseDatabase.getInstance().getReference("accounts")

    /** [onFound] gets the list id, or null if this name is new. */
    fun find(name: String, onFound: (String?) -> Unit, onError: (String) -> Unit) {
        // A single-value listener waits for the connection to start,
        // unlike get(), which can fail with "Client is offline".
        ref.child(Names.firebaseKey(name)).addListenerForSingleValueEvent(
            object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    onFound(snapshot.child("listId").value?.toString())
                }

                override fun onCancelled(error: DatabaseError) {
                    onError(error.message)
                }
            }
        )
    }

    /** Remembers that [name] owns the list [listId]. */
    fun save(name: String, listId: String) {
        ref.child(Names.firebaseKey(name)).setValue(
            mapOf(
                "name" to Names.display(name),
                "listId" to listId
            )
        )
    }

    /**
     * Stops [name] opening [listId], after they are removed from it.
     * Only if the name still points at this list.
     */
    fun forget(name: String, listId: String) {
        val account = ref.child(Names.firebaseKey(name))
        account.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.child("listId").value?.toString() == listId) {
                    account.removeValue()
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }
}