package com.example.shopping_list

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * The bar at the bottom of the screen: Home, + Add, People.
 * The screen you are on is highlighted, so it is always clear where you are.
 *
 * Use it with one line, straight after setContentView, for example:
 *   BottomBar.attach(this, BottomBar.PEOPLE)
 */
object BottomBar {

    const val HOME = 0
    const val ADD = 1
    const val PEOPLE = 2

    private const val NAVY = "#1F3864"
    private const val GREY = "#5B6475"

    /**
     * Puts the bar under the screen's own layout.
     * onAdd: what + Add does on this screen. If not given, it goes to the
     * shopping list and opens Add from there.
     */
    fun attach(activity: AppCompatActivity, current: Int, onAdd: (() -> Unit)? = null) {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        // Take the screen's own layout out, and put it back above the bar.
        val content = activity.findViewById<FrameLayout>(android.R.id.content)
        val page = content.getChildAt(0) ?: return
        content.removeView(page)

        val wrapper = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        wrapper.addView(page, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // A thin grey line above the bar.
        wrapper.addView(View(activity).apply { setBackgroundColor(Color.parseColor("#D5DAE3")) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))

        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        // ---- THE ICONS: change R.drawable.… here to use a different picture ----
        bar.addView(button(activity, R.drawable.ic_bar_home, "Home", current == HOME) {
            goHome(activity, current)
        }, weightOne())

        bar.addView(addButton(activity, current == ADD) {
            if (onAdd != null) onAdd() else openAddFromList(activity)
        }, weightOne())

        bar.addView(button(activity, R.drawable.ic_bar_people, "People", current == PEOPLE) {
            goPeople(activity, current)
        }, weightOne())

        wrapper.addView(bar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        content.addView(wrapper, 0, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Keep the bar above the phone's own buttons at the bottom of the screen.
        ViewCompat.setOnApplyWindowInsetsListener(wrapper) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(wrapper)
    }

    private fun weightOne() = LinearLayout.LayoutParams(0,
        LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    /** The box every button sits in; pale blue when it is this screen. */
    private fun box(activity: AppCompatActivity, word: String, here: Boolean): LinearLayout {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        return LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            minimumHeight = dp(68)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            isClickable = true
            isFocusable = true
            contentDescription = if (here) "$word, this screen" else word
            if (here) {
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.parseColor("#E3EAF6"))   // pale blue: "you are here"
                }
            }
        }
    }

    /** The word under the icon: navy and bold on this screen, grey otherwise. */
    private fun label(activity: AppCompatActivity, word: String, here: Boolean): TextView {
        return TextView(activity).apply {
            text = word
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor(if (here) NAVY else GREY))
            setTypeface(null, if (here) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    /** Home and People: an icon with a word under it. */
    private fun button(
        activity: AppCompatActivity, icon: Int, word: String,
        here: Boolean, onTap: () -> Unit
    ): View {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val box = box(activity, word, here)
        val picture = ImageView(activity).apply {
            setImageResource(icon)
            setColorFilter(Color.parseColor(if (here) NAVY else GREY))   // one colour, to match
        }
        box.addView(picture, LinearLayout.LayoutParams(dp(32), dp(32)))
        box.addView(label(activity, word, here), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })
        box.setOnClickListener { onTap() }
        return box
    }

    /** + Add: a navy circle with a white plus, so it stands out. */
    private fun addButton(activity: AppCompatActivity, here: Boolean, onTap: () -> Unit): View {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val box = box(activity, "Add", here)
        val circle = TextView(activity).apply {
            text = "+"
            textSize = 26f
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(NAVY))
            }
        }
        box.addView(circle, LinearLayout.LayoutParams(dp(40), dp(40)))
        box.addView(label(activity, "Add", here), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })
        box.setOnClickListener { onTap() }
        return box
    }

    /** Back to the shopping list, closing the screens in between. */
    private fun goHome(activity: AppCompatActivity, current: Int) {
        if (current == HOME) return
        val intent = Intent(activity, ShoppingList::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        activity.startActivity(intent)
        activity.finish()
    }

    /** Goes to the shopping list and opens Add from there. */
    private fun openAddFromList(activity: AppCompatActivity) {
        val intent = Intent(activity, ShoppingList::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        intent.putExtra("openAdd", true)
        activity.startActivity(intent)
        activity.finish()
    }

    /** People: follows the same lock as in Settings. */
    private fun goPeople(activity: AppCompatActivity, current: Int) {
        if (current == PEOPLE) return
        val prefs = activity.getSharedPreferences("shopping", AppCompatActivity.MODE_PRIVATE)
        if (!prefs.getBoolean("mayChangeShared", true)) {
            val dialog = AlertDialog.Builder(activity)
                .setTitle("This setting is locked")
                .setMessage("Only the list owner, or members with permission, can change this setting.")
                .setPositiveButton("OK", null)
                .show()
            dialog.findViewById<TextView>(android.R.id.message)?.textSize = 19f
            return
        }
        activity.startActivity(Intent(activity, PeopleScreen::class.java))
    }
}