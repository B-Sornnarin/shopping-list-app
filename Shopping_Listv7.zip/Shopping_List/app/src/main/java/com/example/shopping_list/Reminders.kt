package com.example.shopping_list

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Calendar
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * "Remind me after N days, at a chosen time" (Settings, screen 3.9).
 *
 * Once a day, at the chosen time, Android wakes the app, even when it is closed.
 * If things have been on the list, not ticked, for N days or more:
 *   "Still on your list – 3 things to get: Milk, Eggs and Bread".
 * At most once a day. Tapping it opens the list.
 */
object Reminders {

    private const val WORK = "daily_reminder"
    private const val CHANNEL = "reminders"
    private const val TAG = "Remind"
    private const val DAY = 24L * 60 * 60 * 1000

    // Firebase item ids start with the time they were added, written in these characters.
    private const val PUSH_CHARS =
        "-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz"

    /** The chosen hour (24-hour clock), 10 unless changed. */
    fun hour(context: Context): Int =
        context.getSharedPreferences("shopping", Context.MODE_PRIVATE).getInt("remindHour", 10)

    /** The chosen minute, 0 unless changed. */
    fun minute(context: Context): Int =
        context.getSharedPreferences("shopping", Context.MODE_PRIVATE).getInt("remindMinute", 0)

    /** Saves a new time and moves the daily check to it. */
    fun setTime(context: Context, hour: Int, minute: Int) {
        context.getSharedPreferences("shopping", Context.MODE_PRIVATE).edit()
            .putInt("remindHour", hour)
            .putInt("remindMinute", minute)
            .apply()
        schedule(context, moved = true)
    }

    /** "10:00 am", "12:30 pm", "4:45 pm" */
    fun label(hour: Int, minute: Int): String {
        val h = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        val amPm = if (hour < 12) "am" else "pm"
        return "$h:${minute.toString().padStart(2, '0')} $amPm"
    }

    /** The chosen time as words, e.g. "10:00 am". */
    fun label(context: Context): String = label(hour(context), minute(context))

    /**
     * Sets up the daily check at the chosen time. Safe to call every time the list opens.
     * [moved] = true when the time was just changed in Settings, so it starts again at the new time.
     */
    fun schedule(context: Context, moved: Boolean = false) {
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour(context))
            set(Calendar.MINUTE, minute(context))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_MONTH, 1)
        }
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(next.timeInMillis - now.timeInMillis, TimeUnit.MILLISECONDS)
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
            )
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK,
            if (moved) ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE
            else ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    /** For testing: checks straight away, ignoring the days and the once-a-day rule. */
    fun testNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInputData(workDataOf("test" to true))
            .build()
        WorkManager.getInstance(context).enqueue(request)
    }

    /** When an item was added, read from its Firebase id. */
    private fun addedAt(id: String): Long? {
        if (id.length < 8) return null
        var time = 0L
        for (c in id.take(8)) {
            val i = PUSH_CHARS.indexOf(c)
            if (i < 0) return null
            time = time * 64 + i
        }
        return time
    }

    /** The daily check. Runs in the background. */
    fun check(context: Context, test: Boolean) {
        val prefs = context.getSharedPreferences("shopping", Context.MODE_PRIVATE)
        if (!test && !prefs.getBoolean("remind", true)) { Log.d(TAG, "Remind me is Off"); return }
        val listId = Session.listId(context) ?: run { Log.d(TAG, "No list"); return }

        val now = System.currentTimeMillis()
        if (!test && now - prefs.getLong("lastReminded", 0L) < 20 * 60 * 60 * 1000L) {
            Log.d(TAG, "Already reminded today"); return
        }

        // Read the list once (waits up to 30 seconds for the internet)
        val latch = CountDownLatch(1)
        var snapshot: DataSnapshot? = null
        FirebaseDatabase.getInstance().getReference("lists").child(listId).child("items")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) { snapshot = s; latch.countDown() }
                override fun onCancelled(error: DatabaseError) { latch.countDown() }
            })
        latch.await(30, TimeUnit.SECONDS)
        val items = snapshot ?: run { Log.d(TAG, "Could not read the list"); return }

        // Count by calendar days: anything added yesterday counts as "1 day" this morning.
        val days = prefs.getInt("remindDays", 7)
        fun dayNumber(time: Long): Long {
            val c = Calendar.getInstance()
            c.timeInMillis = time
            c.set(Calendar.HOUR_OF_DAY, 12)   // midday, so clock changes never matter
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis / DAY
        }
        val today = dayNumber(now)
        val names = items.children.filter { child ->
            val done = child.child("done").value == true
            val added = addedAt(child.key ?: "") ?: now
            val daysWaiting = today - dayNumber(added)
            !done && (test || daysWaiting >= days)
        }.map { it.child("name").value?.toString() ?: "" }.filter { it.isNotEmpty() }

        if (names.isEmpty()) { Log.d(TAG, "Nothing waiting $days days or more"); return }

        show(context, names)
        prefs.edit().putLong("lastReminded", now).apply()
    }

    @SuppressLint("MissingPermission")
    private fun show(context: Context, names: List<String>) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) { Log.d(TAG, "Not shown: notifications not allowed"); return }

        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH
            )
            channel.description = "When things have been on the list for a while"
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        // "Milk" / "Milk and Eggs" / "Milk, Eggs and Bread" / "Milk, Eggs, Bread and 2 more"
        val list = when (names.size) {
            1 -> names[0]
            2 -> "${names[0]} and ${names[1]}"
            3 -> "${names[0]}, ${names[1]} and ${names[2]}"
            else -> "${names[0]}, ${names[1]}, ${names[2]} and ${names.size - 3} more"
        }
        val things = if (names.size == 1) "1 thing to get" else "${names.size} things to get"
        val text = "$things: $list"

        val open = PendingIntent.getActivity(
            context, 1,
            Intent(context, ShoppingList::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Still on your list")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(5000, notification)   // one reminder at a time
            Log.d(TAG, "Shown: $text")
        } catch (e: SecurityException) {
            Log.d(TAG, "Not shown: blocked by Android")
        }
    }
}

/** Android runs this once a day, even when the app is closed. */
class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        Reminders.check(applicationContext, inputData.getBoolean("test", false))
        return Result.success()
    }
}