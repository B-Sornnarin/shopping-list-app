package com.example.shopping_list

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * The shopping list, kept in Firebase.
 *
 * Every device listening to the same list sees a change immediately,
 * which is requirement 3, real-time synchronisation.
 */
object ListRepository {

    /** Which list this device is on. Set once when the screen opens. */
    private var listId: String = ""

    private val itemsRef
        get() = FirebaseDatabase.getInstance()
            .getReference("lists")
            .child(listId)
            .child("items")

    private var listener: ValueEventListener? = null

    fun use(id: String) {
        listId = id
    }

    /**
     * Calls [onChanged] with the whole list, once straight away and
     * again every time anything changes, on any device.
     */
    fun listen(onChanged: (MutableList<Item>) -> Unit) {
        listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val items = mutableListOf<Item>()
                snapshot.children.forEach { child ->
                    items.add(
                        Item(
                            id = child.key ?: "",
                            name = child.child("name").value?.toString() ?: "",
                            category = child.child("category").value?.toString() ?: "",
                            picture = child.child("picture").value?.toString() ?: "",
                            count = (child.child("count").value as? Long)?.toInt() ?: 1,
                            done = child.child("done").value == true,
                            addedBy = child.child("addedBy").value?.toString() ?: ""
                        )
                    )
                }
                onChanged(items)
            }

            override fun onCancelled(error: DatabaseError) {
                // Nothing to do: the list simply stays as it was.
            }
        }
        itemsRef.addValueEventListener(listener!!)
    }

    /** Stops listening, so a closed screen does not keep updating. */
    fun stopListening() {
        listener?.let { itemsRef.removeEventListener(it) }
        listener = null
    }

    /**
     * Adds a thing, or raises its count if it is already on the list.
     * [addedBy] is the name of the person adding it.
     */
    fun add(name: String, category: String, picture: String, addedBy: String = "") {
        // A single-value listener, not get(): get() can fail with
        // "Client is offline".
        itemsRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val existing = snapshot.children.firstOrNull {
                    it.child("name").value?.toString() == name
                }

                if (existing != null) {
                    val current = (existing.child("count").value as? Long)?.toInt() ?: 1
                    existing.ref.child("count").setValue(current + 1)
                    // Something wanted again is not bought yet.
                    existing.ref.child("done").setValue(false)
                } else {
                    val key = itemsRef.push().key ?: return
                    itemsRef.child(key).setValue(
                        mapOf(
                            "name" to name,
                            "category" to category,
                            "picture" to picture,
                            "count" to 1,
                            "done" to false,
                            "addedBy" to addedBy
                        )
                    )
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    /**
     * Changes how many of something are wanted, from the – 1 + row on
     * the list. Asking for more of a thing already ticked off means it
     * has not all been bought, so it comes back un-ticked.
     */
    fun setCount(item: Item, count: Int) {
        if (count < 1) return
        val row = itemsRef.child(item.id)
        row.child("count").setValue(count)
        if (count > item.count && item.done) row.child("done").setValue(false)
    }

    /**
     * Follows a renamed picture through to the list, so a thing called
     * "Photo 1" this morning does not stay "Photo 1" on the list after
     * it has been given a proper name.
     */
    fun renameAll(oldName: String, newName: String) {
        if (listId.isEmpty() || Names.same(oldName, newName)) return
        itemsRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children
                    .filter { Names.same(it.child("name").value?.toString() ?: "", oldName) }
                    .forEach { it.ref.child("name").setValue(newName) }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun setDone(item: Item, done: Boolean) {
        itemsRef.child(item.id).child("done").setValue(done)
    }

    fun remove(item: Item) {
        itemsRef.child(item.id).removeValue()
    }

    /** Clears the whole list, for "Start a new list". Undo uses restore(). */
    fun clear() {
        itemsRef.removeValue()
    }

    /** Puts a deleted item back exactly as it was, for Undo. */
    fun restore(item: Item) {
        itemsRef.child(item.id).setValue(
            mapOf(
                "name" to item.name,
                "category" to item.category,
                "picture" to item.picture,
                "count" to item.count,
                "done" to item.done,
                "addedBy" to item.addedBy
            )
        )
    }
}