package com.example.shopping_list

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * The press-and-hold menu, like holding an app on the phone's home screen:
 * the screen dims, the item lifts up, and a small menu appears next to it.
 * Tapping the dim area (or Back) closes it. Used on the list and on Add.
 */
object HoldMenu {

    /** One menu row: the words, their colour, and what tapping does. */
    class Row(
        val words: String,
        val colour: String,
        val onTap: () -> Unit
    )

    private const val TAG = "holdMenu"

    /**
     * Shows the menu next to [item]. [keepAbove] is a view the menu must not cover
     * (e.g. "+ Add" or "Add selected"); near it, the menu goes above the item instead.
     */
    fun show(activity: Activity, item: View, keepAbove: View?, rows: List<Row>) {
        close(activity, animate = false)
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = activity.findViewById<ViewGroup>(android.R.id.content)
        val rootAt = IntArray(2).also { root.getLocationOnScreen(it) }
        val itemAt = IntArray(2).also { item.getLocationOnScreen(it) }
        val itemX = (itemAt[0] - rootAt[0]).toFloat()
        val itemY = (itemAt[1] - rootAt[1]).toFloat()

        // 1. The dimmed screen. Tapping it closes the menu.
        val layer = FrameLayout(activity).apply {
            tag = TAG
            setBackgroundColor(Color.parseColor("#80000000"))
            alpha = 0f
            isClickable = true
            setOnClickListener { close(activity) }
        }

        // 2. A copy of the item, lifted up on a white card.
        val snapshot = Bitmap.createBitmap(item.width, item.height, Bitmap.Config.ARGB_8888)
        item.draw(Canvas(snapshot))
        val lifted = ImageView(activity).apply {
            setImageBitmap(snapshot)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
            }
            clipToOutline = true
            elevation = dp(12).toFloat()
            x = itemX
            y = itemY
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        layer.addView(lifted, FrameLayout.LayoutParams(item.width, item.height))

        // 3. The small menu, sized to fit its words.
        val menu = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
            }
            clipToOutline = true
            elevation = dp(16).toFloat()
            isClickable = true   // taps on the menu itself don't close it
        }
        rows.forEachIndexed { i, row ->
            if (i > 0) {
                menu.addView(View(activity).apply {
                    setBackgroundColor(Color.parseColor("#E6E9EF"))
                }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
            }
            menu.addView(rowView(activity, row))
        }

        // Under the item if there is room above [keepAbove]; otherwise above the item.
        menu.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        // As wide as its longest line (never less than a neat minimum, never off the screen)
        val menuW = menu.measuredWidth
            .coerceAtLeast(dp(220))
            .coerceAtMost(root.width - dp(24))
        menu.measure(
            View.MeasureSpec.makeMeasureSpec(menuW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val menuH = menu.measuredHeight
        val limit = if (keepAbove != null) {
            IntArray(2).also { keepAbove.getLocationOnScreen(it) }[1] - rootAt[1]
        } else {
            root.height - dp(12)
        }
        val below = itemY + item.height + dp(12) + menuH <= limit
        menu.y = if (below) itemY + item.height + dp(12) else itemY - menuH - dp(12)
        menu.x = itemX.coerceIn(dp(12).toFloat(), (root.width - menuW - dp(12)).toFloat())
        menu.pivotX = (itemX + item.width / 2f - menu.x).coerceIn(0f, menuW.toFloat())
        menu.pivotY = if (below) 0f else menuH.toFloat()
        layer.addView(menu, FrameLayout.LayoutParams(menuW, FrameLayout.LayoutParams.WRAP_CONTENT))
        root.addView(layer, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // Gentle movement: dim in, item lifts, menu grows out from the item.
        layer.animate().alpha(1f).setDuration(160).start()
        lifted.animate().scaleX(1.04f).scaleY(1.04f).setDuration(180).start()
        menu.scaleX = 0.85f
        menu.scaleY = 0.85f
        menu.alpha = 0f
        menu.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
    }

    /** Closes the menu. True if one was open. */
    fun close(activity: Activity, animate: Boolean = true): Boolean {
        val root = activity.findViewById<ViewGroup>(android.R.id.content) ?: return false
        val layer = root.findViewWithTag<View>(TAG) ?: return false
        layer.tag = null
        if (!animate) {
            root.removeView(layer)
        } else {
            layer.animate().alpha(0f).setDuration(140)
                .withEndAction { root.removeView(layer) }.start()
        }
        return true
    }

    /** One row: big enough to tap, small enough to look neat. */
    private fun rowView(activity: Activity, row: Row): View {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        return LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(58)
            setPadding(dp(18), 0, dp(24), 0)
            val ripple = TypedValue()
            activity.theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)
            setBackgroundResource(ripple.resourceId)
            isClickable = true
            contentDescription = row.words
            setOnClickListener {
                close(activity)
                row.onTap()
            }

            // Words only. Emoji are missing from the fonts on some
            // cheaper phones, and a blank gap reads worse than no icon.

            addView(TextView(activity).apply {
                text = row.words
                textSize = 18f
                setTextColor(Color.parseColor(row.colour))
                maxLines = 1
            })
        }
    }
}

/**
 * The "Change the name" box, opened by press-and-hold on a picture,
 * from Add (2.1) and from Settings > Pictures (3.6).
 *
 * It lives here rather than in either screen because both use it, and
 * both reach it the same way: hold the picture, then tap the menu.
 */
object RenameItem {

    fun ask(activity: Activity, item: LibraryItem) {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val input = EditText(activity).apply {
            setText(item.name)
            setSelection(text.length)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            textSize = 20f
            setSingleLine()
        }
        val holder = FrameLayout(activity).apply { setPadding(dp(22), dp(4), dp(22), dp(4)) }
        holder.addView(input, FrameLayout.LayoutParams(dp(210), wrap))

        MaterialAlertDialogBuilder(activity, R.style.Shopping_SmallDialog)
            .setTitle("Change the name")
            .setView(holder)
            .setPositiveButton("Save") { _, _ ->
                val typed = input.text.toString().trim()
                if (typed.isEmpty()) {
                    Toast.makeText(activity, "Please type a name", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (Library.renameCustom(activity, item, typed) == null) {
                    Toast.makeText(activity, "There is already a picture called $typed",
                        Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(activity, "Now called $typed", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()

    }
}

/**
 * "Which group?", opened by press-and-hold on a picture.
 *
 * Every thing starts in the group it was built with, but a household
 * shops in its own order: a shop with a bakery aisle wants Bread in
 * Bakery, not Fridge. Built-in things can move too — that is the whole
 * point of being able to add a group.
 */
object ChooseGroup {

    fun ask(activity: Activity, item: LibraryItem) {
        val listId = Session.listId(activity) ?: return

        // The household's own groups, in their own order.
        Categories.once(listId) { groups ->
            if (activity.isFinishing || activity.isDestroyed) return@once
            val now = Library.groupFor(activity, item)
            val at = groups.indexOf(now)

            MaterialAlertDialogBuilder(activity)
                .setTitle("Which category for ${item.name}?")
                .setSingleChoiceItems(groups.toTypedArray(), at) { dialog, which ->
                    val chosen = groups[which]
                    dialog.dismiss()
                    if (chosen == now) return@setSingleChoiceItems
                    Library.setGroup(activity, item, chosen)
                    Toast.makeText(activity, "${item.name} is now in $chosen",
                        Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}