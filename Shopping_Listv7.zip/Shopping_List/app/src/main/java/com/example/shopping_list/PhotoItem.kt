package com.example.shopping_list

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.mlkit.common.model.LocalModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.custom.CustomImageLabelerOptions
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.io.File

/**
 * Screen 2.1b Photo.
 *
 * The camera opens as soon as this screen does, so tapping the camera
 * on Add goes straight to taking a picture.
 *
 * Two recognisers, both on the phone, no internet:
 *  1. Our own model, trained on the household's real groceries with
 *     Teachable Machine. If it is sure, Check (2.2) asks "Tomato?".
 *  2. If not (or it saw "Other"), the general model names the kind
 *     ("Vegetable") and she taps the right picture from that group.
 *  3. If neither helps, the photo itself becomes the picture:
 *     "Add this photo to the list" keeps it, with a name if she
 *     wants to give one, and saves it to Settings > Pictures so it
 *     can be tapped again next week, on any device on the list.
 */
class PhotoItem : AppCompatActivity() {

    private lateinit var preview: ImageView
    private lateinit var lookingText: TextView
    private lateinit var instruction: TextView
    private lateinit var choiceTitle: TextView
    private lateinit var choiceList: RecyclerView
    private lateinit var usePhotoButton: View

    /** Shorthand for ViewGroup.LayoutParams.WRAP_CONTENT. */
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT


    private val photoFile: File
        get() = File(cacheDir, "camera").apply { mkdirs() }.let { File(it, "add_photo.jpg") }

    private val photoUri: Uri
        get() = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)

    /** Our own model, from assets/grocery.tflite (Teachable Machine, quantized). */
    private val groceryLabeler by lazy {
        val model = LocalModel.Builder().setAssetFilePath("grocery.tflite").build()
        ImageLabeling.getClient(
            CustomImageLabelerOptions.Builder(model)
                .setConfidenceThreshold(0.6f)   // only when it is fairly sure
                .setMaxResultCount(3)
                .build()
        )
    }

    /** "0 Tomato", "1 Apple"… from assets/grocery_labels.txt, by number. */
    private val groceryNames: List<String> by lazy {
        try {
            assets.open("grocery_labels.txt").bufferedReader().readLines().map { line ->
                val trimmed = line.trim()
                trimmed.substringAfter(' ', trimmed)   // "0 Tomato" → "Tomato"
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** True until the first photo is taken, so a straight cancel goes back to Add. */
    private var firstShot = true

    private val takePhoto = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { taken: Boolean ->
        if (taken) {
            firstShot = false
            recognise()
        } else if (firstShot) {
            // She tapped the camera on Add and then changed her mind.
            // Go straight back, rather than leaving her on a screen
            // she never asked to see.
            finish()
        }
    }

    /** Check said Yes: pass the item straight back to Add. */
    private val checkLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            setResult(Activity.RESULT_OK, result.data)
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photo_item)
        Library.load(this)

        preview = findViewById(R.id.photoPreview)
        lookingText = findViewById(R.id.lookingText)
        instruction = findViewById(R.id.instructionText)
        choiceTitle = findViewById(R.id.choiceTitle)
        choiceList = findViewById(R.id.choiceList)
        choiceList.layoutManager = GridLayoutManager(this, Pictures.columns(this))

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }
        findViewById<View>(R.id.cameraButton).setOnClickListener { openCamera() }

        usePhotoButton = findViewById(R.id.usePhotoButton)
        usePhotoButton.setOnClickListener { askForName() }

        // Tapping the camera on Add means "take a photo", so the camera
        // opens straight away: one tap, not two. The button above is
        // then there for trying again.
        if (savedInstanceState == null) openCamera()
    }

    private fun openCamera() {
        hideChoices()
        usePhotoButton.visibility = View.GONE
        try {
            takePhoto.launch(photoUri)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "This device has no camera. Try Type instead.",
                Toast.LENGTH_LONG).show()
        }
    }

    /** Shows the photo, then asks our own model first. */
    private fun recognise() {
        val options = BitmapFactory.Options().apply { inSampleSize = 4 }
        preview.setImageBitmap(BitmapFactory.decodeFile(photoFile.absolutePath, options))
        lookingText.visibility = View.VISIBLE

        // There is a photo now, so keeping it is always an option, even
        // if nothing below works out what it is.
        usePhotoButton.visibility = View.VISIBLE

        val image = try {
            InputImage.fromFilePath(this, photoUri)   // also turns it upright
        } catch (e: Exception) {
            return notFound()
        }

        groceryLabeler.process(image)
            .addOnSuccessListener { labels ->
                val best = labels.maxByOrNull { it.confidence }
                val name = best?.text?.ifEmpty { groceryNames.getOrNull(best.index) ?: "" } ?: ""
                Log.d("Photo", "Our model: $name ${((best?.confidence ?: 0f) * 100).toInt()}%")

                // "Other", or a name not in the library, falls through.
                val match = if (name.isEmpty()) null else Library.match(name)
                if (match != null) {
                    lookingText.visibility = View.GONE
                    check(match)
                } else {
                    recogniseGeneral(image)
                }
            }
            .addOnFailureListener { e ->
                Log.d("Photo", "Our model failed: ${e.message}")   // e.g. grocery.tflite missing
                recogniseGeneral(image)
            }
    }

    /** The general model: one thing, or at least the kind of thing. */
    private fun recogniseGeneral(image: InputImage) {
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { labels ->
                lookingText.visibility = View.GONE
                val words = labels.sortedByDescending { it.confidence }.map { it.text }
                Log.d("Photo", "General model: $words")

                val match = Library.matchPhoto(words)
                val kind = Library.categoryFor(words)
                when {
                    match != null -> check(match)
                    kind != null -> showChoices(kind)
                    else -> notFound()
                }
            }
            .addOnFailureListener { notFound() }
    }

    /** "It looks like Fruit & veg. Tap the right one:" and that group's pictures. */
    private fun showChoices(category: String) {
        val group = Library.items.filter { it.category == category }.toMutableList()

        choiceTitle.text = "It looks like $category. Tap the right one:"
        choiceTitle.visibility = View.VISIBLE
        instruction.visibility = View.GONE
        choiceList.visibility = View.VISIBLE
        choiceList.adapter = LibraryAdapter(
            group,
            onSelectionChanged = {},
            selectable = false,
            onTapped = { item -> addNow(item) }
        )
        choiceList.scrollToPosition(0)
    }

    private fun hideChoices() {
        choiceTitle.visibility = View.GONE
        choiceList.visibility = View.GONE
        instruction.visibility = View.VISIBLE
    }

    /** She tapped the picture herself, so it goes straight on the list. */
    private fun addNow(item: LibraryItem) {
        val result = Intent()
        result.putStringArrayListExtra("names", arrayListOf(item.name))
        result.putStringArrayListExtra("categories", arrayListOf(item.category))
        result.putStringArrayListExtra("pictures", arrayListOf(item.picture))
        setResult(Activity.RESULT_OK, result)
        finish()
    }

    private fun notFound() {
        lookingText.visibility = View.GONE
        // Not knowing the name no longer means the photo is wasted:
        // the button underneath keeps it exactly as it is.
        Toast.makeText(this,
            "Not recognised. You can still add the photo below.",
            Toast.LENGTH_LONG).show()
    }

    /** The app guessed one thing from a photo, so it checks first (2.2). */
    private fun check(item: LibraryItem) {
        val intent = Intent(this, CheckItem::class.java)
        intent.putExtra("name", item.name)
        intent.putExtra("category", item.category)
        intent.putExtra("picture", item.picture)
        checkLauncher.launch(intent)
    }

    // ---------------------------------------------------------------
    //  Keeping the photo itself
    // ---------------------------------------------------------------

    /**
     * Asks what the thing is, with the app's guess filled in if it has
     * one. The name is optional: a photo she took of her own shampoo
     * is easier to recognise than any word.
     */
    private fun askForName() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val input = EditText(this).apply {
            // Empty to start with: nothing to rub out before typing, and
            // no guess of ours sitting there pretending to be her answer.
            hint = "Name"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            textSize = 20f
            setSingleLine()
        }
        val holder = FrameLayout(this).apply { setPadding(dp(22), dp(4), dp(22), dp(4)) }
        holder.addView(input, FrameLayout.LayoutParams(dp(210), wrap))

        val dialog = MaterialAlertDialogBuilder(this, R.style.Shopping_SmallDialog)
            .setTitle("What is it?")
            .setMessage("You can leave this empty.")
            .setView(holder)
            .setPositiveButton("Add to the list") { _, _ ->
                keepPhotoAs(input.text.toString().trim())
            }
            .setNegativeButton("Cancel", null)
            .show()

        dialog.findViewById<TextView>(android.R.id.message)?.textSize = 16f
    }

    /**
     * Saves the photo as the picture for [typed], puts that on the
     * shopping list, and adds it to Settings > Pictures (3.6) for every
     * device on the list.
     */
    private fun keepPhotoAs(typed: String) {
        val name = if (typed.isNotBlank()) typed else nextPhotoName()

        // A name already in the library keeps its place; only the
        // picture changes. Anything else joins as one of the
        // household's own things.
        var item = Library.items.firstOrNull { Names.same(it.name, name) }
        if (item == null) {
            Library.addCustom(this, name)
            item = Library.items.firstOrNull { Names.same(it.name, name) }
        }
        if (item == null) {
            Toast.makeText(this, "Could not be saved", Toast.LENGTH_SHORT).show()
            return
        }

        val saved = saveSmallCopy(item.id)
        if (saved != null) {
            Library.setPicture(this, item.id, saved.absolutePath)
            // Every other phone and tablet on the list gets it too.
            Session.listId(this)?.let {
                SharedPictures.upload(this, it, item.id, saved, item.name)
            }
        }

        addNow(item)
    }

    /** "Photo 1", "Photo 2"… when she would rather not type a name. */
    private fun nextPhotoName(): String {
        var n = 1
        while (Library.items.any { Names.same(it.name, "Photo $n") }) n++
        return "Photo $n"
    }

    /**
     * Keeps a small, upright copy of the photo. A camera photo can be
     * 4000 pixels wide; the list never shows one bigger than about
     * 100dp, so a 600-pixel copy looks the same and loads quickly.
     */
    private fun saveSmallCopy(itemId: String): File? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(photoFile.absolutePath, bounds)
            if (bounds.outWidth <= 0) return null

            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 600) sample *= 2
            val bitmap = BitmapFactory.decodeFile(
                photoFile.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: return null

            val upright = turnUpright(bitmap)
            val file = File(filesDir, "$itemId.jpg")
            file.outputStream().use { upright.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            file
        } catch (e: Exception) {
            Log.d("Photo", "Could not keep the photo: $e")
            null
        }
    }

    /** Many phones save photos sideways and only note the turn. */
    private fun turnUpright(bitmap: Bitmap): Bitmap {
        val degrees = when (ExifInterface(photoFile.absolutePath).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
        )) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> return bitmap
        }
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}