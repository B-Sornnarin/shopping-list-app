package com.example.shopping_list

/**
 * A line on the list screen. Either a category heading or an item.
 *
 * The list is grouped, never filtered: a person with MCI does not
 * register something that cannot be seen, so nothing is hidden.
 */
sealed class Row {
    data class Heading(val title: String) : Row()
    data class ItemRow(val item: Item) : Row()
}