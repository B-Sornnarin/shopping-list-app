package com.example.shopping_list

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged

/**
 * Screen 2.1d Type.
 * After two or three letters the app shows what she may mean, with
 * pictures, so she rarely has to type a whole word.
 */
class TypeItem : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var list: LinearLayout
    private lateinit var didYouMean: TextView
    private lateinit var nothingFound: TextView

    /** Check (2.2) said Yes: pass the item straight back to Add. */
    private val checkLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            setResult(Activity.RESULT_OK, result.data)
            finish()
        }
        // On No, we stay here with her letters still typed.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_type_item)
        Library.load(this)   // include the household's own things

        input = findViewById(R.id.typeInput)
        list = findViewById(R.id.suggestionList)
        didYouMean = findViewById(R.id.didYouMeanText)
        nothingFound = findViewById(R.id.nothingFoundText)

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }

        // New suggestions with every letter.
        input.doAfterTextChanged { showSuggestions(it?.toString() ?: "") }

        // The keyboard's Done key picks the first suggestion.
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                Library.suggestions(input.text.toString()).firstOrNull()?.let { check(it) }
                true
            } else false
        }

        input.requestFocus()
    }

    private fun showSuggestions(typed: String) {
        list.removeAllViews()
        val found = Library.suggestions(typed)

        // Not in the pictures? Offer to add exactly what she typed.
        // Only from two letters on, so one stray tap adds nothing.
        val offerNew = Names.key(typed).length >= 2 && !Library.isKnown(typed)

        didYouMean.visibility = if (found.isEmpty()) View.GONE else View.VISIBLE
        nothingFound.text = "Not in the pictures yet"
        nothingFound.visibility = if (found.isEmpty() && offerNew) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(this)

        // Things already in the library, with their pictures.
        for (item in found) {
            val row = inflater.inflate(R.layout.row_suggestion, list, false)
            Pictures.show(row.findViewById<ImageView>(R.id.suggestionPicture),
                Library.pictureFor(this, item))
            row.findViewById<TextView>(R.id.suggestionName).text = boldStart(item.name, typed)
            row.contentDescription = item.name
            row.setOnClickListener { check(item) }
            list.addView(row)
        }

        // Then "+ Add “Tahini”" at the bottom.
        if (offerNew) {
            val newItem = Library.custom(typed)
            val row = inflater.inflate(R.layout.row_suggestion, list, false)
            Pictures.show(row.findViewById<ImageView>(R.id.suggestionPicture), newItem.picture)
            row.findViewById<TextView>(R.id.suggestionName).text =
                "+  Add \u201C${newItem.name}\u201D"
            row.contentDescription = "Add ${newItem.name}"
            row.setOnClickListener { check(newItem, isNew = true) }
            list.addView(row)
        }
    }

    /** "Bro" + "Broccoli" → **Bro**ccoli, as in the wireframe. */
    private fun boldStart(name: String, typed: String): CharSequence {
        val t = Names.key(typed)
        if (!name.lowercase().startsWith(t)) return name
        return SpannableString(name).apply {
            setSpan(StyleSpan(Typeface.BOLD), 0, t.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    /** The app guessed from letters, so it checks first (2.2). */
    private fun check(item: LibraryItem, isNew: Boolean = false) {
        val intent = Intent(this, CheckItem::class.java)
        intent.putExtra("name", item.name)
        intent.putExtra("category", item.category)
        intent.putExtra("picture", item.picture)
        intent.putExtra("isNew", isNew)
        checkLauncher.launch(intent)
    }
}