package com.example.shopping_list

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * The household's favourites, kept in Firebase so everyone on the
 * list shares them:
 *
 *   lists / KQZPMT / favourites / lib_milk = true
 *
 * Nothing is a favourite until someone chooses it.
 */
object Favourites {

    private var listId: String? = null
    private var ref: DatabaseReference? = null
    private var listener: ValueEventListener? = null
    private val ids = mutableSetOf<String>()
    private val watchers = mutableListOf<() -> Unit>()

    /** True once the favourites have arrived from Firebase. */
    var loaded = false
        private set

    /** Starts keeping the favourites up to date. Safe to call often. */
    fun start(listId: String) {
        if (this.listId == listId && listener != null) return
        stop()
        this.listId = listId
        loaded = false

        val r = FirebaseDatabase.getInstance().getReference("lists")
            .child(listId).child("favourites")
        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                ids.clear()
                snapshot.children.filter { it.value == true }.mapNotNullTo(ids) { it.key }
                loaded = true
                tellWatchers()
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        r.addValueEventListener(l)
        ref = r
        listener = l
    }

    private fun stop() {
        val r = ref
        val l = listener
        if (r != null && l != null) r.removeEventListener(l)
        ref = null
        listener = null
        ids.clear()
    }

    fun isFavourite(itemId: String) = itemId in ids

    fun hasAny() = ids.isNotEmpty()

    /**
     * Makes something a favourite, or takes it out. Each one is saved
     * on its own, so nothing else is touched, and every screen hears
     * about it straight away.
     */
    fun set(itemId: String, favourite: Boolean) {
        val r = ref ?: return
        if (favourite) {
            ids.add(itemId)
            r.child(itemId).setValue(true)
        } else {
            ids.remove(itemId)
            r.child(itemId).removeValue()
        }
        tellWatchers()
    }

    private fun tellWatchers() {
        watchers.toList().forEach { it() }
    }

    /** Screens that show stars call this to hear about changes. */
    fun watch(watcher: () -> Unit) {
        watchers.add(watcher)
    }

    fun unwatch(watcher: () -> Unit) {
        watchers.remove(watcher)
    }
}