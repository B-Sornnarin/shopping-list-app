package com.example.shopping_list

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * The groups shown on the list (screen 3.2), kept in Firebase so the
 * whole household sees the same groups in the same order.
 *
 *   lists / KQZPMT / categories = ["Fruit & veg", "Fridge", ...]
 */
object Categories {

    /** The groups a new list starts with. A household may change them all. */
    val builtIn = listOf(
        "Fruit & veg", "Fridge", "Frozen", "Bathroom", "Cleaning", "Cupboard", "Other"
    )

    private fun ref(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists")
            .child(listId).child("categories")

    /**
     * Calls [onChanged] with the groups in order, now and after every
     * change on any device. Returns the listener so it can be stopped.
     */
    fun listen(listId: String, onChanged: (List<String>) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // The built-in groups seed a brand-new list. After that the
                // household's own list is the whole truth, so a group they
                // delete stays deleted instead of coming back.
                val saved = snapshot.children.mapNotNull { it.value?.toString() }
                onChanged(saved.ifEmpty { builtIn })
            }

            override fun onCancelled(error: DatabaseError) {
                onChanged(builtIn)
            }
        }
        ref(listId).addValueEventListener(listener)
        return listener
    }

    fun stop(listId: String, listener: ValueEventListener) {
        ref(listId).removeEventListener(listener)
    }

    /** Reads the groups once, for a menu that needs them right now. */
    fun once(listId: String, onLoaded: (List<String>) -> Unit) {
        ref(listId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val saved = snapshot.children.mapNotNull { it.value?.toString() }
                onLoaded(saved.ifEmpty { builtIn })
            }

            override fun onCancelled(error: DatabaseError) = onLoaded(builtIn)
        })
    }

    /** Saves the groups in this order. */
    fun save(listId: String, categories: List<String>) {
        ref(listId).setValue(categories)
    }
}