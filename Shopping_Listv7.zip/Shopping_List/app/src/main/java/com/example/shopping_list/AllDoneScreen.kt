package com.example.shopping_list

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Screen 2.5 All done: shown when the last thing is ticked.
 *
 * "Start a new list" clears the ticked items (the list screen offers Undo).
 * The phone's Back button returns to the list and clears nothing.
 */
class AllDoneScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_done)

        // Green circle behind the tick
        findViewById<TextView>(R.id.doneCircle).background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#2E7D32"))
        }

        // "You bought all 5 things." / "You bought the 1 thing on the list."
        val count = intent.getIntExtra("count", 0)
        findViewById<TextView>(R.id.doneText).text = when {
            count == 1 -> "You bought the 1 thing on the list."
            count > 1 -> "You bought all $count things."
            else -> "You bought everything on the list."
        }

        findViewById<Button>(R.id.startNewButton).setOnClickListener {
            setResult(Activity.RESULT_OK)   // the list clears, with Undo
            finish()
        }
    }
}