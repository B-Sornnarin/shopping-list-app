package com.example.shopping_list

import android.content.Context

/**
 * Which list this device is using.
 *
 * Stored once, so the app opens straight on the list every time:
 * participants said having to log in each time would be a reason
 * not to use the app at all.
 */
object Session {

    private const val FILE = "shopping"
    private const val KEY = "listId"

    fun listId(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY, null)

    fun setListId(context: Context, id: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY, id).apply()
    }

    /** Six letters, easy to read aloud and to type. */
    fun newListId(): String {
        val letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"   // no I or O: they look like 1 and 0
        return (1..6).map { letters.random() }.joinToString("")
    }
}