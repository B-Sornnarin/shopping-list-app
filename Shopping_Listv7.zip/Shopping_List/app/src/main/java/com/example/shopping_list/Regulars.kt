package com.example.shopping_list

import android.content.Context
import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener

/**
 * "Frequency" on Add, shared by the whole household: how many times each
 * thing has been added to the list THIS MONTH, by anyone, on any device.
 *
 *   lists / KQZPMT / monthlyCounts / 2026-10 / milk = 7
 *
 * Counting starts again on the 1st of each month: on 1 November the
 * October counts are simply no longer read, so Frequency starts empty.
 * Someone who joins the list sees the household's frequent things at once.
 */
object Regulars {

    /** Added this many times or more this month = shown under Frequency. */
    private const val OFTEN = 2
    private const val TAG = "Regulars"

    private var listId: String? = null
    private var month: String? = null
    private var listener: ValueEventListener? = null
    private val counts = mutableMapOf<String, Long>()
    private val watchers = mutableListOf<() -> Unit>()

    /** "2026-10": this month, on this phone's calendar. */
    private fun thisMonth(): String =
        java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.ROOT).format(java.util.Date())

    private fun ref(listId: String, month: String = thisMonth()): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists").child(listId)
            .child("monthlyCounts").child(month)

    /** "Sweet potato" → "sweet potato" with no characters Firebase forbids. */
    private fun key(name: String) = Names.firebaseKey(name)

    fun watch(watcher: () -> Unit) { watchers.add(watcher) }
    fun unwatch(watcher: () -> Unit) { watchers.remove(watcher) }

    /** Starts keeping the household's counts up to date. Safe to call often. */
    fun start(listId: String) {
        val now = thisMonth()
        if (this.listId == listId && month == now && listener != null) return
        stop()
        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                counts.clear()
                for (child in snapshot.children) {
                    val n = (child.value as? Number)?.toLong() ?: continue
                    counts[child.key ?: continue] = n
                }
                watchers.toList().forEach { it() }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d(TAG, "Cannot read counts: ${error.message}")
            }
        }
        ref(listId, now).addValueEventListener(l)
        this.listId = listId
        this.month = now
        listener = l
    }

    private fun stop() {
        val id = listId
        val l = listener
        val m = month
        if (id != null && l != null && m != null) ref(id, m).removeEventListener(l)
        listId = null
        month = null
        listener = null
        counts.clear()
    }

    /** Counts one more for each thing just added. Safe if two people add at once. */
    fun record(listId: String, names: List<String>) {
        for (name in names) {
            if (name.isBlank()) continue
            ref(listId).child(key(name)).runTransaction(object : Transaction.Handler {
                override fun doTransaction(data: MutableData): Transaction.Result {
                    val now = (data.value as? Number)?.toLong() ?: 0L
                    data.value = now + 1
                    return Transaction.success(data)
                }

                override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {}
            })
        }
    }

    /** How many times the household has added this thing. */
    fun timesAdded(name: String): Long = counts[key(name)] ?: 0L

    /**
     * The Frequency tab: what the household has added this month, most first.
     * If the month has turned over while the app was open, start the new count.
     */
    fun often(context: Context, library: List<LibraryItem>): List<LibraryItem> {
        val id = listId
        if (id != null && month != thisMonth()) {
            start(id)
            return emptyList()
        }
        return library.filter { timesAdded(it.name) >= OFTEN }
            .sortedByDescending { timesAdded(it.name) }
    }
}