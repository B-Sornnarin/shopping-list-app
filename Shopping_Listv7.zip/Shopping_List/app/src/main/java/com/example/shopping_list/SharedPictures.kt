package com.example.shopping_list

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Pictures shared by everyone on the list (Settings > Pictures > Change picture).
 *
 * A small copy of each changed picture is kept in Firebase, next to the list:
 *
 *   lists / KQZPMT / pictures / lib_milk = { itemId, name, data, updated }
 *
 * Every device watches this and saves new pictures as they arrive, so a
 * picture changed on the tablet shows on the phone too. The name travels
 * with it, so things a household typed in themselves (not in the built-in
 * library) get their photo on every device as well.
 */
object SharedPictures {

    private const val TAG = "SharedPictures"

    private var listId: String? = null
    private var listener: ValueEventListener? = null
    private val watchers = mutableListOf<() -> Unit>()

    private fun ref(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists").child(listId).child("pictures")

    private fun prefs(context: Context) =
        context.getSharedPreferences("shopping", Context.MODE_PRIVATE)

    /** Firebase keys cannot contain . # $ [ ] / */
    private fun key(itemId: String) = itemId.replace(Regex("[.#$\\[\\]/]"), "_")

    /** "Milk", " milk " and "MILK" are the same thing. */
    private fun nameKey(name: String) = "picName_" + name.trim().lowercase()

    /** The shared photo for this item name, if there is one on this device. */
    fun pathForName(context: Context, name: String): String? {
        val path = prefs(context).getString(nameKey(name), null) ?: return null
        return if (File(path).exists()) path else null
    }

    /** Screens that show pictures call this to redraw when a new one arrives. */
    fun watch(watcher: () -> Unit) { watchers.add(watcher) }
    fun unwatch(watcher: () -> Unit) { watchers.remove(watcher) }

    /** Shares a changed picture with every device on the list. */
    fun upload(context: Context, listId: String, itemId: String, file: File, name: String = "") {
        try {
            val small = shrink(file, 400) ?: return
            val bytes = ByteArrayOutputStream().also {
                small.compress(Bitmap.CompressFormat.JPEG, 75, it)
            }.toByteArray()
            val data = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val updated = System.currentTimeMillis()

            // This device already has it, so it doesn't download its own picture again.
            prefs(context).edit()
                .putLong("pic_$itemId", updated)
                .apply { if (name.isNotBlank()) putString(nameKey(name), file.absolutePath) }
                .apply()

            ref(listId).child(key(itemId)).setValue(
                mapOf("itemId" to itemId, "name" to name, "data" to data, "updated" to updated)
            )
            Log.d(TAG, "Shared $itemId '$name' (${bytes.size / 1024} KB)")
        } catch (e: Exception) {
            Log.d(TAG, "Could not share $itemId: $e")
        }
    }

    /** Starts saving pictures that others change. Safe to call often. */
    fun start(context: Context, listId: String) {
        if (this.listId == listId && listener != null) return
        stop()
        val app = context.applicationContext

        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var changed = false
                for (child in snapshot.children) {
                    val itemId = child.child("itemId").value?.toString() ?: continue
                    val name = child.child("name").value?.toString() ?: ""
                    val updated = (child.child("updated").value as? Number)?.toLong() ?: continue
                    if (prefs(app).getLong("pic_$itemId", 0L) >= updated) continue   // already have it
                    val data = child.child("data").value?.toString() ?: continue
                    try {
                        val bytes = Base64.decode(data, Base64.NO_WRAP)
                        // A new file name each time, so no old copy is ever shown by mistake.
                        val file = File(app.filesDir, "${itemId}_$updated.jpg")
                        file.writeBytes(bytes)

                        // By name: works even if this device has never had this item.
                        val edit = prefs(app).edit().putLong("pic_$itemId", updated)
                        if (name.isNotBlank()) edit.putString(nameKey(name), file.absolutePath)
                        edit.apply()

                        // By id: for things in the picture library (Milk, Broccoli…)
                        try {
                            Library.setPicture(app, itemId, file.absolutePath)
                        } catch (e: Exception) {
                            Log.d(TAG, "$itemId is not in this device's library; using the name instead")
                        }

                        changed = true
                        Log.d(TAG, "Received $itemId '$name'")
                    } catch (e: Exception) {
                        Log.d(TAG, "Could not save $itemId: $e")
                    }
                }
                if (changed) watchers.toList().forEach { it() }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d(TAG, "Cannot read shared pictures: ${error.message}")
            }
        }
        ref(listId).addValueEventListener(l)
        this.listId = listId
        listener = l
        Log.d(TAG, "Watching shared pictures for list $listId")
    }

    private fun stop() {
        val id = listId
        val l = listener
        if (id != null && l != null) ref(id).removeEventListener(l)
        listId = null
        listener = null
    }

    /** Loads the photo at about [maxSide] pixels on its longest side. */
    private fun shrink(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val decoded = BitmapFactory.decodeFile(
            file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: return null
        val scale = maxSide.toFloat() / maxOf(decoded.width, decoded.height)
        return if (scale >= 1f) decoded else Bitmap.createScaledBitmap(
            decoded, (decoded.width * scale).toInt(), (decoded.height * scale).toInt(), true
        )
    }
}