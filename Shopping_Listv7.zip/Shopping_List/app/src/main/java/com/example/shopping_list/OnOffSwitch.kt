package com.example.shopping_list

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo

/**
 * The On/Off switch from wireframe 3.0: a green pill saying "On",
 * or a grey pill saying "Off". TalkBack reads it as a normal switch.
 */
class OnOffSwitch @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var isChecked: Boolean = false
        set(value) {
            if (field == value) return
            field = value
            invalidate()
        }

    /** Called only when the person taps. */
    var onChanged: ((Boolean) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val onColour = 0xFF2E7D32.toInt()
    private val offColour = 0xFF6B6B6B.toInt()

    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = 15 * resources.displayMetrics.scaledDensity
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    init {
        isClickable = true
        isFocusable = true
    }

    /** 96 x 48 dp: a big target for older fingers. */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            resolveSize((96 * density).toInt(), widthMeasureSpec),
            resolveSize((48 * density).toInt(), heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f

        track.color = if (isChecked) onColour else offColour
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, track)

        // Knob on the right when On, on the left when Off.
        val gap = 4 * density
        val knobX = if (isChecked) w - r else r
        canvas.drawCircle(knobX, r, r - gap, thumb)

        // The word sits on the other side from the knob.
        val text = if (isChecked) "On" else "Off"
        val textX = if (isChecked) (w - 2 * r) / 2f + gap else 2 * r + (w - 2 * r) / 2f - gap
        val textY = r - (label.descent() + label.ascent()) / 2f
        canvas.drawText(text, textX, textY, label)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) performClick()
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        isChecked = !isChecked
        onChanged?.invoke(isChecked)
        return true
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        info.className = "android.widget.Switch"
        info.isCheckable = true
        info.isChecked = isChecked
    }
}