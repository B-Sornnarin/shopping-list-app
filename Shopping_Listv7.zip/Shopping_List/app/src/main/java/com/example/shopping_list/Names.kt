package com.example.shopping_list

import java.util.Locale

/**
 * One rule for names, used everywhere.
 * "Sorn", "SORN", "sorn" and " Sorn " are all the same person.
 */
object Names {

    /** For comparing and saving: lowercase, single spaces, no spaces at the ends. */
    fun key(name: String): String =
        name.trim().replace(Regex("\\s+"), " ").lowercase(Locale.ROOT)

    /** For showing on screen: "sORN smith" becomes "Sorn Smith". */
    fun display(name: String): String =
        key(name).split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { it.titlecase(Locale.ROOT) }
        }

    /** True if two names belong to the same person. */
    fun same(a: String, b: String): Boolean = key(a) == key(b)

    /** Firebase does not allow . # $ [ ] / in a key, so swap them for _. */
    fun firebaseKey(name: String): String =
        key(name).replace(Regex("[.#$\\[\\]/]"), "_")
}