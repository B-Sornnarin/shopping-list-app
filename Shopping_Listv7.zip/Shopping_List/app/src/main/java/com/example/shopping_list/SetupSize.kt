package com.example.shopping_list

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Screen 1.2 and 3.4 Picture size.
 *
 * The same screen serves set-up and Settings. Only the picture size is
 * set here: word size follows whatever the person has already chosen
 * in their phone's own settings, so nobody sets it twice.
 *
 * The preview is a real list row with a real picture in it, so the
 * choice is made against the thing itself.
 */
class SetupSize : AppCompatActivity() {

    private val sizes = listOf(48, 64, 96)   // Small, Medium, Large

    private lateinit var preview: ImageView
    private lateinit var buttons: List<TextView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup_size)
        Library.load(this)   // so the preview can borrow a real picture

        preview = findViewById(R.id.previewImage)
        buttons = listOf(
            findViewById(R.id.smallButton),
            findViewById(R.id.mediumButton),
            findViewById(R.id.largeButton)
        )

        // Milk, drawn exactly as the list would draw it: the household's
        // own photo if they have taken one, otherwise the built-in picture.
        Library.items.firstOrNull { Names.same(it.name, "Milk") }?.let {
            Pictures.show(preview, Library.pictureFor(this, it))
        }

        // Each button changes the preview straight away, so the choice
        // is made against what the person will actually see.
        buttons.forEachIndexed { at, button ->
            button.setOnClickListener { choose(sizes[at]) }
        }

        // Open on whatever was chosen last time, rather than on nothing.
        choose(
            getSharedPreferences("shopping", MODE_PRIVATE).getInt("pictureSize", 64),
            save = false
        )

        val fromSettings = intent.getBooleanExtra("fromSettings", false)

        // ‹ back button: only from Settings. During set-up there is nothing to go back to.
        val back = findViewById<View>(R.id.backButton)
        back.visibility = if (fromSettings) View.VISIBLE else View.GONE
        back.setOnClickListener { finish() }

        // "Step 2 of 3" belongs to set-up only.
        findViewById<TextView>(R.id.stepText).visibility =
            if (fromSettings) View.GONE else View.VISIBLE

        // Opened from Settings it simply closes; during set-up it
        // moves on to step 3.
        val next = findViewById<Button>(R.id.nextButton)
        next.text = if (fromSettings) "Done" else "Next"

        next.setOnClickListener {
            if (!fromSettings) {
                startActivity(android.content.Intent(this, SetupWhoElse::class.java))
            }
            finish()
        }
    }

    /**
     * Resizes the preview, marks the chosen button, and remembers it.
     * [save] is false when the screen is only catching up with the
     * choice already made.
     */
    private fun choose(sizeDp: Int, save: Boolean = true) {
        val chosen = if (sizeDp in sizes) sizeDp else 64

        val px = (chosen * resources.displayMetrics.density).toInt()
        preview.layoutParams.width = px
        preview.layoutParams.height = px
        preview.requestLayout()

        // Filled and navy for the one in use, plain outline for the rest.
        buttons.forEachIndexed { at, button ->
            val here = sizes[at] == chosen
            button.setBackgroundResource(
                if (here) R.drawable.button_selected else R.drawable.button_outline
            )
            button.setTextColor(
                android.graphics.Color.parseColor(if (here) "#1F3864" else "#1A1A1A")
            )
            button.setTypeface(null, if (here) android.graphics.Typeface.BOLD
            else android.graphics.Typeface.NORMAL)
            button.contentDescription =
                if (here) "${button.text}, chosen" else button.text
        }

        if (save) {
            getSharedPreferences("shopping", MODE_PRIVATE)
                .edit()
                .putInt("pictureSize", chosen)
                .apply()
        }
    }
}