package com.example.shopping_list

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * Screen 3.0 Settings, reached only from the gear on the list.
 *
 * Settings that only affect this person (reminders, notifications, how the
 * list looks, Log out) are always available. Settings that change things for
 * everyone (Pictures, Categories, People, Devices) are locked unless the
 * person is the list owner, or was given permission on People.
 */
class Settings : AppCompatActivity() {

    /** May this person change settings that affect everyone? Kept up to date live. */
    private var mayChangeShared = true

    private var permissionRef: DatabaseReference? = null
    private var permissionListener: ValueEventListener? = null

    /** The note at the top of MORE SETTINGS when some are locked. */
    private var lockedNote: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("shopping", MODE_PRIVATE)

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }

        // ---- REMINDERS AND SUGGESTIONS ----

        val remind = findViewById<OnOffSwitch>(R.id.remindSwitch)
        val daysRow = findViewById<View>(R.id.daysRow)
        val daysText = findViewById<TextView>(R.id.daysText)
        val fewer = findViewById<View>(R.id.fewerDaysButton)
        val more = findViewById<View>(R.id.moreDaysButton)

        // The reminder time, on its own line under "After − 1 day +"; tap to choose.
        val timeRow = findViewById<View>(R.id.timeRow)
        val timeButton = addReminderTime(timeRow)

        fun showDays() {
            val days = prefs.getInt("remindDays", 7)
            daysText.text = if (days == 1) "1 day" else "$days days"
            // With reminders off, the whole line (days and time) is faded and does nothing.
            val on = remind.isChecked
            daysRow.alpha = if (on) 1f else 0.4f
            timeRow.alpha = if (on) 1f else 0.4f
            fewer.isEnabled = on
            more.isEnabled = on
            timeButton.isEnabled = on
        }

        remind.isChecked = prefs.getBoolean("remind", true)
        remind.onChanged = { on ->
            prefs.edit().putBoolean("remind", on).apply()
            showDays()
            // Android 13 and newer must allow notifications for the reminder to show.
            if (on && !Notifier.canShow(this)) {
                androidx.core.app.ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 8
                )
            }
        }

        // FOR TESTING: press and hold "After … days" to see the reminder now.
        // Remove these 4 lines before handing in the final app.
        daysRow.setOnLongClickListener {
            Reminders.testNow(this)
            Toast.makeText(this, "Checking the list for a reminder…", Toast.LENGTH_SHORT).show()
            true
        }
        showDays()

        fewer.setOnClickListener {
            val days = (prefs.getInt("remindDays", 7) - 1).coerceAtLeast(1)
            prefs.edit().putInt("remindDays", days).apply()
            showDays()
        }
        more.setOnClickListener {
            val days = (prefs.getInt("remindDays", 7) + 1).coerceAtMost(30)
            prefs.edit().putInt("remindDays", days).apply()
            showDays()
        }

        val suggest = findViewById<OnOffSwitch>(R.id.suggestSwitch)
        suggest.isChecked = prefs.getBoolean("suggest", true)
        suggest.onChanged = { on -> prefs.edit().putBoolean("suggest", on).apply() }

        val notify = findViewById<OnOffSwitch>(R.id.notifySwitch)
        notify.isChecked = prefs.getBoolean("notify", false)
        notify.onChanged = { on ->
            prefs.edit().putBoolean("notify", on).apply()
            // Android 13 and newer asks the person once.
            if (on && !Notifier.canShow(this)) {
                androidx.core.app.ActivityCompat.requestPermissions(
                    this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7
                )
            }
        }

        // ---- HOW THE LIST LOOKS ----

        val groupCategory = findViewById<TextView>(R.id.groupCategoryButton)
        val groupNone = findViewById<TextView>(R.id.groupNoneButton)

        fun showGroupBy() {
            val byCategory = prefs.getString("groupBy", "category") != "none"
            choose(groupCategory, byCategory)
            choose(groupNone, !byCategory)
        }
        showGroupBy()

        groupCategory.setOnClickListener {
            prefs.edit().putString("groupBy", "category").apply()
            showGroupBy()
        }
        groupNone.setOnClickListener {
            prefs.edit().putString("groupBy", "none").apply()
            showGroupBy()
        }

        // ---- MORE SETTINGS ----

        // Picture size: only this person's screen, so always allowed.
        findViewById<View>(R.id.pictureSizeButton).setOnClickListener {
            val intent = Intent(this, SetupSize::class.java)
            intent.putExtra("fromSettings", true)
            startActivity(intent)
        }

        // These change things for everyone: only if allowed.
        findViewById<View>(R.id.picturesButton).setOnClickListener {
            ifAllowed { startActivity(Intent(this, PicturesScreen::class.java)) }
        }
        findViewById<View>(R.id.categoriesButton).setOnClickListener {
            ifAllowed { startActivity(Intent(this, CategoriesScreen::class.java)) }
        }
        findViewById<View>(R.id.peopleButton).setOnClickListener {
            ifAllowed { startActivity(Intent(this, PeopleScreen::class.java)) }
        }
        findViewById<View>(R.id.devicesButton).setOnClickListener {
            ifAllowed { startActivity(Intent(this, DevicesScreen::class.java)) }
        }

        // Log out: asks first, so a mis-tap does nothing.
        // Only this phone leaves. The list itself is not deleted. Always allowed.
        findViewById<View>(R.id.logOutButton).setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Log out?")
                .setMessage("This phone will leave the shopping list. The list is not deleted.")
                .setPositiveButton("Log out") { _, _ ->
                    getSharedPreferences("shopping", MODE_PRIVATE)
                        .edit().clear().apply()
                    Session.listId(this)?.let { Devices.unregister(this, it) }
                    startActivity(Intent(this, MainActivity::class.java))
                    finishAffinity()   // close every screen, start at Set up
                }
                .setNegativeButton("Stay", null)
                .show()
        }

        // ---- WHO MAY CHANGE SETTINGS FOR EVERYONE ----
        // Start with the last known answer (so it looks right at once), then keep it live.
        mayChangeShared = prefs.getBoolean("mayChangeShared", true)
        showPermission()
        watchPermission()
    }

    override fun onDestroy() {
        super.onDestroy()
        val ref = permissionRef
        val l = permissionListener
        if (ref != null && l != null) ref.removeEventListener(l)
    }

    /**
     * Listens to this person's entry on People:
     *   lists / KQZPMT / people / jj = { owner, canChange, … }
     * The list owner may always change everything.
     */
    private fun watchPermission() {
        val prefs = getSharedPreferences("shopping", MODE_PRIVATE)
        val listId = Session.listId(this) ?: return
        val myKey = Names.firebaseKey(prefs.getString("userName", "") ?: "")
        if (myKey.isEmpty()) return

        val ref = FirebaseDatabase.getInstance().getReference("lists")
            .child(listId).child("people").child(myKey)
        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) return   // not on People yet: leave as it is
                val owner = snapshot.child("owner").value == true
                val canChange = snapshot.child("canChange").value == true
                mayChangeShared = owner || canChange
                prefs.edit().putBoolean("mayChangeShared", mayChangeShared).apply()
                showPermission()
            }

            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(l)
        permissionRef = ref
        permissionListener = l
    }

    /** Fades the settings that affect everyone, and shows a note, if not allowed. */
    private fun showPermission() {
        val locked = !mayChangeShared
        val shared = listOf(
            R.id.picturesButton, R.id.categoriesButton, R.id.peopleButton, R.id.devicesButton
        )
        for (id in shared) {
            val button = findViewById<View>(id) ?: continue
            button.alpha = if (locked) 0.45f else 1f
            button.contentDescription = if (locked) "Locked" else null
        }

        // A short note above them, so it's clear why.
        val first = findViewById<View>(R.id.picturesButton) ?: return
        val parent = first.parent as? android.view.ViewGroup ?: return
        if (lockedNote == null) {
            val d = resources.displayMetrics.density
            lockedNote = TextView(this).apply {
                text = "🔒  Some settings are locked. Only the list owner, " +
                        "or members with permission, can change them."
                textSize = 16f
                setTextColor(Color.parseColor("#5B6475"))
                setPadding(0, (8 * d).toInt(), 0, (8 * d).toInt())
            }
            parent.addView(lockedNote, parent.indexOfChild(first))
        }
        lockedNote?.visibility = if (locked) View.VISIBLE else View.GONE
    }

    /** Opens the setting if allowed; otherwise explains, politely. */
    private fun ifAllowed(open: () -> Unit) {
        if (mayChangeShared) {
            open()
            return
        }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("This setting is locked")
            .setMessage("Only the list owner, or members with permission, can change this setting.")
            .setPositiveButton("OK", null)
            .show()
        dialog.findViewById<TextView>(android.R.id.message)?.textSize = 19f
    }

    /** The chosen Group by button: navy outline, pale blue fill, bold. */
    private fun choose(button: TextView, chosen: Boolean) {
        button.setBackgroundResource(
            if (chosen) R.drawable.button_selected else R.drawable.button_outline
        )
        button.setTextColor(Color.parseColor(if (chosen) "#1F3864" else "#1A1A1A"))
        button.setTypeface(null, if (chosen) Typeface.BOLD else Typeface.NORMAL)
        button.isSelected = chosen
    }
    /** If notifications were not allowed, turn the switch back Off and say why. */
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 7) return
        if (grantResults.firstOrNull() == android.content.pm.PackageManager.PERMISSION_GRANTED) return

        getSharedPreferences("shopping", MODE_PRIVATE).edit().putBoolean("notify", false).apply()
        findViewById<OnOffSwitch>(R.id.notifySwitch).isChecked = false
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Notifications are off")
            .setMessage("To turn them on, open the phone's Settings, then Apps, " +
                    "then ShoppingList, then Notifications.")
            .setPositiveButton("OK", null)
            .show()
    }

    /**
     * Adds the reminder time to the "At …" line, under "After − 1 day +".
     * Tapping it opens Android's clock, to choose any hour and minute
     * (turn the hands, or tap the keyboard icon to type it).
     */
    private fun addReminderTime(row: android.view.View): android.view.View {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val time = TextView(this).apply {
            text = Reminders.label(this@Settings)
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#1F3864"))
            gravity = android.view.Gravity.CENTER
            minHeight = dp(52)
            setPadding(dp(18), 0, dp(18), 0)
            setBackgroundResource(R.drawable.button_outline)
            isClickable = true
            isFocusable = true
            contentDescription = "Reminder time, ${text}. Tap to change."
        }

        time.setOnClickListener {
            if (!time.isEnabled) return@setOnClickListener   // Remind me is Off

            val picker = com.google.android.material.timepicker.MaterialTimePicker.Builder()
                .setTimeFormat(com.google.android.material.timepicker.TimeFormat.CLOCK_12H)
                .setHour(Reminders.hour(this))
                .setMinute(Reminders.minute(this))
                .setTitleText("What time should the reminder come?")
                .setInputMode(com.google.android.material.timepicker.MaterialTimePicker.INPUT_MODE_CLOCK)
                .build()

            picker.addOnPositiveButtonClickListener {
                Reminders.setTime(this, picker.hour, picker.minute)   // saves and moves the daily check
                time.text = Reminders.label(this)
                time.contentDescription = "Reminder time, ${time.text}. Tap to change."
                Toast.makeText(this, "Reminder at ${time.text}", Toast.LENGTH_SHORT).show()
            }
            picker.show(supportFragmentManager, "reminderTime")
        }

        // After the word "At" on its own line
        (row as android.view.ViewGroup).addView(time, android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        return time
    }
}