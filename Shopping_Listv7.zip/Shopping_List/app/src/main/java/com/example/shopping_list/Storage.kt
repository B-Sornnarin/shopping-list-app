package com.example.shopping_list

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Saves the list on the phone so it survives closing the app.
 *
 * Firebase replaces this later for sharing between devices. Keeping
 * saving in one place means the screens do not change when it does.
 */
object Storage {

    private const val FILE = "shopping"
    private const val KEY = "items"

    fun save(context: Context, items: List<Item>) {
        val array = JSONArray()
        items.forEach { item ->
            val json = JSONObject()
            json.put("id", item.id)
            json.put("name", item.name)
            json.put("category", item.category)
            json.put("done", item.done)
            array.put(json)
        }

        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, array.toString())
            .apply()
    }

    fun load(context: Context): MutableList<Item> {
        val text = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return mutableListOf()

        val items = mutableListOf<Item>()
        val array = JSONArray(text)
        for (i in 0 until array.length()) {
            val json = array.getJSONObject(i)
            items.add(
                Item(
                    id = json.getString("id"),
                    name = json.getString("name"),
                    category = json.getString("category"),
                    done = json.getBoolean("done")
                )
            )
        }
        return items
    }
}