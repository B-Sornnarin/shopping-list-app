package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.ValueEventListener

/**
 * Screen 3.1 People.
 *
 * Everyone on the list can add things and tick them off. The switch
 * gives someone permission to change settings, and only someone with
 * permission can use the switches or remove people. The owner (who
 * set the list up) can never be removed from their own list.
 */
class PeopleScreen : AppCompatActivity() {

    private lateinit var listId: String
    private lateinit var rows: LinearLayout
    private var listener: ValueEventListener? = null

    /** "mary": the person using this phone. */
    private val myKey: String
        get() = Names.firebaseKey(
            getSharedPreferences("shopping", MODE_PRIVATE).getString("userName", "") ?: ""
        )

    /** Whether the person using this phone may change settings. */
    private var iMayChange = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_people)

        listId = Session.listId(this) ?: return finish()
        rows = findViewById(R.id.peopleRows)

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }
        findViewById<View>(R.id.addPersonButton).setOnClickListener {
            if (iMayChange) {
                startActivity(Intent(this, AddPersonScreen::class.java))
            } else {
                notAllowed()
            }
        }

        listener = People.listen(listId) { people -> show(people) }
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.let { People.stop(listId, it) }
    }

    private fun show(people: List<Person>) {
        // Lists made before People existed: put this person on it.
        // On an empty list they become the owner.
        val name = getSharedPreferences("shopping", MODE_PRIVATE).getString("userName", null)
        if (name != null && people.none { it.key == myKey }) {
            People.join(listId, name, owner = people.isEmpty())
            return   // the listener calls show() again with them in
        }

        iMayChange = people.firstOrNull { it.key == myKey }?.mayChangeSettings == true

        rows.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (person in people) {
            val row = inflater.inflate(R.layout.row_person, rows, false)

            val avatar = row.findViewById<TextView>(R.id.personAvatar)
            avatar.text = person.name.take(1).uppercase()
            avatar.setBackgroundResource(
                if (person.owner) R.drawable.avatar_filled else R.drawable.avatar_outline
            )

            row.findViewById<TextView>(R.id.personName).text =
                if (person.key == myKey) "${person.name} (you)" else person.name

            val status = row.findViewById<TextView>(R.id.personStatus)
            val switchRow = row.findViewById<View>(R.id.permissionRow)
            val switch = row.findViewById<OnOffSwitch>(R.id.permissionSwitch)
            val remove = row.findViewById<TextView>(R.id.removePersonButton)

            if (person.owner) {
                // The owner always keeps permission and cannot be removed.
                status.text = "Uses the list · Can change settings"
                switchRow.visibility = View.GONE
                remove.visibility = View.GONE
            } else {
                // The switch has a full-width line of its own under the name,
                // so the status stays short. Squeezing both onto one line in
                // the narrow column beside the letter wrapped the words onto
                // three lines on a small phone.
                if (iMayChange) {
                    status.text = "Uses the list"
                    switchRow.visibility = View.VISIBLE
                } else {
                    // No switch to show, so the status says it in words.
                    status.text = if (person.canChange) "Uses the list · Can change settings"
                    else "Uses the list · Cannot change settings"
                    switchRow.visibility = View.GONE
                }

                switch.isChecked = person.canChange
                switch.alpha = if (iMayChange) 1f else 0.5f
                switch.contentDescription = "${person.name} can change settings"
                switch.onChanged = { on ->
                    if (iMayChange) {
                        People.setCanChange(listId, person.key, on)
                    } else {
                        switch.isChecked = !on   // put it back
                        notAllowed()
                    }
                }

                // Remove: only with permission, and never yourself
                // (Log out in Settings is for leaving).
                val canRemove = iMayChange && person.key != myKey
                remove.visibility = if (canRemove) View.VISIBLE else View.GONE
                remove.contentDescription = "Remove ${person.name}"
                remove.setOnClickListener { confirmRemove(person) }
            }
            rows.addView(row)
        }
    }

    /** Asks first, so a mis-tap removes nobody. */
    private fun confirmRemove(person: Person) {
        AlertDialog.Builder(this)
            .setTitle("Remove ${person.name}?")
            .setMessage(
                "${person.name} will no longer be able to see or change this shopping list. " +
                        "You can invite them again at any time."
            )
            .setPositiveButton("Remove") { _, _ ->
                People.remove(listId, person)
                Toast.makeText(this, "${person.name} has been removed from the list.",
                    Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun notAllowed() {
        Toast.makeText(this, "Only the list owner, or members with permission, can change this.",
            Toast.LENGTH_LONG).show()
    }
}