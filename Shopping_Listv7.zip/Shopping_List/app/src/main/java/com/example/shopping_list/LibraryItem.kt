package com.example.shopping_list

/**
 * One thing in the app's picture library.
 *
 * [picture] is a drawable name (pumpkin → res/drawable/pumpkin.png).
 * Until that image is added, [emoji] is drawn instead.
 */
data class LibraryItem(
    val id: String,
    val name: String,
    val category: String,
    val picture: String,
    val favourite: Boolean = false,
    val emoji: String = ""
)