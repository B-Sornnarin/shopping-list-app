package com.example.shopping_list

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Screen 1.3 Who else.
 *
 * Adding someone does not give them permission to change settings.
 * They join as a member; permission is given later on the People
 * screen. "Not now" is always available, so nobody is stuck here.
 */
class SetupWhoElse : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup_who_else)

        // Add someone: make the list first, then invite (3.3).
        // When the invitation is sent, set-up is finished.
        findViewById<Button>(R.id.addPersonButton).setOnClickListener {
            makeList()
            addPerson.launch(android.content.Intent(this, AddPersonScreen::class.java))
        }

        findViewById<Button>(R.id.addDeviceButton).setOnClickListener {
            makeList()   // the list must exist before another device can join it
            Devices.showHowToAdd(this)
        }

        findViewById<Button>(R.id.notNowButton).setOnClickListener {
            finishSetup()
        }
    }

    private val addPerson = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) finishSetup()
    }

    /** Set-up runs once. After this the app always opens on the list. */
    private fun finishSetup() {
        makeList()

        getSharedPreferences("shopping", MODE_PRIVATE)
            .edit().putBoolean("setupDone", true).apply()

        startActivity(android.content.Intent(this, ShoppingList::class.java))
        finish()
    }

    /** A new list of our own, unless this phone already has one. */
    private fun makeList() {
        if (Session.listId(this) == null) {
            val newId = Session.newListId()
            Session.setListId(this, newId)

            // Connect the name to the new list, so the same name
            // (in any capitals) finds it again after logging out.
            val name = getSharedPreferences("shopping", MODE_PRIVATE)
                .getString("userName", null)
            if (name != null) {
                Accounts.save(name, newId)
                People.join(newId, name, owner = true)   // whoever sets up owns it
            }
        }
    }
}