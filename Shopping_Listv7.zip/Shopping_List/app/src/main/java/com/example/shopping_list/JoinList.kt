package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Joining an existing list with a code.
 *
 * A code rather than an account: the sponsor said a password would
 * stop people using the app. Links and QR codes replace this later.
 */
class JoinList : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join_list)

        findViewById<Button>(R.id.joinButton).setOnClickListener {
            val code = findViewById<EditText>(R.id.codeInput)
                .text.toString().trim().uppercase()

            if (code.length != 6) {
                Toast.makeText(this, "Please type all six letters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Session.setListId(this, code)
            startActivity(Intent(this, ShoppingList::class.java))
            finish()
        }
    }
}