package com.example.shopping_list

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import java.io.File

/**
 * Screen 3.6 Pictures.
 *
 * Reached from Settings, not from the list, so a picture can be
 * changed whether or not the thing is on the list today.
 * Tap a picture to change it. Press and hold one of the household's
 * own things to delete it (on every device), with Undo.
 */
class PicturesScreen : AppCompatActivity() {

    private lateinit var adapter: LibraryAdapter

    /** Redraws the grid when things change here or on another device. */
    private val refresh: () -> Unit = { adapter.refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pictures_screen)
        Library.load(this)   // include the household's own things
        Session.listId(this)?.let {
            Favourites.start(it)
            Library.startSharing(this, it)
        }

        // ‹ back to Settings; the phone's Back closes the menu first if it is open
        findViewById<View>(R.id.backButton).setOnClickListener { finish() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (HoldMenu.close(this@PicturesScreen)) return
                finish()
            }
        })

        // Tapping opens the item rather than selecting it: this screen
        // changes pictures, it does not add anything.
        adapter = LibraryAdapter(
            Library.items,
            onSelectionChanged = {},
            selectable = false,
            onTapped = { item ->
                val intent = Intent(this, ChangePicture::class.java)
                intent.putExtra("id", item.id)
                intent.putExtra("name", item.name)
                startActivity(intent)
            },
            // Press and hold: Delete item (the household's own things only)
            onRemoveFavourite = { item, tile -> showHoldMenu(item, tile) }
        )

        val grid = findViewById<RecyclerView>(R.id.picturesGrid)
        grid.layoutManager = GridLayoutManager(this, 3)
        grid.adapter = adapter

        Library.watch(refresh)
        SharedPictures.watch(refresh)
    }

    override fun onResume() {
        super.onResume()
        // A picture may have changed while we were away.
        adapter.refresh()
    }

    override fun onDestroy() {
        super.onDestroy()
        Library.unwatch(refresh)
        SharedPictures.unwatch(refresh)
        HoldMenu.close(this, animate = false)
    }

    /** Press and hold a picture: the same dim-and-lift menu as everywhere else. */
    private fun showHoldMenu(item: LibraryItem, tile: View) {
        val main = if (Library.isCustom(item)) {
            HoldMenu.Row("Delete item", "#B3261E") { deleteItem(item) }
        } else {
            HoldMenu.Row("Built in, can't be deleted", "#8A93A3") {}
        }
        val rows = mutableListOf<HoldMenu.Row>()
        if (Library.isCustom(item)) {
            rows.add(HoldMenu.Row("Change the name", "#1F3864") {
                RenameItem.ask(this, item)
            })
        }
        // Built-in things can be moved as well: that is what makes a
        // group somebody added worth having.
        rows.add(HoldMenu.Row("Move to another category", "#1F3864") {
            ChooseGroup.ask(this, item)
        })
        rows.add(main)
        rows.add(HoldMenu.Row("Cancel", "#1A1A1A") {})

        HoldMenu.show(this, tile, null, rows)
    }

    /** Deletes it on every device, with 8 seconds to Undo. */
    private fun deleteItem(item: LibraryItem) {
        val wasFavourite = Favourites.isFavourite(item.id)
        val picture = Library.pictureFor(this, item)   // kept here, in case of Undo

        Library.deleteCustom(this, item)
        adapter.refresh()

        val bar = Snackbar.make(
            findViewById(R.id.picturesGrid),
            "${item.name} deleted",
            8000   // 8 seconds: time to read and decide
        )
        bar.setAction("Undo") {
            Library.addCustom(this, item.name)
            if (wasFavourite) Favourites.set(item.id, true)
            // Put its photo back for everyone, if it had one.
            if (picture.startsWith("/") && File(picture).exists()) {
                Library.setPicture(this, item.id, picture)
                Session.listId(this)?.let {
                    SharedPictures.upload(this, it, item.id, File(picture), item.name)
                }
            }
            adapter.refresh()
        }
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_text
        ).textSize = 18f
        bar.view.findViewById<TextView>(
            com.google.android.material.R.id.snackbar_action
        ).textSize = 18f
        bar.show()
    }
}