package com.example.shopping_list

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Screen 3.8 while the list is open: a white card slides down from the top,
 * "Frank added to the list / Milk and Bread". Tap it to close it.
 */
object InAppBanner {

    private const val TAG = "inAppBanner"

    fun show(activity: Activity, title: String, text: String) {
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = activity.findViewById<ViewGroup>(android.R.id.content)
        root.findViewWithTag<View>(TAG)?.let { root.removeView(it) }   // one at a time

        val card = LinearLayout(activity).apply {
            tag = TAG
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(20), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.parseColor("#C8C8C8"))
            }
            elevation = dp(12).toFloat()
            contentDescription = "$title. $text. Tap to close."
        }

        // Navy circle with the white cart
        val circle = ImageView(activity).apply {
            setImageResource(R.drawable.ic_notify)
            setColorFilter(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1F3864"))
            }
            setPadding(dp(13), dp(13), dp(13), dp(13))
        }
        card.addView(circle, LinearLayout.LayoutParams(dp(56), dp(56)))

        val words = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, 0, 0)
        }
        words.addView(TextView(activity).apply {
            this.text = "Shopping list · now"
            textSize = 14f
            setTextColor(Color.parseColor("#595959"))
        })
        words.addView(TextView(activity).apply {
            this.text = title
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#1A1A1A"))
        })
        words.addView(TextView(activity).apply {
            this.text = text
            textSize = 19f
            setTextColor(Color.parseColor("#1A1A1A"))
        })
        card.addView(words, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // Centred at the top, never wider than 560dp, clear of the status bar
        val screenWidth = activity.resources.displayMetrics.widthPixels
        val width = minOf(screenWidth - dp(32), dp(560))
        val params = FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        params.topMargin = dp(36)
        root.addView(card, params)

        // Slide down, then slide away after 8 seconds or when tapped
        card.translationY = -dp(220).toFloat()
        card.animate().translationY(0f).setDuration(300).start()

        fun hide() {
            if (card.parent == null) return
            card.animate().translationY(-dp(220).toFloat()).setDuration(300)
                .withEndAction { root.removeView(card) }.start()
        }
        card.setOnClickListener { hide() }
        card.postDelayed({ hide() }, 8000)
    }
}