package com.example.shopping_list

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView

/**
 * Builds the list screen: category headings and item rows.
 *
 * A bought item keeps its place, turns green and says "Done", so
 * nothing is cleared away while the person is shopping.
 * Tapping an item's picture or name opens a small favourites card next to it.
 * Tapping the bin plays a short animation, then deletes (with Undo).
 */
class ItemAdapter(
    private val context: android.content.Context,
    private val items: MutableList<Item>,
    private val onTicked: (Item) -> Unit,
    private val onDelete: (Item) -> Unit,
    private val onTapped: (Item, View) -> Unit = { _, _ -> },
    private val onCountChanged: (Item, Int) -> Unit = { _, _ -> },
    private val onCountTapped: (Item) -> Unit = { }
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val headingType = 0
    private val itemType = 1

    /** How long the bin animation plays, in milliseconds. Change this to make it slower or faster. */
    private val binMs = 1200L

    /** Items whose bin was tapped and are waiting to be deleted, so a second tap does nothing. */
    private val deleting = mutableSetOf<String>()

    private val handler = Handler(Looper.getMainLooper())

    /**
     * Group by category (the default) or show one plain list.
     * Set from Settings > Group by. Either way, nothing is hidden.
     */
    var grouped: Boolean = true
    /** The order of the groups, from Settings > Categories (3.2). */
    var order: List<String> = Categories.builtIn

    /**
     * The group tapped in the bar above the list, shown first.
     * Null: every group in its usual order. Nothing is hidden either way.
     */
    var first: String? = null

    /** The rows actually drawn: headings mixed in with items. */
    private var rows: List<Row> = buildRows()

    /**
     * Which group a row belongs under. The household may have moved
     * the thing since it was added, so the library has the last word,
     * not the group copied onto the row at the time.
     */
    private fun groupOf(item: Item): String =
        Library.groupForName(context, item.name, item.category)

    /**
     * The groups with their items, in the order set on Categories (3.2);
     * unknown groups last. With [chosenFirst], the tapped group goes on top.
     */
    private fun groups(chosenFirst: Boolean): List<Pair<String, List<Item>>> {
        fun place(category: String): Int {
            if (chosenFirst && category == first) return -1
            val at = order.indexOf(category)
            return if (at < 0) order.size else at
        }
        return items.groupBy { groupOf(it) }.toList().sortedBy { place(it.first) }
    }

    /** Groups the items by category, keeping each group's order. */
    private fun buildRows(): List<Row> {
        if (!grouped) return items.map { Row.ItemRow(it) }

        val result = mutableListOf<Row>()
        for ((category, itemsInGroup) in groups(chosenFirst = true)) {
            if (category.isNotEmpty()) result.add(Row.Heading(category))
            itemsInGroup.forEach { result.add(Row.ItemRow(it)) }
        }
        return result
    }

    /** Call after anything changes the items. */
    fun refresh() {
        rows = buildRows()
        notifyDataSetChanged()
    }

    class HeadingHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.headingText)
    }

    class ItemHolder(view: View) : RecyclerView.ViewHolder(view) {
        val row: LinearLayout = view.findViewById(R.id.itemRow)
        val tickBox: CheckBox = view.findViewById(R.id.tickBox)
        val picture: ImageView = view.findViewById(R.id.itemPicture)
        val name: TextView = view.findViewById(R.id.itemName)
        val status: TextView = view.findViewById(R.id.itemStatus)
        val bin: ImageButton = view.findViewById(R.id.binButton)
        val binAnimation: LottieAnimationView = view.findViewById(R.id.binAnimation)
        val countRow: View = view.findViewById(R.id.countRow)
        val minus: TextView = view.findViewById(R.id.minusButton)
        val countText: TextView = view.findViewById(R.id.countText)
        val plus: TextView = view.findViewById(R.id.plusButton)
    }

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int) =
        if (rows[position] is Row.Heading) headingType else itemType

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == headingType) {
            HeadingHolder(inflater.inflate(R.layout.row_heading, parent, false))
        } else {
            ItemHolder(inflater.inflate(R.layout.row_item, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Heading -> {
                (holder as HeadingHolder).title.text = row.title
            }
            is Row.ItemRow -> {
                bindItem(holder as ItemHolder, row.item)
            }
        }
    }

    private fun bindItem(holder: ItemHolder, item: Item) {
        // Just the name. How many is shown by the – 1 + row underneath,
        // so the number can be changed without leaving this screen.
        holder.name.text = item.name

        // The household's own picture if they have chosen one for this
        // thing, otherwise the library's.
        val libraryItem = Library.items.firstOrNull { it.name == item.name }
        val picture = if (libraryItem != null) {
            Library.pictureFor(holder.itemView.context, libraryItem)
        } else {
            SharedPictures.pathForName(holder.itemView.context, item.name) ?: item.picture
        }
        Pictures.show(holder.picture, picture)

        // A gold ★ after the name if it is a favourite.
        if (libraryItem != null && Favourites.isFavourite(libraryItem.id)) {
            val text = android.text.SpannableString("${holder.name.text}  ★")
            text.setSpan(
                android.text.style.ForegroundColorSpan(Color.parseColor("#E0A100")),
                text.length - 1, text.length, 0
            )
            holder.name.text = text
        }

        // The size the household chose, applied to every row.
        val sizeDp = holder.itemView.context
            .getSharedPreferences("shopping", android.content.Context.MODE_PRIVATE)
            .getInt("pictureSize", 64)
        val px = (sizeDp * holder.itemView.resources.displayMetrics.density).toInt()
        holder.picture.layoutParams.width = px
        holder.picture.layoutParams.height = px
        holder.picture.requestLayout()

        // Clear the listener first, or a reused row fires for the
        // wrong item.
        holder.tickBox.setOnCheckedChangeListener(null)
        holder.tickBox.isChecked = item.done

        if (item.done) {
            holder.row.setBackgroundResource(R.drawable.row_done)
            holder.name.setTextColor(Color.parseColor("#1E5B14"))
            holder.status.visibility = View.VISIBLE
            // Bought: the number still works, but it steps back so the
            // green row reads as finished.
            holder.countRow.alpha = 0.55f
        } else {
            holder.row.setBackgroundResource(0)
            holder.name.setTextColor(Color.parseColor("#1A1A1A"))
            holder.status.visibility = View.GONE
            holder.countRow.alpha = 1f
        }

        holder.tickBox.setOnCheckedChangeListener { _, checked ->
            item.done = checked
            onTicked(item)
        }

        // Tap the picture or the name: a small favourites card next to this row.
        holder.picture.setOnClickListener { onTapped(item, holder.row) }
        holder.name.setOnClickListener { onTapped(item, holder.row) }

        // ---- HOW MANY ----
        holder.countText.text = item.count.toString()
        // One is the smallest. Removing a thing is the bin's job, which
        // says so and offers Undo.
        val canGoDown = item.count > 1
        holder.minus.isEnabled = canGoDown
        holder.minus.alpha = if (canGoDown) 1f else 0.25f
        holder.minus.setOnClickListener {
            if (item.count > 1) onCountChanged(item, item.count - 1)
        }
        holder.plus.setOnClickListener { onCountChanged(item, item.count + 1) }
        // Tap the number itself to type one, for "a dozen eggs".
        holder.countText.setOnClickListener { onCountTapped(item) }

        // ---- THE BIN ----
        // A reused row may be showing another item's animation: reset it.
        holder.binAnimation.cancelAnimation()
        holder.binAnimation.visibility = View.GONE
        holder.binAnimation.progress = 0f
        holder.bin.setImageResource(R.drawable.ic_bin)
        holder.bin.isEnabled = item.id !in deleting

        holder.bin.setOnClickListener { playBinThenDelete(holder, item) }
    }

    /**
     * Plays the bin animation, then deletes. The delete happens after binMs
     * even if the list redraws in the middle, so it is never lost.
     */
    private fun playBinThenDelete(holder: ItemHolder, item: Item) {
        if (item.id in deleting) return   // already on its way
        val composition = holder.binAnimation.composition

        // No animation: the phone's "Remove animations" is on, or it did not load.
        if (animationsOff(holder.itemView) || composition == null) {
            onDelete(item)
            return
        }

        deleting.add(item.id)
        holder.bin.isEnabled = false
        holder.bin.setImageDrawable(null)   // keep the box, swap the icon for the animation
        holder.binAnimation.visibility = View.VISIBLE
        holder.binAnimation.progress = 0f
        holder.binAnimation.speed = composition.duration / binMs.toFloat()
        holder.binAnimation.playAnimation()

        handler.postDelayed({
            deleting.remove(item.id)
            onDelete(item)
        }, binMs)
    }

    /** True if the phone's accessibility setting "Remove animations" is on. */
    private fun animationsOff(view: View): Boolean {
        val scale = android.provider.Settings.Global.getFloat(
            view.context.contentResolver,
            android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f
        )
        return scale == 0f
    }

    fun remove(item: Item) {
        items.removeAll { it.id == item.id }
        refresh()
    }

    fun stillToGet() = items.count { !it.done }

    // ---- For the jump bar on the list screen ----

    /**
     * Each group, with how many of it are still to get. Always in the usual
     * order, so the buttons above the list never move when one is tapped.
     */
    fun headings(): List<Pair<String, Int>> =
        if (!grouped) emptyList()
        else groups(chosenFirst = false)
            .filter { it.first.isNotEmpty() }
            .map { (title, list) -> title to list.count { !it.done } }

    /** Where a group's heading sits, so the list can scroll to it. */
    fun positionOfHeading(title: String): Int =
        rows.indexOfFirst { it is Row.Heading && it.title == title }
}