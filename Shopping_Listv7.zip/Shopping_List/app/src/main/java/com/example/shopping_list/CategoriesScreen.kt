package com.example.shopping_list

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.ValueEventListener

/**
 * Screen 3.2 Categories.
 *
 * The groups shown on the list, in the order they appear there, so the
 * list can be put in the order of the walk around the shop.
 *
 * Two ways to move a group, because one gesture is never enough for
 * everybody: hold it and drag it, or tap it and choose Move up or
 * Move down. "+ Add a category" adds a new group before "Other".
 */
class CategoriesScreen : AppCompatActivity() {

    private lateinit var listId: String
    private lateinit var rows: RecyclerView
    private lateinit var adapter: Rows
    private lateinit var dragger: ItemTouchHelper

    private val categories = mutableListOf<String>()
    private var listener: ValueEventListener? = null

    /**
     * True while a row is under her finger. A change arriving from
     * another device must not rebuild the list mid-drag.
     */
    private var dragging = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categories)

        listId = Session.listId(this) ?: return finish()
        Library.startSharing(this, listId)   // so a bulk move sees every thing

        findViewById<View>(R.id.backButton).setOnClickListener { finish() }
        findViewById<View>(R.id.addCategoryButton).setOnClickListener { askNewCategory() }

        adapter = Rows()
        rows = findViewById(R.id.categoryRows)
        rows.layoutManager = LinearLayoutManager(this)
        rows.adapter = adapter

        dragger = ItemTouchHelper(DragToReorder())
        dragger.attachToRecyclerView(rows)

        // Shows changes from other devices straight away.
        listener = Categories.listen(listId) { latest ->
            if (dragging || latest == categories) return@listen
            categories.clear()
            categories.addAll(latest)
            adapter.notifyDataSetChanged()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        listener?.let { Categories.stop(listId, it) }
    }

    // ------------------------------------------------------------------
    //  The rows
    // ------------------------------------------------------------------

    private inner class Rows : RecyclerView.Adapter<Rows.Holder>() {

        inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val name: TextView = view.findViewById(R.id.categoryName)
            val handle: View = view.findViewById(R.id.dragHandle)
        }

        override fun getItemCount() = categories.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            Holder(
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.row_category, parent, false)
            )

        @SuppressLint("ClickableViewAccessibility")
        override fun onBindViewHolder(holder: Holder, position: Int) {
            holder.name.text = categories[position]

            holder.itemView.setOnClickListener {
                val at = holder.bindingAdapterPosition
                if (at != RecyclerView.NO_POSITION) askWhatToDo(at)
            }

            // Touching the grip starts the drag at once, with no wait.
            // Holding the row itself also works, for anyone who misses it.
            holder.handle.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) dragger.startDrag(holder)
                false
            }
        }
    }

    /** Hold a row, drag it, and the order follows the finger. */
    private inner class DragToReorder : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
    ) {
        override fun isLongPressDragEnabled() = true

        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean {
            val from = viewHolder.bindingAdapterPosition
            val to = target.bindingAdapterPosition
            if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
            categories.add(to, categories.removeAt(from))
            adapter.notifyItemMoved(from, to)
            return true
        }

        /** Nothing is swiped away here: the row menu removes a group. */
        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit

        override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
            super.onSelectedChanged(viewHolder, actionState)
            if (actionState != ItemTouchHelper.ACTION_STATE_DRAG) return
            dragging = true
            viewHolder?.itemView?.apply {
                // A small shadow, so the row looks lifted off the page.
                elevation = 14f
                alpha = 0.95f
                // A short buzz confirms the hold worked, before anything moves.
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            }
        }

        override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
            super.clearView(recyclerView, viewHolder)
            viewHolder.itemView.elevation = 0f
            viewHolder.itemView.alpha = 1f
            dragging = false
            // Let go, and everyone on the list gets the new order.
            Categories.save(listId, categories.toList())
        }
    }

    // ------------------------------------------------------------------
    //  The tap menu, for anyone who would rather not drag
    // ------------------------------------------------------------------

    private fun askWhatToDo(index: Int) {
        val name = categories[index]
        val choices = mutableListOf<String>()
        if (index > 0) choices.add("Move up")
        if (index < categories.size - 1) choices.add("Move down")
        choices.add("Change the name")
        if (categories.size > 1) choices.add("Move everything here to…")
        // A list must keep at least one group for things to sit in.
        if (categories.size > 1) choices.add("Delete")

        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(choices.toTypedArray()) { _, which ->
                when (choices[which]) {
                    "Move up" -> move(index, index - 1)
                    "Move down" -> move(index, index + 1)
                    "Change the name" -> askRename(index, name)
                    "Move everything here to…" -> askMoveAll(name)
                    "Delete" -> confirmDelete(name)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun move(from: Int, to: Int) {
        categories.add(to, categories.removeAt(from))
        adapter.notifyItemMoved(from, to)
        Categories.save(listId, categories.toList())
    }

    /**
     * Empties a group in one go. Splitting "Fruit & veg" means moving
     * 27 things, and doing that one at a time would be a punishment.
     */
    private fun askMoveAll(from: String) {
        val others = categories.filter { it != from }
        if (others.isEmpty()) return

        AlertDialog.Builder(this)
            .setTitle("Move everything in $from to…")
            .setItems(others.toTypedArray()) { _, which ->
                Library.moveAll(this, from, others[which])
                Toast.makeText(this, "Everything in $from is now in ${others[which]}",
                    Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * Renames a group. Anything in it follows the new name, so nothing
     * is left pointing at a group that no longer exists.
     */
    private fun askRename(index: Int, old: String) {
        val input = EditText(this).apply {
            setText(old)
            setSelection(text.length)
            textSize = 20f
            setSingleLine()
            setPadding(48, 32, 48, 32)
        }

        AlertDialog.Builder(this)
            .setTitle("Change the name")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val fresh = Names.display(input.text.toString())
                when {
                    fresh.isEmpty() -> Unit
                    Names.same(fresh, old) -> Unit
                    categories.any { Names.same(it, fresh) } ->
                        Toast.makeText(this, "$fresh is already there",
                            Toast.LENGTH_SHORT).show()
                    else -> {
                        val list = categories.toMutableList()
                        list[index] = fresh
                        Categories.save(listId, list)
                        Library.moveAll(this, old, fresh)   // the things follow
                        Toast.makeText(this, "Now called $fresh",
                            Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Deleting a group is not undoable, so it asks, and says where things go. */
    private fun confirmDelete(name: String) {
        val moveTo = categories.firstOrNull { it != name } ?: return
        val inside = Library.items.count { Library.groupFor(this, it) == name }
        val message = if (inside == 0) "Delete $name?"
        else "Delete $name? The $inside things in it will move to $moveTo."

        AlertDialog.Builder(this)
            .setTitle(name)
            .setMessage(message)
            .setPositiveButton("Delete") { _, _ -> remove(name, moveTo) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun remove(name: String, moveTo: String) {
        // Nothing may be left pointing at a group that is gone.
        Library.moveAll(this, name, moveTo)
        Categories.save(listId, categories.filter { it != name })
        Toast.makeText(this, "$name deleted", Toast.LENGTH_SHORT).show()
    }

    /** A box to type the new group's name. */
    private fun askNewCategory() {
        val input = EditText(this).apply {
            hint = "For example: Bakery"
            textSize = 20f
            setSingleLine()
            setPadding(48, 32, 48, 32)
        }

        AlertDialog.Builder(this)
            .setTitle("Add a category")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val name = Names.display(input.text.toString())
                when {
                    name.isEmpty() -> Unit
                    categories.any { Names.same(it, name) } ->
                        Toast.makeText(this, "$name is already there", Toast.LENGTH_SHORT).show()
                    else -> {
                        // New groups go just before "Other", which stays last.
                        val list = categories.toMutableList()
                        val at = list.indexOf("Other").takeIf { it >= 0 } ?: list.size
                        list.add(at, name)
                        Categories.save(listId, list)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}