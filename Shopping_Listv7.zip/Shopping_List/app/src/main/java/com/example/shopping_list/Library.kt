package com.example.shopping_list

import android.content.Context
import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * The app's picture library, shared by Add, Say, Type, Photo and
 * Settings > Pictures.
 *
 * Built-in things come with a picture. Anything else a household adds
 * joins the library and is shared through Firebase, so it shows up in
 * the picture grid on every device on the list:
 *
 *   lists / KQZPMT / customItems / custom_dom = { name: "Dom", category: "Other" }
 *
 * A deleted one is kept as { name, deleted: true }, so no other device
 * brings it back.
 */
object Library {

    val items = mutableListOf<LibraryItem>()

    /**
     * Other names people use for the same thing. Used by Say, Type
     * and Photo. Only specific words: a general word like "vegetable"
     * would pick the wrong thing.
     */
    private val alsoCalled = mapOf(
        "Capsicum" to listOf("pepper", "bell pepper"),
        "Kiwi fruit" to listOf("kiwi"),
        "Strawberries" to listOf("strawberry"),
        "Corn" to listOf("sweetcorn", "sweet corn"),
        "Chilli" to listOf("chili", "chilli pepper"),
        "Yoghurt" to listOf("yogurt"),
        "Frozen chips" to listOf("chips", "fries"),
        "Biscuits" to listOf("cookies", "cookie"),
        "Toilet paper" to listOf("toilet roll", "toilet rolls", "loo paper"),
        "Tissues" to listOf("tissue", "kleenex"),
        "Band-aids" to listOf("bandaid", "band aid", "plasters"),
        "Dishwashing liquid" to listOf("dishwashing", "detergent", "washing up liquid"),
        "Laundry powder" to listOf("washing powder", "laundry"),
        "Bin bags" to listOf("rubbish bags", "garbage bags"),
        "Light globes" to listOf("light bulb", "light bulbs", "globe"),
        "Medicine" to listOf("tablets", "pills"),
        "Bread" to listOf("loaf"),
        "Cream" to listOf("lotion", "moisturiser"),
        "Toothpaste" to listOf("tooth paste"),
        "Rockmelon" to listOf("cantaloupe", "melon"),
        "Capsicum" to listOf("pepper", "bell pepper"),
        "Zucchini" to listOf("courgette"),
        "Eggplant" to listOf("aubergine"),
        "Mince" to listOf("ground beef", "minced beef"),
        "Soft drink" to listOf("fizzy drink", "soda", "lemonade"),
        "Lollies" to listOf("sweets", "candy"),
        "Chips" to listOf("crisps"),
        "Paper towel" to listOf("kitchen towel", "kitchen roll"),
        "Rubber gloves" to listOf("gloves"),
        "Laundry liquid" to listOf("washing liquid"),
        "Dishwasher tablets" to listOf("dishwasher"),
        "Painkillers" to listOf("paracetamol", "panadol", "ibuprofen"),
        "Hand sanitiser" to listOf("sanitiser"),
        "Cooking oil" to listOf("vegetable oil"),
        "Thickened cream" to listOf("pouring cream", "whipping cream")
    )

    private const val CUSTOM = "custom_items"
    private const val TAG = "Library"

    // ---- Building the library ----

    /** A built-in thing. Its id and picture name come from its name. */
    private fun item(name: String, category: String, emoji: String,
                     favourite: Boolean = false) =
        LibraryItem("lib_" + slug(name), name, category, slug(name), favourite, emoji)

    /** "Sweet potato" → "sweet_potato": a safe file and id name. */
    private fun slug(name: String) =
        Names.key(name).replace(Regex("[^a-z0-9]+"), "_").trim('_')

    private fun prefs(context: Context) =
        context.getSharedPreferences("shopping", Context.MODE_PRIVATE)

    /**
     * Adds the household's own things, saved on this phone, to the
     * library. Safe to call often: nothing is added twice.
     */
    fun load(context: Context) {
        val saved = prefs(context).getStringSet(CUSTOM, emptySet()) ?: emptySet()
        for (name in saved) {
            if (items.none { Names.same(it.name, name) }) items.add(custom(name))
        }
        startCloud(context)   // the items kept in Firebase (see the bottom of this file)
    }

    /**
     * Remembers a new thing so it joins the picture grid from now on,
     * on this device and on every other device on the list.
     */
    fun addCustom(context: Context, name: String) {
        rememberLocally(context, name)
        Session.listId(context)?.let { share(it, name) }
    }

    /** A household's own thing: no picture yet, so its first letter is shown. */
    fun custom(name: String) =
        LibraryItem("custom_" + slug(name), Names.display(name), "Other", slug(name))

    /**
     * Gives one of the household's own things a new name, everywhere:
     * the picture grid, favourites, the other devices, and anything
     * already on the shopping list.
     *
     * Returns the renamed thing, or null if the name cannot be used
     * (empty, or already taken by something else). Built-in things are
     * never renamed: their names are what Say, Type and Photo match on.
     */
    fun renameCustom(context: Context, item: LibraryItem, newName: String): LibraryItem? {
        if (!isCustom(item)) return null
        val clean = Names.display(newName.trim())
        if (clean.isEmpty()) return null
        if (Names.same(item.name, clean)) return item
        if (items.any { it.id != item.id && Names.same(it.name, clean) }) return null

        val picture = pictureFor(context, item)       // a file path, if it has a photo
        val wasFavourite = Favourites.isFavourite(item.id)
        val oldName = item.name

        // The new one is made first, so a failure half way through
        // leaves the thing still there under its old name.
        addCustom(context, clean)
        val fresh = items.firstOrNull { Names.same(it.name, clean) } ?: return null

        if (picture.startsWith("/")) {
            setPicture(context, fresh.id, picture)
            val file = java.io.File(picture)
            Session.listId(context)?.let { listId ->
                if (file.exists()) SharedPictures.upload(context, listId, fresh.id, file, clean)
            }
        }
        if (wasFavourite) Favourites.set(fresh.id, true)

        // Only now does the old one go.
        deleteCustom(context, item)

        // Anything already on the list follows the new name.
        Session.listId(context)?.let { ListRepository.use(it) }
        ListRepository.renameAll(oldName, clean)

        Log.d(TAG, "Renamed '$oldName' to '$clean'")
        watchers.toList().forEach { it() }
        return fresh
    }

    /** True for the household's own things; built-in ones cannot be deleted. */
    fun isCustom(item: LibraryItem) = item.id.startsWith("custom_")

    /**
     * Deletes one of the household's own things, on every device on the list:
     * from the picture grid, favourites and shared pictures.
     * Things already on the shopping list stay there.
     */
    fun deleteCustom(context: Context, item: LibraryItem) {
        if (!isCustom(item)) return
        forgetLocally(context, item.name)
        Session.listId(context)?.let { listId ->
            val list = FirebaseDatabase.getInstance().getReference("lists").child(listId)
            // Kept as "deleted", so no other device shares it again.
            customRef(listId).child(item.id).setValue(mapOf("name" to item.name, "deleted" to true))
            list.child("pictures").child(item.id).removeValue()
            list.child("favourites").child(item.id).removeValue()
        }
        Log.d(TAG, "Deleted '${item.name}'")
        watchers.toList().forEach { it() }
    }

    // ---- Shared with every device on the list ----

    private var sharedListId: String? = null
    private var sharedListener: ValueEventListener? = null
    private var groupListener: ValueEventListener? = null
    private val watchers = mutableListOf<() -> Unit>()

    /** Screens that show the picture grid call this to redraw when things change. */
    fun watch(watcher: () -> Unit) { watchers.add(watcher) }
    fun unwatch(watcher: () -> Unit) { watchers.remove(watcher) }

    private fun customRef(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists").child(listId).child("customItems")

    /** Which group each thing has been put in, for the whole household. */
    private fun groupRef(listId: String): DatabaseReference =
        FirebaseDatabase.getInstance().getReference("lists").child(listId).child("itemGroups")

    /** Adds to this device's library and saved set. True if it was new here. */
    private fun rememberLocally(context: Context, name: String): Boolean {
        if (items.any { Names.same(it.name, name) }) return false
        val p = prefs(context)
        val saved = p.getStringSet(CUSTOM, emptySet())?.toMutableSet() ?: mutableSetOf()
        saved.add(Names.display(name))
        p.edit().putStringSet(CUSTOM, saved).apply()
        items.add(custom(name))
        return true
    }

    /** Removes one of the household's own things from this device. True if it was here. */
    private fun forgetLocally(context: Context, name: String): Boolean {
        val p = prefs(context)
        val saved = p.getStringSet(CUSTOM, emptySet())?.toMutableSet() ?: mutableSetOf()
        saved.removeAll { Names.same(it, name) }
        p.edit().putStringSet(CUSTOM, saved).apply()
        return items.removeAll { it.id.startsWith("custom_") && Names.same(it.name, name) }
    }

    /** Puts one of the household's own things in Firebase, for every device. */
    private fun share(listId: String, name: String) {
        val item = custom(name)
        customRef(listId).child(item.id).setValue(
            mapOf("name" to item.name, "category" to item.category)
        )
    }

    /**
     * Starts sharing the household's own things with every device on the list.
     * Things only on this device (typed before sharing existed) are shared too.
     * Safe to call often.
     */
    fun startSharing(context: Context, listId: String) {
        if (sharedListId == listId && sharedListener != null) return
        stopSharing()
        val app = context.applicationContext
        load(app)

        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var changed = false
                val known = mutableListOf<String>()   // every name Firebase has, deleted or not

                for (child in snapshot.children) {
                    val name = child.child("name").value?.toString() ?: continue
                    known.add(name)
                    if (child.child("deleted").value == true) {
                        // Deleted on another device: remove it here too.
                        if (forgetLocally(app, name)) {
                            changed = true
                            Log.d(TAG, "'$name' was deleted on another device")
                        }
                    } else if (rememberLocally(app, name)) {
                        // New from another device: add it here.
                        changed = true
                        Log.d(TAG, "Received '$name' from another device")
                    }
                }

                // Things typed on this device that Firebase has never seen: share them.
                val local = prefs(app).getStringSet(CUSTOM, emptySet()) ?: emptySet()
                for (name in local) {
                    if (known.none { Names.same(it, name) }) {
                        share(listId, name)
                        Log.d(TAG, "Shared '$name' with the other devices")
                    }
                }

                if (changed) watchers.toList().forEach { it() }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d(TAG, "Cannot read shared things: ${error.message}")
            }
        }
        customRef(listId).addValueEventListener(l)
        sharedListId = listId
        sharedListener = l

        // The household's own groupings: "Bread is in Bakery now".
        val g = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val edit = groups(app).edit()
                edit.clear()   // Firebase is the whole truth here
                for (child in snapshot.children) {
                    val group = child.value?.toString() ?: continue
                    edit.putString(child.key, group)
                }
                edit.apply()
                watchers.toList().forEach { it() }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d(TAG, "Cannot read the groups: ${error.message}")
            }
        }
        groupRef(listId).addValueEventListener(g)
        groupListener = g
    }

    private fun stopSharing() {
        val id = sharedListId
        val l = sharedListener
        if (id != null && l != null) customRef(id).removeEventListener(l)
        val g = groupListener
        if (id != null && g != null) groupRef(id).removeEventListener(g)
        sharedListId = null
        sharedListener = null
        groupListener = null
    }

    // ---- Groups ----
    //
    // A thing's group starts as the one it was built with ("Bread" is
    // in "Fridge"), but a household can put it anywhere: a shop with a
    // bakery aisle wants a Bakery group. The choice is kept per item id
    // and shared, so every device groups the list the same way.

    private fun groups(context: Context) =
        context.getSharedPreferences("item_groups", Context.MODE_PRIVATE)

    /** The group this thing is in: the household's choice, or the default. */
    fun groupFor(context: Context, item: LibraryItem): String =
        groups(context).getString(item.id, null) ?: item.category

    /** The group for a thing by name, for rows already on the list. */
    fun groupForName(context: Context, name: String, fallback: String): String {
        val item = items.firstOrNull { Names.same(it.name, name) } ?: return fallback
        return groupFor(context, item)
    }

    /** Puts one thing in a group, on every device on the list. */
    fun setGroup(context: Context, item: LibraryItem, group: String) {
        groups(context).edit().putString(item.id, group).apply()
        Session.listId(context)?.let { groupRef(it).child(item.id).setValue(group) }
        Log.d(TAG, "'${item.name}' is now in '$group'")
        watchers.toList().forEach { it() }
    }

    /**
     * Moves everything currently in [from] into [to]. Used when a group
     * is split or removed, so nothing is left pointing at a group that
     * is no longer there.
     */
    fun moveAll(context: Context, from: String, to: String) {
        val moving = items.filter { groupFor(context, it) == from }
        if (moving.isEmpty()) return

        val edit = groups(context).edit()
        moving.forEach { edit.putString(it.id, to) }
        edit.apply()

        Session.listId(context)?.let { listId ->
            groupRef(listId).updateChildren(moving.associate { it.id to to })
        }
        Log.d(TAG, "Moved ${moving.size} things from '$from' to '$to'")
        watchers.toList().forEach { it() }
    }

    // ---- Pictures ----

    /** The picture to use for an item: the household's choice, or the default. */
    fun pictureFor(context: Context, item: LibraryItem): String =
        context.getSharedPreferences("pictures", Context.MODE_PRIVATE)
            .getString(item.id, null) ?: item.picture

    /** Remembers that this item should now use a different picture. */
    fun setPicture(context: Context, itemId: String, picture: String) {
        context.getSharedPreferences("pictures", Context.MODE_PRIVATE)
            .edit().putString(itemId, picture).apply()
    }

    /** The emoji for a picture name, if a built-in thing has one. */
    fun emojiFor(picture: String): String? =
        items.firstOrNull { it.picture == picture }?.emoji?.takeIf { it.isNotEmpty() }

    // ---- Finding things ----

    /** "Strawberries" → "strawberry", "tomatoes" → "tomato", "eggs" → "egg". */
    private fun singular(word: String): String {
        val w = Names.key(word)
        return when {
            w.endsWith("ies") && w.length > 4 -> w.dropLast(3) + "y"
            w.endsWith("oes") -> w.dropLast(2)
            w.endsWith("s") && !w.endsWith("ss") && w.length > 3 -> w.dropLast(1)
            else -> w
        }
    }

    /** Every way of saying this thing, in singular form. */
    private fun forms(item: LibraryItem): List<String> =
        (listOf(item.name) + alsoCalled[item.name].orEmpty()).map { singular(it) }

    /** Exactly this word or phrase, or null. "Pineapple" never finds Apple. */
    private fun exact(text: String): LibraryItem? {
        val s = singular(text)
        if (s.isEmpty()) return null
        return items.firstOrNull { s in forms(it) }
    }

    /**
     * For Say. Tries the whole phrase first ("sweet potato"), then
     * shorter parts, so "some pumpkin please" still finds Pumpkin.
     */
    fun match(heard: String): LibraryItem? {
        val words = Names.key(heard).split(" ").filter { it.isNotEmpty() }
        for (size in words.size downTo 1) {
            for (start in 0..words.size - size) {
                exact(words.subList(start, start + size).joinToString(" "))?.let { return it }
            }
        }
        return null
    }

    /** True if the text names something already in the library. */
    fun isKnown(text: String): Boolean = exact(text) != null

    /**
     * For Type: names starting with the letters first ("Bro" → Broccoli),
     * then names containing them. Five at most, so no scrolling.
     */
    fun suggestions(typed: String): List<LibraryItem> {
        val t = Names.key(typed)
        if (t.isEmpty()) return emptyList()

        fun names(item: LibraryItem) =
            (listOf(item.name) + alsoCalled[item.name].orEmpty()).map { it.lowercase() }

        val starts = items.filter { item -> names(item).any { it.startsWith(t) } }
        val contains = items.filter { item ->
            item !in starts && names(item).any { it.contains(t) }
        }
        return (starts + contains).take(5)
    }

    /** For Photo: the first thing on our list that one of the words names. */
    fun matchPhoto(labels: List<String>): LibraryItem? {
        for (label in labels) exact(label)?.let { return it }
        return null
    }
    /**
     * For Photo, when no exact thing was found: the kind of thing the
     * recogniser saw ("Vegetable" → Fruit & veg), so she can pick it.
     */
    fun categoryFor(labels: List<String>): String? {
        val kinds = mapOf(
            "vegetable" to "Fruit & veg",
            "fruit" to "Fruit & veg",
            "produce" to "Fruit & veg",
            "citrus" to "Fruit & veg",
            "berry" to "Fruit & veg",
            "meat" to "Fridge",
            "dairy" to "Fridge",
            "seafood" to "Fridge"
        )
        for (label in labels) kinds[label.lowercase().trim()]?.let { return it }
        return null
    }

    // ---- Items kept in Firebase, shared by every household ----
    //
    //   library / items / lib_apple = { name, category, emoji, favourite, order }
    //
    // The items live in Firebase. Each phone keeps a copy, so the Add screen
    // works with no internet. An item added or changed in Firebase reaches
    // every phone without an app update. "order" sets where it appears
    // (10, 20, 30…). To take an item out of the app, give it  hidden = true.

    private const val CLOUD_CACHE = "cloud_library"
    private const val CLOUD_SEEDED = "cloud_library_seeded_v2"
    private var cloudStarted = false

    private fun cloudRef() = FirebaseDatabase.getInstance().getReference("library")

    /** Reads the items from Firebase, once per app run. Safe to call often. */
    private fun startCloud(context: Context) {
        if (cloudStarted) return
        cloudStarted = true
        val app = context.applicationContext

        // The last copy from Firebase, so the right items show with no internet.
        prefs(app).getString(CLOUD_CACHE, null)?.let {
            try { applyCloud(org.json.JSONObject(it)) } catch (e: Exception) {}
        }

        uploadIfEmpty(app)

        cloudRef().child("items").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) return
                val json = org.json.JSONObject()
                for (child in snapshot.children) {
                    val id = child.key ?: continue
                    val name = child.child("name").value?.toString() ?: continue
                    val o = org.json.JSONObject()
                    o.put("name", name)
                    o.put("category", child.child("category").value?.toString() ?: "Other")
                    o.put("emoji", child.child("emoji").value?.toString() ?: "")
                    o.put("favourite", child.child("favourite").value == true)
                    o.put("hidden", child.child("hidden").value == true)
                    o.put("order", (child.child("order").value as? Number)?.toInt() ?: Int.MAX_VALUE)
                    json.put(id, o)
                }
                prefs(app).edit().putString(CLOUD_CACHE, json.toString()).apply()
                applyCloud(json)
                watchers.toList().forEach { it() }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d(TAG, "Cannot read the library: ${error.message}")
            }
        })
    }

    /** Puts Firebase's items into the app's list, in Firebase's order (the household's own things last). */
    private fun applyCloud(json: org.json.JSONObject) {
        val order = mutableMapOf<String, Int>()
        val ids = json.keys()
        while (ids.hasNext()) {
            val id = ids.next()
            if (id.startsWith("custom_")) continue          // the household's own things are kept elsewhere
            val o = json.optJSONObject(id) ?: continue
            val at = items.indexOfFirst { it.id == id }
            if (o.optBoolean("hidden")) {
                if (at >= 0) items.removeAt(at)
                continue
            }
            order[id] = o.optInt("order", Int.MAX_VALUE)
            val name = o.optString("name")
            if (name.isBlank()) continue
            val item = LibraryItem(
                id = id,
                name = name,
                category = o.optString("category").ifBlank { "Other" },
                picture = if (at >= 0) items[at].picture else slug(name),
                favourite = o.optBoolean("favourite"),
                emoji = o.optString("emoji")
            )
            if (at >= 0) items[at] = item else items.add(item)
        }
        items.sortBy { order[it.id] ?: Int.MAX_VALUE }
    }

    /** The very first time: uploads the built-in items, only if Firebase has none yet. */
    private fun uploadIfEmpty(app: Context) {
        if (prefs(app).getBoolean(CLOUD_SEEDED, false)) return
        val builtIn = items.filter { it.id.startsWith("lib_") }
        cloudRef().child("items").runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(data: com.google.firebase.database.MutableData):
                    com.google.firebase.database.Transaction.Result {
                if (data.value != null) return com.google.firebase.database.Transaction.abort()
                for ((i, item) in builtIn.withIndex()) {
                    data.child(item.id).value = mapOf(
                        "name" to item.name,
                        "category" to item.category,
                        "emoji" to item.emoji,
                        "favourite" to item.favourite,
                        "order" to (i + 1) * 10   // gaps of 10, so a new item can go in between
                    )
                }
                return com.google.firebase.database.Transaction.success(data)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                // Uploaded now, or already there: either way, never try again on this phone.
                if (error == null) prefs(app).edit().putBoolean(CLOUD_SEEDED, true).apply()
                else Log.d(TAG, "Cannot upload the library: ${error.message}")
            }
        })
    }
}