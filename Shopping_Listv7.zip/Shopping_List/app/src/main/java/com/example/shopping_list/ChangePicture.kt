package com.example.shopping_list

import android.content.ActivityNotFoundException
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

/**
 * Screen 3.7 Change picture.
 *
 * One job only: change the picture. A household's own photo of the
 * thing they actually buy is easier to recognise than a stock image.
 *
 * Take a photo uses the phone's own camera app, so the person sees a
 * camera they already know, and this app needs no camera permission.
 */
class ChangePicture : AppCompatActivity() {

    private var itemId: String = ""

    /** Where the camera app writes the photo before we tidy it up. */
    private val cameraFile: File
        get() = File(cacheDir, "camera").apply { mkdirs() }.let { File(it, "new_photo.jpg") }

    /** The camera app reports back true if a photo was taken. */
    private val takePhoto = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { taken: Boolean ->
        // Pressing back in the camera is not a mistake: say nothing.
        if (taken) savePicture(cameraFile)
    }

    /** Opens the phone's own photo picker. No permission is needed. */
    private val pickPhoto = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        // The picker only lends us the photo, so copy it first.
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                cameraFile.outputStream().use { output -> input.copyTo(output) }
            }
            savePicture(cameraFile)
        } catch (e: Exception) {
            sorry()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_picture)
        Library.load(this)   // make sure the pictures are loaded before showing one

        itemId = intent.getStringExtra("id") ?: ""
        val item = Library.items.firstOrNull { it.id == itemId }
        val name = intent.getStringExtra("name")?.takeIf { it.isNotBlank() } ?: item?.name ?: ""

        // The name, centred under the picture, and the picture itself
        findViewById<TextView>(R.id.itemTitle).text = name
        showCurrent()

        findViewById<android.view.View>(R.id.backButton).setOnClickListener { finish() }   // ‹ back to Pictures

        findViewById<Button>(R.id.takePhotoButton).setOnClickListener { openCamera() }

        findViewById<Button>(R.id.choosePictureButton).setOnClickListener {
            pickPhoto.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        }
    }

    /** Hands the camera app a safe address to save the photo to. */
    private fun openCamera() {
        val uri = FileProvider.getUriForFile(
            this, "$packageName.fileprovider", cameraFile
        )
        try {
            takePhoto.launch(uri)
        } catch (e: ActivityNotFoundException) {
            // Some tablets have no camera app.
            Toast.makeText(this, "This device has no camera. Try Choose a picture.",
                Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Shrinks the photo, turns it the right way up, and keeps it as
     * this item's picture.
     *
     * A camera photo can be 4000 pixels wide. The list never shows a
     * picture bigger than about 100dp, so a 600-pixel copy looks the
     * same, loads quickly and cannot run the phone out of memory.
     */
    private fun savePicture(source: File) {
        try {
            val bitmap = loadSmall(source, 600) ?: return sorry()
            val upright = turnUpright(bitmap, source)

            val file = File(filesDir, "$itemId.jpg")
            file.outputStream().use { upright.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            source.delete()

            Library.setPicture(this, itemId, file.absolutePath)
            val itemName = findViewById<TextView>(R.id.itemTitle).text.toString()
            Session.listId(this)?.let { SharedPictures.upload(this, it, itemId, file, itemName) }   // every device gets it
            Toast.makeText(this, "Picture changed", Toast.LENGTH_SHORT).show()
            finish()   // back to Pictures, which reloads the grid

        } catch (e: Exception) {
            sorry()
        }
    }

    /** Decodes the photo at roughly [maxSide] pixels on its longest side. */
    private fun loadSmall(file: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0) return null

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, options)
    }

    /** Many phones save photos sideways and only note the turn. */
    private fun turnUpright(bitmap: Bitmap, file: File): Bitmap {
        val degrees = when (ExifInterface(file.absolutePath).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
        )) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> return bitmap
        }
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun sorry() {
        Toast.makeText(this, "That picture could not be used", Toast.LENGTH_SHORT).show()
    }

    private fun showCurrent() {
        val item = Library.items.firstOrNull { it.id == itemId } ?: return
        Pictures.show(findViewById<ImageView>(R.id.currentPicture), Library.pictureFor(this, item))
    }
}